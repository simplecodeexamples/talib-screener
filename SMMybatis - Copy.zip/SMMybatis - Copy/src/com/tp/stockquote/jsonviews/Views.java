package com.tp.stockquote.jsonviews;


public class Views {
    public static class Public {}
}