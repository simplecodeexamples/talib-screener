package com.tp.stockquote.dao;

public interface WatchListDao {

}
