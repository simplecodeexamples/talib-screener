package com.tp.stockquote.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.StockGroup;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.TradingMode;

public interface StockDao {

	List<String> selectAllStockNames(String searchString);

	StockObject selectStockByStockName(StockObject stockObject);

	void insertTradingMode(TradingMode tradingMode);

	void editTradingMode(TradingMode tradingMode);

	void deleteTradingMode(TradingMode tradingMode);

	List<TradingMode> getTradingModes(User userObj);

	TradingMode selectTradingModeByName(TradingMode tradingModeObject);

	void insertTradingModeValue(TradingMode tradingModeObject);

	void editTradingModeValue(TradingMode tradingModeObject);

	List<TradingMode> selectTradingModes(int userId);

	List<StockGroup> selectStockGroups(@Param("userid")int userid,@Param("modeid") int modeid);

	StockGroup selectStockGroupByName(StockGroup stockGroupObject);

	void insertStockGroupValue(StockGroup stockGroupObject);

	void updateStockGroupValue(StockGroup stockGroupObject);

	List<Double> selectLastFiveDayPrice(StockObject stockObject);

	List<StockObject> selectLastNDayData(@Param("stockId") int stockId,@Param("numDays") int numDays);



}
