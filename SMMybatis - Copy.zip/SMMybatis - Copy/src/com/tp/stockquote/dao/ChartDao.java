package com.tp.stockquote.dao;

import java.util.List;

import com.tp.stockquote.dto.AdxObject;
import com.tp.stockquote.dto.ChartObject;
import com.tp.stockquote.dto.StockObject;

public interface ChartDao {

	List<Double> selectMacdValues(StockObject stockObject);

	List<Double> selectSignalValues(StockObject stockObject);

	List<AdxObject> selectCurrentAdxValues(StockObject stockObject);

	List<ChartObject> selectCharts(StockObject stockObject);

}
