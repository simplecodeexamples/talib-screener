package com.tp.stockquote.dao;

import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.User;

public interface UserMapper {

	public void insertUser(Map<String, Object> params);
	public User selectUserByuserId(@Param("userId")int userId);
	public User getUserByUserName(User userParam);


}
