package com.tp.stockquote.dao;

import java.util.Map;

import com.tp.stockquote.dto.BalanceObject;
import com.tp.stockquote.dto.User;

public interface BalanceDao {

	void selectBalance(Map<String, Object> paramVal);

	void insertBalance(Map<String, Object> paramVal);

}
