package com.tp.stockquote.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.tp.stockquote.dto.ScreenerObject;


public interface ScreenerDao {

	List<ScreenerObject> selectAllMasterScreeners();

	List<ScreenerObject> selectScreenersByScreenerId(@Param("screenerId") int screenerId);
	
	List<ScreenerObject> selectAllScreenersByMasterScreenerId(@Param("screenerId") int screenerId);

	ScreenerObject selectScreenerByScreenerId(@Param("screenerId") int screenerId);
	

}
