package com.tp.stockquote.dao;

import java.util.List;
import java.util.Map;

import com.tp.stockquote.dto.LedgerObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.MacdObject;
import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.dto.StockGroup;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.TradingMode;
import com.tp.stockquote.dto.TransactionObject;

public interface PortfolioDao {

	void insertPortfolioAttributes(int portfolioid, Integer key, String value);

	List<TransactionObject> selectTransactionByPortfolio(
			PortfolioObject portfolioObject);

	List<PortfolioObject> selectAllPortfolio(PortfolioObject portfolioObject);

	void insertPortfolio(Map<String, Object> params);

	void insertPortfolioAttributes(Map<String, Object> paramsInner);

	void selectAdditionalPortfolioDetails(Map<String, Object> paramVal);

	PortfolioObject selectPortfolio(PortfolioObject portfolioObject);

	List<StrategyObject> selectAllStrategies();

	List<TradingMode> selectModeWiseAllocation(User user);

	List<StockGroup> selectGroupWiseAllocation(User user);

	int selectGroupCountByPortfolio(PortfolioObject portfolioObject);

	List<Map<String, String>> selectAttributesByPortfolioid(
			PortfolioObject portfolioObject);

	void insertStockToPortfolio(Map<String, Object> paramVal);

	List<TransactionObject> selectTransactions(
			TransactionObject transactionObject);

	void editTransaction(Map<String, Object> paramVal);

	List<MacdObject> setLast5DayMacdList(MacdObject macd);

	List<MacdObject> setLast5DaySignalList(MacdObject macd);

	List<LedgerObject> selectLedgerList(User user);

}
