package com.tp.stockquote.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.tp.stockquote.dto.CommentObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.StrategyObject;

public interface StrategyDao {

	List<StrategyObject> selectAllStrategies(User user);

	List<StrategyObject> selectStrategiesByPageNumber(@Param("user") User user,
			@Param("pageNum")  int pageNum,@Param("sortBy") String sortBy,@Param("lastIndex") int lastIndex,@Param("status") String status);

	void insertStrategy(Map<String, Object> paramVal);
	
	void updateStrategy(StrategyObject strategyObject);
	
	
	StrategyObject selectStrategyById(StrategyObject strategyObject);

	List<String> selectAllStrategyNames(@Param("description") String description);

	List<StrategyObject> selectStrategiesByName(@Param("description")  String description);

	void shareStrategy(StrategyObject strategyObject);

	void insertStrategyComment(Map<String, Object> paramVal);

	List<CommentObject> selectStrategyComments(StrategyObject strategyObject);

	void insertStrategySatisfaction(Map<String, Object> paramVal);

	StrategyObject selectStrategySatisfactionById(StrategyObject strategyObject);

	Integer selectSatisfactionCount(StrategyObject strategyObject);

}
