package com.tp.stockquote.service.impl;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tp.stockquote.dao.PortfolioDao;
import com.tp.stockquote.dao.StrategyDao;
import com.tp.stockquote.dto.LedgerObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.MacdObject;
import com.tp.stockquote.dto.OrderObject;
import com.tp.stockquote.dto.OrderTypeObject.ORDERTYPE;
import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.dto.PositionObject;
import com.tp.stockquote.dto.ProfitObject;
import com.tp.stockquote.dto.StockGroup;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.TradingMode;
import com.tp.stockquote.dto.TransactionObject;
import com.tp.stockquote.service.PortfolioService;
import com.tp.stockquote.utility.Util;

@Service("portfolioService")
public class PortfolioServiceImpl implements PortfolioService {

	@Autowired
	private PortfolioDao portfolioDao;
	
	@Autowired
	private StrategyDao strategyDao;

	@Override
	public void createPortfolio(PortfolioObject portfolioObject) {
		try {
			Map<String, Object> params = new HashMap<String, Object>();
			params.put("name", portfolioObject.getPortfolioName());
			params.put("currencyid", portfolioObject.getCurrencyId());
			params.put("createid", portfolioObject.getUser().getUserId());
			params.put("trackportfolio", portfolioObject.getEnableMailAlert());
			params.put("portfolioid", null);
			portfolioDao.insertPortfolio(params);
			int portfolioid = (int) params.get("portfolioid");
			createOrEditPortfolioAttributes(portfolioObject
					.getAttrValueMap(),portfolioid);
		} catch (Exception e) { 
			e.printStackTrace();
		}

	}
	
	@Override
	public void createOrEditPortfolioAttributes(
			Map<Integer, String> prtfolioAttr,int portfolioId) {
		for (Entry<Integer, String> element :prtfolioAttr.entrySet()) {
			Map<String, Object> paramsInner = new HashMap<String, Object>();
			paramsInner.put("portfolioid",
					portfolioId);
			paramsInner.put("attrid", element.getKey());
			paramsInner.put("attrval", element.getValue());
			paramsInner.put("errorCode", null);
			portfolioDao.insertPortfolioAttributes(paramsInner);
			if (paramsInner.get("errorCode")!=null) {
				int error = (int) paramsInner.get("errorCode");
			}
		}
		
	}

	


	@Override
	public PortfolioObject getPortfolio(PortfolioObject portfolioObject) {
		try {
			portfolioObject=portfolioDao.selectPortfolio(portfolioObject);
			
			if (portfolioObject!=null) {
				List<Map<String, String>> portfolioAttrMapList=portfolioDao.selectAttributesByPortfolioid(portfolioObject);
				TreeMap<String, String> portfolioAttrMap=Util.stringMapFromListOfMap(portfolioAttrMapList);
				portfolioObject.setAttrValueDisplay(portfolioAttrMap);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return portfolioObject;
	}

	@Override
	public List<StrategyObject> getAllStrategies() {
		return portfolioDao.selectAllStrategies();
	}

	@Override
	public List<PositionObject> getPositions(PortfolioObject portfolioObject) {

		List<PositionObject> positionList = new ArrayList<PositionObject>();
		try {
			boolean includeHistory=portfolioObject.isIncludeHistory();
			List<TransactionObject> transactionList = portfolioDao
					.selectTransactionByPortfolio(portfolioObject);
			positionList = processTransactionData(transactionList,includeHistory);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return positionList;

	}

	private List<PositionObject> processTransactionData(
			List<TransactionObject> transactionlist,boolean includeHistory) {
		DecimalFormat df = new DecimalFormat("#.00");

		List<PositionObject> positionList = new ArrayList<PositionObject>();
		try {

			List<TransactionObject> tranList = new ArrayList<TransactionObject>();
			int netBuyQuantity = 0;
			int netSellQuantity = 0;
			double totalBuyAmount = 0;
			double totalSellAmount = 0;
			int stockId = 0;
			String exchange = null;
			TransactionObject newTranObject = null;
			if (transactionlist.size() > 0) {
				transactionlist.add(new TransactionObject());
			}
			List<OrderObject> orderList = null;
			for (TransactionObject transactionObject : transactionlist) {

				if (stockId == 0 && null == exchange) {
					orderList = new ArrayList<OrderObject>();
					newTranObject = new TransactionObject();
					newTranObject.setTransactionId(transactionObject
							.getTransactionId());
					newTranObject.setStockObject(transactionObject
							.getStockObject());
					newTranObject.setPortfolioId(transactionObject
							.getPortfolioId());
					newTranObject.setPositionType(transactionObject
							.getPositionType());
					newTranObject.setStrategyId(transactionObject
							.getStrategyId());
					newTranObject.setAmount(transactionObject.getAmount());
					newTranObject.setUser(transactionObject.getUser());
					newTranObject.setCreateDate(transactionObject
							.getCreateDate());
					exchange = transactionObject.getStockObject().getExchange();
					stockId = transactionObject.getStockObject().getStockid();
					OrderObject order = getOrderFromTransaction(newTranObject);
					orderList.add(order);

				}

				if (exchange.equals(transactionObject.getStockObject()
						.getExchange())
						&& stockId == transactionObject.getStockObject()
								.getStockid()
						&& transactionObject.getStockObject().getStockid() != 0) {

					if (transactionObject.getTransactionType() == 1) {
						netBuyQuantity += transactionObject.getQuantity();
						totalBuyAmount += transactionObject.getQuantity()
								* transactionObject.getAmount();
					} else {
						netSellQuantity += transactionObject.getQuantity();
						totalSellAmount += transactionObject.getQuantity()
								* transactionObject.getAmount();

					}
					OrderObject order = getOrderFromTransaction(newTranObject);
					orderList.add(order);
					newTranObject.getStockWiseTransactionList().add(
							transactionObject);

				} else {
					newTranObject.getStockWiseTransactionList().add(
							transactionObject);
					newTranObject.setBuyquantity(netBuyQuantity);
					newTranObject.setSellquantity(netSellQuantity);
					newTranObject.setTotalBuyAmount(totalBuyAmount);
					newTranObject.setTotalSellAmount(totalSellAmount);
					if (netBuyQuantity > 0) {
						newTranObject.setAvgBuyAmount(totalBuyAmount
								/ netBuyQuantity);
					}
					if (netSellQuantity > 0) {
						newTranObject.setAvgSellAmount(totalSellAmount
								/ netSellQuantity);
					}

					if (netBuyQuantity != netSellQuantity || (includeHistory && netBuyQuantity == netSellQuantity)) {
						PositionObject positionObj = new PositionObject();
						positionObj.setNetQuantity(netBuyQuantity
								- netSellQuantity);
						positionObj.setNetAmount(Double.valueOf(df
								.format(totalBuyAmount - totalSellAmount)));
						positionObj.setStockObject(newTranObject
								.getStockObject());
						if (newTranObject.getAvgBuyAmount() > 0
								&& newTranObject.getAvgSellAmount() > 0) {
							positionObj
									.setAvgAmount(Double.valueOf(df.format((newTranObject
											.getAvgBuyAmount() + newTranObject
											.getAvgSellAmount()) / 2)));
						} else if (newTranObject.getAvgBuyAmount() > 0) {
							positionObj.setAvgAmount(Double.valueOf(df
									.format(newTranObject.getAvgBuyAmount())));
						} else if (newTranObject.getAvgSellAmount() > 0) {
							positionObj.setAvgAmount(Double.valueOf(df
									.format(newTranObject.getAvgSellAmount())));
						}
						ProfitObject profit = calculateProfit(netBuyQuantity,
								netSellQuantity,
								newTranObject.getAvgBuyAmount(),
								newTranObject.getAvgSellAmount(), newTranObject
										.getStockObject().getLastPrice());
						positionObj.setProfit(profit);
						positionObj.setOrders(orderList);
						positionList.add(positionObj);
						tranList.add(newTranObject);
					}
					orderList = new ArrayList<OrderObject>();

					newTranObject = new TransactionObject();
					newTranObject.setTransactionId(stockId);
					newTranObject.setStockObject(transactionObject
							.getStockObject());
					newTranObject.setPortfolioId(transactionObject
							.getPortfolioId());
					newTranObject.setPositionType(transactionObject
							.getPositionType());
					newTranObject.setStrategyId(transactionObject
							.getStrategyId());
					newTranObject.setAmount(transactionObject.getAmount());
					newTranObject.setUser(transactionObject.getUser());
					newTranObject.setTransactionType(transactionObject
							.getTransactionType());
					newTranObject.setCreateDate(transactionObject
							.getCreateDate());
					OrderObject order = getOrderFromTransaction(newTranObject);
					orderList.add(order);
					exchange = transactionObject.getStockObject().getExchange();
					stockId = transactionObject.getStockObject().getStockid();
					if (transactionObject.getTransactionType() == 1) {
						netBuyQuantity = transactionObject.getQuantity();
						totalBuyAmount = transactionObject.getQuantity()
								* transactionObject.getAmount();
						netSellQuantity = 0;
						totalSellAmount = 0;
					} else {
						netSellQuantity = transactionObject.getQuantity();
						totalSellAmount = transactionObject.getQuantity()
								* transactionObject.getAmount();
						netBuyQuantity = 0;
						totalBuyAmount = 0;

					}

				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return positionList;

	}

	private ProfitObject calculateProfit(int buyQuantity, int sellQuantity,
			double yourAvgBuyPrice, double yourAvgSellPrice, double currentPrice) {
		DecimalFormat df = new DecimalFormat("#.00");
		double currentProfit = 0;
		double avgPrice = 0;
		double netquantity = 0;
		double baseProfit = 0;
		double netprofit = 0;
		double gain = 0;
		double profitPercent = 0;

		ProfitObject profit = new ProfitObject();

		if (buyQuantity > 0 && sellQuantity > 0) {
			if (buyQuantity > sellQuantity) {
				netquantity = buyQuantity - sellQuantity;
				baseProfit = sellQuantity
						* (yourAvgSellPrice - yourAvgBuyPrice);
				currentProfit = netquantity * (currentPrice - yourAvgBuyPrice);
				netprofit = currentProfit;
				profitPercent = ((currentPrice - yourAvgBuyPrice) * 100 / (yourAvgBuyPrice));
				gain = (netprofit);

			} else if (sellQuantity > buyQuantity) {
				netquantity = sellQuantity - buyQuantity;
				baseProfit = sellQuantity * yourAvgSellPrice - buyQuantity
						* yourAvgBuyPrice;
				currentProfit = netquantity * (currentPrice - yourAvgBuyPrice);
				netprofit = currentProfit - baseProfit;
				profitPercent = ((netprofit / netquantity) * 100 / yourAvgBuyPrice);
				gain = (currentProfit);

			} else if (buyQuantity == sellQuantity) {
				profitPercent = -(((yourAvgBuyPrice - yourAvgSellPrice) * 100) / yourAvgBuyPrice);
				gain = -((yourAvgBuyPrice - yourAvgSellPrice) * buyQuantity);

			}

		} else if (buyQuantity > 0) {
			avgPrice = (yourAvgBuyPrice);
			currentProfit = (currentPrice - avgPrice);
			profitPercent = (((currentPrice) - (avgPrice)) * 100 / (avgPrice));
			gain = (buyQuantity * ((currentPrice) - (avgPrice)));

		} else if (sellQuantity > 0) {
			avgPrice = (yourAvgSellPrice);
			profitPercent = (((avgPrice) - (currentPrice)) * 100 / (avgPrice));
			gain = (sellQuantity * ((avgPrice) - (currentPrice)));

		}
		profit.setAmount(Double.valueOf(df.format(gain)));
		profit.setPercent(Double.valueOf(df.format(profitPercent)));
		return profit;

	}

	private OrderObject getOrderFromTransaction(
			TransactionObject transactionObject) {
		OrderObject order = new OrderObject();
		String tranType = transactionObject.getTransactionType() == 1 ? "BUY"
				: "SELL";
		order.setTransactionType(tranType);
		order.setOrderTypeObject(ORDERTYPE.MIS.getOrderType());
		order.setStockObject(transactionObject.getStockObject());
		order.setQuantity(transactionObject.getQuantity());
		order.setAmount(transactionObject.getAmount());
		order.setCreateDate(transactionObject.getCreateDate());
		return order;
	}

	@Override
	public List<PortfolioObject> getAllPortfolio(PortfolioObject portfolioObject) {

		List<PortfolioObject> portfolioList = portfolioDao
				.selectAllPortfolio(portfolioObject);
		for (PortfolioObject portfolioObj : portfolioList) {
			Map<String, Object> paramVal = new HashMap<String, Object>();
			paramVal.put("P_PORTFOLIOID", portfolioObj.getPortfolioId());
			paramVal.put("stockCount", null);
			paramVal.put("profit", null);
			paramVal.put("numberOfgain", null);
			paramVal.put("numberOfloss", null);
			paramVal.put("numberOfUnsettled", null);
			paramVal.put("errorcode", null);
			portfolioDao.selectAdditionalPortfolioDetails(paramVal);
			if (paramVal.get("error") != null) {
				int error = (int) paramVal.get("error");
			}

			portfolioObj.setStockCount((int) paramVal.get("stockCount"));
			portfolioObj.setProfit((double) paramVal.get("profit"));
			portfolioObj.setNumberOfGain((int) paramVal.get("numberOfgain"));
			portfolioObj.setNumberOfLoss((int) paramVal
					.get("numberOfloss"));

		}
		return portfolioList;
	}

	@Override
	public List<TradingMode> getModeWiseallocation(User user) {
		List<TradingMode> tradingModeList=null;
		try {
			tradingModeList=portfolioDao.selectModeWiseAllocation(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tradingModeList;
	}

	@Override
	public List<StockGroup> getGroupWiseAllocation(User user) {
		List<StockGroup> groupList=null;
		try {
			groupList=portfolioDao.selectGroupWiseAllocation(user);
		} catch (Exception e) {
			e.printStackTrace();	
		}
		return groupList;
	}

	@Override
	public int getGroupCountByPortfolio(PortfolioObject portfolioObject) {
		return portfolioDao.selectGroupCountByPortfolio(portfolioObject);
	}

	@Override
	public void addStockToPortfolio(TransactionObject transactionObject) {
		try {
			Map<String, Object> paramVal = new HashMap<String, Object>();
			paramVal.put("STOCKID", transactionObject.getStockObject()
					.getStockid());
			paramVal.put("POSITIONTYPE", transactionObject.getPositionType());
			paramVal.put("TRANTYPE", transactionObject.getTransactionType());
			paramVal.put("QUANTITY", transactionObject.getQuantity());
			paramVal.put("AMOUNT", transactionObject.getAmount());
			paramVal.put("STOPLOSS", transactionObject.getStoploss());
			paramVal.put("USERID", transactionObject.getUser().getUserId());
			paramVal.put("PORTFOLIOID", transactionObject.getPortfolioId());
			paramVal.put("STRATEGYID", transactionObject.getStrategyId());
			paramVal.put("STRATEGYDESCRIPTION",
					transactionObject.getStrategyName());

			paramVal.put("tranId", null);
			paramVal.put("errorCode", null);
			if (paramVal.get("errorCode") != null) {
				int error = (int) paramVal.get("errorCode");
			}
			portfolioDao.insertStockToPortfolio(paramVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<TransactionObject> getTransactions(
			TransactionObject transactionObject) {
		List<TransactionObject> transactionList=null;
		try {
			transactionList=portfolioDao.selectTransactions(transactionObject);
		} catch (Exception e) {
				e.printStackTrace();
		}
		return transactionList;
	}

	@Override
	public void editTransaction(TransactionObject transactionObject) {
			try {
				Map<String, Object> paramVal = new HashMap<String, Object>();
				paramVal.put("P_CREATEDATE", transactionObject.getCreateDate());
				paramVal.put("P_QUANTITY", transactionObject.getQuantity());
				paramVal.put("P_PRICE", transactionObject.getAmount());
				paramVal.put("P_TRANID", transactionObject.getTransactionId());
				paramVal.put("errorCode", null);
				portfolioDao.editTransaction(paramVal);
				if (paramVal.get("errorCode") != null) {
					int error = (int) paramVal.get("errorCode");
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	}

	@Override
	public MacdObject getCurrentMacdValues(StockObject stockObject) {
		MacdObject macd=new MacdObject();
		macd.setShortPeriod(12);
		macd.setLongPeriod(26);
		macd.setSignalPeriod(9);
		macd.setDaySpan(200);
		macd.setTimeframeId(5);
		macd.setStockid(stockObject.getStockid());
	
		try {
			List<MacdObject> last5DayMacd=portfolioDao.setLast5DayMacdList(macd);
			List<MacdObject> last5DaySignal=portfolioDao.setLast5DaySignalList(macd);
			if (last5DayMacd.size()>0 && last5DaySignal.size()>0) {
				macd.setMacdValue(last5DayMacd.get(0).getMacdValue());
				macd.setSignalLineValue(last5DaySignal.get(0).getSignalLineValue());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return macd;
	}

	@Override
	public List<LedgerObject> getLedgerList(User user) {
		 List<LedgerObject> ledgerList = null;
		try {
			ledgerList=portfolioDao.selectLedgerList(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ledgerList;
	}





}
