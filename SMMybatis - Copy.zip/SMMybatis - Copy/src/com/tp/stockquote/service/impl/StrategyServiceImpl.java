package com.tp.stockquote.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tp.stockquote.dao.StrategyDao;
import com.tp.stockquote.dto.CommentObject;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.TransactionObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.service.StrategyService;

@Service("strategyService")
public class StrategyServiceImpl implements StrategyService {
	
	@Autowired
	private StrategyDao strategyDao;

	@Override
	public List<StrategyObject> getAllStrategies(User user) {
		List<StrategyObject> strategyList=null;
		try {
			strategyList=strategyDao.selectAllStrategies(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strategyList;
	}

	@Override
	public List<StrategyObject> getStrategiesByPageNumber(
			User user, int pageNum,String sortBy,int lastIndex,String status) {
			List<StrategyObject> strategyList=null;
		try {
			strategyList=strategyDao.selectStrategiesByPageNumber(user,(pageNum-1)*5,sortBy,lastIndex,status);
		} catch (Exception e) {
				e.printStackTrace();
		}
		return strategyList;
	}

	@Override
	public void addStrategy(StrategyObject strategyObject) {

		try {

			Map<String, Object> paramVal = new HashMap<String, Object>();
			paramVal.put("P_DESCRIPTION", strategyObject.getDescription());
			paramVal.put("P_DETAIL_DESCRIPTION", strategyObject.getDetailDescription());
			paramVal.put("P_SOURCE", strategyObject.getSource());
			paramVal.put("P_USERID", strategyObject.getUserId());
			paramVal.put("P_ENTRYLONG", strategyObject.getEntryLong());
			paramVal.put("P_EXITLONG",strategyObject.getExitLong());
			paramVal.put("P_ENTRYSHORT", strategyObject.getEntryShort());
			paramVal.put("P_EXITSHORT", strategyObject.getExitShort());
			paramVal.put("errorCode", null);
			if (paramVal.get("errorCode") != null) {
				int error = (int) paramVal.get("errorCode");
			}
			strategyDao.insertStrategy(paramVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
	
	
		
	}

	@Override
	public StrategyObject getStrategyById(StrategyObject strategyObject) {
		try {
			strategyObject=strategyDao.selectStrategyById(strategyObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strategyObject;
	}

	@Override
	public void editStrategy(StrategyObject strategyObject) {
		try {
			strategyDao.updateStrategy(strategyObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<String> getAllStrategyNames(String description) {
		List<String> strategies = null;
		try {
			strategies=strategyDao.selectAllStrategyNames(description+"%");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strategies;
	}

	@Override
	public List<StrategyObject> getStrategyDetailsByStrategyName(String description) {
		List<StrategyObject> strategyObject = null;
		try {
			strategyObject=strategyDao.selectStrategiesByName(description);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strategyObject;
	}

	@Override
	public void shareStrategy(StrategyObject strategyObject) {
		try {
			strategyDao.shareStrategy(strategyObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void addStrategyComment(int strategyId,CommentObject commentObject) {
		try {

			Map<String, Object> paramVal = new HashMap<String, Object>();
			paramVal.put("P_STRATEGYID", strategyId);
			paramVal.put("P_COMMENT", commentObject.getDescription());
			paramVal.put("P_USERID", commentObject.getUser().getUserId());
			paramVal.put("errorCode", null);
			if (paramVal.get("errorCode") != null) {
				int error = (int) paramVal.get("errorCode");
			}
			strategyDao.insertStrategyComment(paramVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<CommentObject> showStrategyComments(
			StrategyObject strategyObject) {
		List<CommentObject> comments=null;
		try {
			comments=strategyDao.selectStrategyComments(strategyObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return comments;
	}

	@Override
	public void addStrategySatisfaction(StrategyObject strategyObject) {
		try {

			Map<String, Object> paramVal = new HashMap<String, Object>();
			paramVal.put("P_STRATEGYID", strategyObject.getStrategyId());
			paramVal.put("P_SATISFACTION", strategyObject.getSatisfaction());
			paramVal.put("P_USERID", strategyObject.getUserId());
			paramVal.put("errorCode", null);
			if (paramVal.get("errorCode") != null) {
				int error = (int) paramVal.get("errorCode");
			}
			strategyDao.insertStrategySatisfaction(paramVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public StrategyObject getStrategySatisfactionById(
			StrategyObject strategyObject) {
		StrategyObject strategyObject2 = null;
		try {
			strategyObject2=strategyDao.selectStrategySatisfactionById(strategyObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strategyObject2;
	}

	@Override
	public int getSatisfactionCount(StrategyObject strategyObject, int satisfactionType) {
		Integer satisfactionCount=0;
		try {
			strategyObject.setSatisfaction(satisfactionType);
			satisfactionCount=strategyDao.selectSatisfactionCount(strategyObject);
			satisfactionCount=satisfactionCount==null?0:satisfactionCount;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return satisfactionCount;
	}

	@Override
	public List<StockObject> generateBuySellDate(
			List<StockObject> consolidateStocks) {
		List<StockObject> selectedStocks = new ArrayList<StockObject>();
		for (StockObject stockObject : consolidateStocks) {
			if (stockObject.getLastPrice() < 2500) {

				if (stockObject.getOpen() == stockObject.getDayHigh()
						&& Math.abs((double)(stockObject.getDayLow() - stockObject
								.getLastPrice())
								* 100
								/ stockObject.getLastPrice()) <= 0.5) {
					System.out.println(stockObject.getSymbol() + " Open:"
							+ stockObject.getOpen() + " High:"
							+ stockObject.getDayHigh() + " Low: "
							+ stockObject.getDayLow() + " Last"
							+ stockObject.getLastPrice()+"SELL");
					stockObject.setSignal("SELL");
					stockObject.setStoploss(stockObject.getOpen());
					selectedStocks.add(stockObject);
				} else if (stockObject.getOpen() == stockObject.getDayLow()
						&& Math.abs((double)(stockObject.getDayHigh() - stockObject
								.getLastPrice())
								* 100
								/ stockObject.getLastPrice()) <= 0.5) {
					System.out.println(stockObject.getSymbol() + " Open:"
							+ stockObject.getOpen() + " High:"
							+ stockObject.getDayHigh() + " Low: "
							+ stockObject.getDayLow() + " Last"
							+ stockObject.getLastPrice()+"BUY");
					stockObject.setSignal("BUY");
					stockObject.setStoploss(stockObject.getOpen());
					selectedStocks.add(stockObject);
				}
			

			}
		}
		return selectedStocks;

	}

	@Override
	public List<TransactionObject> setQuantities(
			ArrayList<StockObject> finalSelection, int size, User user) {
		System.out.println("Quantity Allocation: ");
		double riskamount = 200;
		int quantity;
		List<StockObject> stockObjects=finalSelection;
		List<TransactionObject> transactionObjects=new ArrayList<TransactionObject>();
		for (int i=0;i<finalSelection.size();i++) {
			quantity=0;
			StockObject stockObject=finalSelection.get(i);
			System.out.println("Stock name:"
					+ stockObject.getSymbol()
					+ "Price diff :"
					+ (stockObject.getLastPrice() - stockObject.getOpen())
					+ "Abs value :"
					+ Math.abs(stockObject.getLastPrice()
							- stockObject.getOpen()));
			
			if (Math.abs(stockObject.getLastPrice()
							- stockObject.getOpen())>0) {
				quantity=(int) Math.round((riskamount / size)
						/ Math.abs(stockObject.getLastPrice()
								- stockObject.getOpen()));
			}
			 
			if(quantity==0)
				stockObjects.remove(i);
		}
		for (StockObject stockObject : stockObjects) {
			 quantity=(int) Math.round((riskamount / stockObjects.size())
					/ Math.abs(stockObject.getLastPrice()
							- stockObject.getOpen()));
			TransactionObject transactionObject=new TransactionObject();
			transactionObject.setStockObject(stockObject);
			transactionObject.setTransactionType(stockObject.getSignal().equals("BUY")?1:2);
			transactionObject.setPositionType(2);
			transactionObject.setQuantity(quantity);
			transactionObject.setAmount(stockObject.getLastPrice());
			transactionObject.setPortfolioId(1);
			transactionObjects.add(transactionObject);
		}
			
		return transactionObjects;
	}


}
