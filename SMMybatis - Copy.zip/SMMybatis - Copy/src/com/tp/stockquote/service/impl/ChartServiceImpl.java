package com.tp.stockquote.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tp.stockquote.dao.ChartDao;
import com.tp.stockquote.dto.AdxObject;
import com.tp.stockquote.dto.ChartObject;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.service.ChartService;

@Service("chartService")
public class ChartServiceImpl implements ChartService{
	
	@Autowired
	private ChartDao chartDao;

	@Override
	public void getCurrentMacdValues(StockObject stockObject) {
		try {
			List<Double> macdList=chartDao.selectMacdValues(stockObject);
			List<Double> signalList=chartDao.selectSignalValues(stockObject);
			stockObject.getMacd().setLast5DayMacdList(macdList);
			stockObject.getMacd().setLast5DaySignalList(signalList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<AdxObject> getCurrentAdxValues(StockObject stockObject) {
		List<AdxObject> adxObjects = null;
		try {
			adxObjects=chartDao.selectCurrentAdxValues(stockObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return adxObjects;
	}

	@Override
	public List<ChartObject> getCharts(StockObject stockObject) {
		List<ChartObject> chartObjects = null;
		try {
			chartObjects=chartDao.selectCharts(stockObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return chartObjects;
	}

}
