package com.tp.stockquote.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tp.stockquote.dao.StockDao;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.StockGroup;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.TradingMode;
import com.tp.stockquote.service.StockService;

@Service("stockService")
public class StockServiceImpl implements StockService {

	@Autowired
	private StockDao stockDao;
	
	@Override
	public List<String> getAllStockNames(String searchString) {
		List<String> stockNames = null;
		try {
			stockNames= stockDao.selectAllStockNames(searchString+"%");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stockNames;
	}

	@Override
	public StockObject getStockDetailsByStockName(StockObject stockObject) {
		try {

			stockObject= stockDao.selectStockByStockName(stockObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stockObject;
	}

	@Override
	public void addTradingMode(TradingMode tradingMode) {
		try {
			stockDao.insertTradingMode(tradingMode);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void editTradingMode(TradingMode tradingMode) {
		try {
			stockDao.editTradingMode(tradingMode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public void deleteTradingMode(TradingMode tradingMode) {
		try {
			stockDao.deleteTradingMode(tradingMode);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<TradingMode> getTradingModes(User userObj) {
		List<TradingMode> tradingModeList=null;
		try {
			int userId=userObj.getUserId();
			tradingModeList=stockDao.selectTradingModes(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tradingModeList;
	}

	@Override
	public TradingMode getTradingModeByName(TradingMode tradingModeObject) {
		try {
			tradingModeObject=stockDao.selectTradingModeByName(tradingModeObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return tradingModeObject;
	}

	@Override
	public void addTradingModeValue(TradingMode tradingModeObject) {
		try {
			stockDao.insertTradingModeValue(tradingModeObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void editTradingModeValue(TradingMode tradingModeObject) {
		try {
			stockDao.editTradingModeValue(tradingModeObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public List<StockGroup> getStockGroups(int userid,int modeid) {
		List<StockGroup> stockGroups=null;
		try {
			stockGroups= stockDao.selectStockGroups(userid,modeid);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stockGroups;
	}

	@Override
	public StockGroup getStockGroupByName(StockGroup stockGroupObject) {
		StockGroup stockGroup=null;
		try {
			stockGroup=stockDao.selectStockGroupByName(stockGroupObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stockGroup;
	}

	@Override
	public void addStockGroupValue(StockGroup stockGroupObject) {
		try {
			stockDao.insertStockGroupValue(stockGroupObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Override
	public void editStockGroupValue(StockGroup stockGroupObject) {
		try {
			stockDao.updateStockGroupValue(stockGroupObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public boolean[] getLastFiveDayPerformance(StockObject stockObject) {
		boolean[] fiveDayPerformance=new boolean[5];
		List<Double> fiveDayPrice=new ArrayList<Double>();
		try {
			fiveDayPrice=stockDao.selectLastFiveDayPrice(stockObject);
			double lastPrice=fiveDayPrice.get(fiveDayPrice.size()-1);
			for (int i = fiveDayPrice.size()-1; i >=0; i--) {
				if (fiveDayPrice.get(i)<lastPrice) {
					fiveDayPerformance[fiveDayPrice.size()-1-i]=false;
				}
				else
					fiveDayPerformance[fiveDayPrice.size()-1-i]=true;

			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return fiveDayPerformance;
		
	}

	@Override
	public List<StockObject> getLastNdaysData(int stockId,int numDays) {
		List<StockObject> stockObjects= new ArrayList<StockObject>();
		try {
			stockObjects=stockDao.selectLastNDayData(stockId,numDays);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return stockObjects;
	}	

}
