package com.tp.stockquote.service.impl;

import com.tp.stockquote.service.WatchListService;

public class WatchListServiceImpl implements WatchListService{

}
