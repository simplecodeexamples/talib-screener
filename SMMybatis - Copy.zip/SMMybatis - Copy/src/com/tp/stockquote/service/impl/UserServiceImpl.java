package com.tp.stockquote.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.filter.HTTPBasicAuthFilter;
import com.tp.stockquote.dao.UserMapper;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.UserLogin;
import com.tp.stockquote.service.UserService;


@Service("userService")
public class UserServiceImpl implements UserService {

	@Autowired
	private UserMapper userMapper;

	@Value("${ldap.authentication.url}")
	private String ldapAutheticationUrl;

	
	public void insertUser(User user) {
		try {

			Map<String, Object> params = new HashMap<String, Object>();
			params.put("P_FIRSTNAME", user.getFirstName());
			params.put("P_LASTNAME", user.getLastName());
			params.put("P_EMAIL", user.getEmailAddress());
			params.put("P_ADDRESS",user.getAddress());
			params.put("P_PHONE", user.getPhone());
			params.put("P_PASSWORD", user.getPassword());
			params.put("errorCode", null);
			userMapper.insertUser(params);
			if (params.get("errorCode") != null) {
				int error = (int) params.get("errorCode");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	@Override
	public User getUserByLogin(User userParam) {
		User user = null;
		try {
			user = userMapper.getUserByUserName(userParam);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		return user;
	}


	@Override
	public boolean isLDAPAuthorised(UserLogin userLogin) {

		boolean authenticated = false;
		try {
			Client client = Client.create();
			String username = "admin";
			String password = "system";
			client.addFilter(new HTTPBasicAuthFilter(username, password));

			JSONObject authDetails = new JSONObject();
			authDetails.put("username", userLogin.getUserName());
			authDetails.put("password", userLogin.getPassword());

			System.out.println(authDetails.toString());
			WebResource webResource = client.resource(ldapAutheticationUrl);
			ClientResponse response = webResource
					.type(MediaType.APPLICATION_JSON)
					.accept(MediaType.APPLICATION_OCTET_STREAM)
					.post(ClientResponse.class, authDetails.toString());

			System.out.println("response: " + response.getStatus());
			String output = null;
			output = response.getEntity(String.class);
			System.out.println(output);
			authenticated=response.getStatus()==200?!authenticated:authenticated;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return authenticated;
	}
	@Override
	public User getUserByuserId(int userId) {
		User user=null;
		try {
			 user=userMapper.selectUserByuserId(userId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return user;
	}



}
