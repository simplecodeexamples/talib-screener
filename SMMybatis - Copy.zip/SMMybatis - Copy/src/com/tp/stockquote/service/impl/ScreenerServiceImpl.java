package com.tp.stockquote.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tp.stockquote.dao.ScreenerDao;
import com.tp.stockquote.dto.ScreenerObject;
import com.tp.stockquote.service.ScreenerService;

@Service("screenerService")
public class ScreenerServiceImpl implements ScreenerService {

	@Autowired
	private ScreenerDao screenerDao;

	@Override
	public List<ScreenerObject> getAllMasterScreeners() {
		List<ScreenerObject> screenerObjects = null;
		try {
			screenerObjects=screenerDao.selectAllMasterScreeners();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return screenerObjects;
	}

	@Override
	public List<ScreenerObject> getScreenersByScreenerId(int screenerId) {
		List<ScreenerObject> screenerObjects = null;
		try {
			screenerObjects=screenerDao.selectScreenersByScreenerId(screenerId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return screenerObjects;
	}
	
	@Override
	public List<ScreenerObject> getScreenersByMasterScreenerId(int screenerId) {
		List<ScreenerObject> screenerObjects = null;
		try {
			screenerObjects=screenerDao.selectAllScreenersByMasterScreenerId(screenerId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return screenerObjects;
	}

	@Override
	public ScreenerObject getScreenerByScreenerId(int screenerId) {
		ScreenerObject screenerObject = null;
		try {
			screenerObject=screenerDao.selectScreenerByScreenerId(screenerId);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return screenerObject;
	}
	
}
