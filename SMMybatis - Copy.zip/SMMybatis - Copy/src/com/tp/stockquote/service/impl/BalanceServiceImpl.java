package com.tp.stockquote.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tp.stockquote.dao.BalanceDao;
import com.tp.stockquote.dto.BalanceObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.service.BalanceService;

@Service("balanceService")
public class BalanceServiceImpl implements BalanceService {

	@Autowired
	private BalanceDao balanceDao;
	
	@Override
	public BalanceObject getBalance(User user) {
		BalanceObject balanceObject=new BalanceObject();
		try {
			Map<String, Object> paramVal = new HashMap<String, Object>();
			paramVal.put("P_USERID", user.getUserId());
			paramVal.put("V_BALANCE", null);
			paramVal.put("V_MODE_BALANCE", null);
			paramVal.put("V_MARGINUSED",null);
			paramVal.put("V_TOTALPROFIT", null);
			paramVal.put("errorCode", null);
			if (paramVal.get("errorCode") != null) {
				int error = (int) paramVal.get("errorCode");
			}
			balanceDao.selectBalance(paramVal);
			balanceObject.setBalance((double)paramVal.get("V_BALANCE"));
			balanceObject.setModeBalance((double)paramVal.get("V_MODE_BALANCE"));
			balanceObject.setMarginUsed((double)paramVal.get("V_MARGINUSED"));
			balanceObject.setTotalProfit((double)paramVal.get("V_TOTALPROFIT"));
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	
		
		return balanceObject;
	}

	@Override
	public void addBalance(BalanceObject balance) {
		try {
			Map<String, Object> paramVal = new HashMap<String, Object>();
			paramVal.put("P_USERID", balance.getUserObject().getUserId());
			paramVal.put("P_AMOUNT", balance.getBalance());
			paramVal.put("P_MODEAMOUNT",balance.getModeBalance());
			paramVal.put("P_TRANTYPE", balance.getTransactionTypeId());
			paramVal.put("P_ACCOUNTTYPE",balance.getAccountTypeId());
			paramVal.put("errorCode", null);
			if (paramVal.get("errorCode") != null) {
				int error = (int) paramVal.get("errorCode");
			}
			balanceDao.insertBalance(paramVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

}
