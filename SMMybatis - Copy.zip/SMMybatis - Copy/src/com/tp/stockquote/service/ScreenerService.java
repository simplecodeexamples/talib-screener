package com.tp.stockquote.service;

import java.util.List;

import com.tp.stockquote.dto.ScreenerObject;


public interface ScreenerService {

	List<ScreenerObject> getAllMasterScreeners();

	List<ScreenerObject> getScreenersByScreenerId(int screenerId);

	List<ScreenerObject> getScreenersByMasterScreenerId(int screenerId);

	ScreenerObject getScreenerByScreenerId(int screenerId);

}
