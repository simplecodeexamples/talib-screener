package com.tp.stockquote.service;

public interface WatchListService {

}
