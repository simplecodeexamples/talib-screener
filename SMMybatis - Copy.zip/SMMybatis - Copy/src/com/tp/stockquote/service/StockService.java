package com.tp.stockquote.service;

import java.util.List;

import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.StockGroup;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.TradingMode;

public interface StockService {


	List<String> getAllStockNames(String searchString);

	StockObject getStockDetailsByStockName(StockObject stockObject);

	void addTradingMode(TradingMode tradingMode);

	void editTradingMode(TradingMode tradingMode);

	void deleteTradingMode(TradingMode tradingMode);

	List<TradingMode> getTradingModes(User userObj);

	TradingMode getTradingModeByName(TradingMode tradingModeObject);

	void addTradingModeValue(TradingMode tradingModeObject);

	void editTradingModeValue(TradingMode tradingModeObject);

	StockGroup getStockGroupByName(StockGroup stockGroupObject);

	void editStockGroupValue(StockGroup stockGroupObject);

	void addStockGroupValue(StockGroup stockGroupObject);

	List<StockGroup> getStockGroups(int userid, int modeid);

	boolean[] getLastFiveDayPerformance(StockObject stockObject);

	List<StockObject> getLastNdaysData(int stockId, int numDays);


}
