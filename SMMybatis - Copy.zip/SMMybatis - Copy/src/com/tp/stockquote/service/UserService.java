package com.tp.stockquote.service;

import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.UserLogin;

public interface UserService {
	void insertUser(User user);
	boolean isLDAPAuthorised(UserLogin userLogin);
	User getUserByLogin(User registered);
	User getUserByuserId(int userId);
}
