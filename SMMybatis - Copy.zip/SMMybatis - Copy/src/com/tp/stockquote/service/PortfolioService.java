package com.tp.stockquote.service;

import java.util.List;
import java.util.Map;

import com.tp.stockquote.dto.LedgerObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.MacdObject;
import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.dto.PositionObject;
import com.tp.stockquote.dto.StockGroup;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.TradingMode;
import com.tp.stockquote.dto.TransactionObject;

public interface PortfolioService {

	void createPortfolio(PortfolioObject portfolioObject);

	PortfolioObject getPortfolio(PortfolioObject portfolioObject);

	List<StrategyObject> getAllStrategies();

	List<PositionObject> getPositions(PortfolioObject portfolioObject);

	List<PortfolioObject> getAllPortfolio(PortfolioObject portfolioObject);

	List<TradingMode> getModeWiseallocation(User user);

	List<StockGroup> getGroupWiseAllocation(User user);

	int getGroupCountByPortfolio(PortfolioObject portfolioObject);

	void addStockToPortfolio(TransactionObject transactionObject);

	List<TransactionObject> getTransactions(TransactionObject transactionObject);

	void editTransaction(TransactionObject transactionObject);

	MacdObject getCurrentMacdValues(StockObject stockObject);
	

	void createOrEditPortfolioAttributes(Map<Integer, String> prtfolioAttr,
			int portfolioId);

	List<LedgerObject> getLedgerList(User user);


	
}
