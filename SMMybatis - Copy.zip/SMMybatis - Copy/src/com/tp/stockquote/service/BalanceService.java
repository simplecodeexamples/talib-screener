package com.tp.stockquote.service;

import com.tp.stockquote.dto.BalanceObject;
import com.tp.stockquote.dto.User;

public interface BalanceService {

	BalanceObject getBalance(User user);

	void addBalance(BalanceObject balance);

}
