package com.tp.stockquote.service;

import java.util.ArrayList;
import java.util.List;

import com.tp.stockquote.dto.CommentObject;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.TransactionObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.StrategyObject;

public interface StrategyService {

	List<StrategyObject> getAllStrategies(User user);



	void addStrategy(StrategyObject strategyObject);


	StrategyObject getStrategyById(StrategyObject strategyObject);


	void editStrategy(StrategyObject strategyObject);


	List<String> getAllStrategyNames(String description);


	List<StrategyObject> getStrategiesByPageNumber(User user,
			int pageNum, String sortBy, int lastIndex, String status);



	List<StrategyObject> getStrategyDetailsByStrategyName(String description);



	void shareStrategy(StrategyObject strategyObject);



	void addStrategyComment(int strategyId, CommentObject commentObject);



	List<CommentObject> showStrategyComments(StrategyObject strategyObject);



  void  addStrategySatisfaction(StrategyObject strategyObject);



StrategyObject getStrategySatisfactionById(StrategyObject strategyObject);



int getSatisfactionCount(StrategyObject strategyObject, int i);



List<StockObject> generateBuySellDate(List<StockObject> consolidateStocks);



List<TransactionObject> setQuantities(ArrayList<StockObject> finalSelection,
		int size, User user);

}
