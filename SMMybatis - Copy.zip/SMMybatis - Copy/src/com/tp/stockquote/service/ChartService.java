package com.tp.stockquote.service;

import java.util.List;

import com.tp.stockquote.dto.AdxObject;
import com.tp.stockquote.dto.ChartObject;
import com.tp.stockquote.dto.StockObject;

public interface ChartService {

	void getCurrentMacdValues(StockObject stockObject);

	List<AdxObject> getCurrentAdxValues(StockObject stockObject);

	List<ChartObject> getCharts(StockObject stockObject);

}
