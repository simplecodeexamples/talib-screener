package com.tp.stockquote.advice;

import java.util.ArrayList;
import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;

import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.mail.service.CustomizedMailService;

@Aspect
public class MailAdvice {
	
	@Autowired
	private CustomizedMailService customizedMailService;
	
	@After("execution(*  com.tp.stockquote.service.PortfolioService.createPortfolio(..))")
	public void sendMailForSenderIdAddEdit(JoinPoint  joinPoint)
	{
		try {
			PortfolioObject portfolioObject=(PortfolioObject) joinPoint.getArgs()[0];
			List<String> sendToList=new ArrayList<String>();
			sendToList.add("biswarup.banerjee@mjunction.in");
			String message="SenderId to be created "+portfolioObject.getPortfolioId();
			/*customizedMailService.sendSenderIdMail(portfolioObject,sendToList,message);*/
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
