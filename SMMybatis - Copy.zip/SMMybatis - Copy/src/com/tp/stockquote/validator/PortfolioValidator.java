package com.tp.stockquote.validator;

import java.util.Map.Entry;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.tp.stockquote.dto.BalanceObject;
import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.dto.User;

public class PortfolioValidator implements Validator {

    @Override
    public boolean supports(final Class<?> clazz) {
        return PortfolioObject.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(final Object obj, final Errors errors) {
    	try {
    		PortfolioObject portfolioObject=(PortfolioObject) obj;

			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "portfolioName",
					"message.portfolioName");
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
        
    }

}
