package com.tp.stockquote.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.tp.stockquote.dto.BalanceObject;
import com.tp.stockquote.dto.User;

public class BalanceValidator implements Validator {

    @Override
    public boolean supports(final Class<?> clazz) {
        return BalanceObject.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(final Object obj, final Errors errors) {
    	try {
    		BalanceObject balanceObject=(BalanceObject) obj;
    		if (balanceObject.getBalanceMode()==1) {
    			if (balanceObject.getBalance()<=0) {
    				errors.rejectValue("balance", "message.balance");
				}
			}
    		else if(balanceObject.getBalanceMode()==2)
    		{
    			if (balanceObject.getModeBalance()<=0) {
    				errors.rejectValue("modeBalance", "message.modeBalance");
				}
    		}
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
        
    }

}
