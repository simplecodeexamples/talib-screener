package com.tp.stockquote.validator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.tp.stockquote.dto.User;

public class UserValidator implements Validator {

	private Pattern pattern;
	private Matcher matcher;
	private static final String EMAIL_PATTERN = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
			+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
	private static final String ID_PATTERN = "[0-9]+";
	private static final String STRING_PATTERN = "[a-zA-Z]+";
	private static final String MOBILE_PATTERN = "[0-9]{10}";

	@Override
	public boolean supports(final Class<?> clazz) {
		return User.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(final Object obj, final Errors errors) {
		try {
			
			User user=(User)obj;
			
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName",
					"message.firstName");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName",
					"message.lastName");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phone",
					"message.phone");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password",
					"message.password");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "emailAddress",
					"message.emailAddress");
			
			 // phone number validation
			  if (!(user.getPhone() != null && user.getPhone().isEmpty())) {
			   pattern = Pattern.compile(MOBILE_PATTERN);
			   matcher = pattern.matcher(user.getPhone());
			   if (!matcher.matches()) {
			    errors.rejectValue("phone", "phone.incorrect",
			      "Enter a correct phone number");
			   }
			  }
			
			  //email validation in spring
			  if (!(user.getEmailAddress() != null && user.getEmailAddress().isEmpty())) {
			   pattern = Pattern.compile(EMAIL_PATTERN);
			   matcher = pattern.matcher(user.getEmailAddress());
			   if (!matcher.matches()) {
			    errors.rejectValue("emailAddress", "message.invalidEmailAddress",
			      "Enter a correct email");
			   }
			  }
			  
			// password matching validation
			  if (!user.getPassword().equals(user.getMatchingPassword())) {
			   errors.rejectValue("confirmPassword", "password.mismatch",
			     "Password does not match");
			  }

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
