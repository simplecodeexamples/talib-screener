package com.tp.stockquote.validator;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.tp.stockquote.dto.BalanceObject;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.User;

public class StrategyValidator implements Validator {

    @Override
    public boolean supports(final Class<?> clazz) {
        return StrategyObject.class.isAssignableFrom(clazz);
    }

    @Override
    public void validate(final Object obj, final Errors errors) {
    	try {
    		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "description",
					"message.description");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "detailDescription",
					"message.detailDescription");
			ValidationUtils.rejectIfEmptyOrWhitespace(errors, "source",
					"message.source");
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
        
    }

}
