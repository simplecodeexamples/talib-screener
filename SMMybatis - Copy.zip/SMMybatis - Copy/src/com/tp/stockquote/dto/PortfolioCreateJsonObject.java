package com.tp.stockquote.dto;

public class PortfolioCreateJsonObject {
  
  
  private String portfolioName;
  private int currencyId;
  private boolean tracking;
  private String stoplossPercent;
  private String targetPercent;
  private String trailingStoplossPercent;
  private String stopWatchTime;
  public String getPortfolioName() {
    return portfolioName;
  }
  public void setPortfolioName(String portfolioName) {
    this.portfolioName = portfolioName;
  }
  public int getCurrencyId() {
    return currencyId;
  }
  public void setCurrencyId(int currencyId) {
    this.currencyId = currencyId;
  }
  public boolean isTracking() {
    return tracking;
  }
  public void setTracking(boolean tracking) {
    this.tracking = tracking;
  }
  public String getStoplossPercent() {
    return stoplossPercent;
  }
  public void setStoplossPercent(String stoplossPercent) {
    this.stoplossPercent = stoplossPercent;
  }
  public String getTargetPercent() {
    return targetPercent;
  }
  public void setTargetPercent(String targetPercent) {
    this.targetPercent = targetPercent;
  }
  public String getTrailingStoplossPercent() {
    return trailingStoplossPercent;
  }
  public void setTrailingStoplossPercent(String trailingStoplossPercent) {
    this.trailingStoplossPercent = trailingStoplossPercent;
  }
  public String getStopWatchTime() {
    return stopWatchTime;
  }
  public void setStopWatchTime(String stopWatchTime) {
    this.stopWatchTime = stopWatchTime;
  }
  
  

}
