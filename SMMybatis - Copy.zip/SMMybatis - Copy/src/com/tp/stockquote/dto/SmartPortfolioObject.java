package com.tp.stockquote.dto;


public class SmartPortfolioObject extends PortfolioObject {

	private String commaSeparatedStockSymbols;
	
	public String getCommaSeparatedStockSymbols() {
		return commaSeparatedStockSymbols;
	}

	public void setCommaSeparatedStockSymbols(String commaSeparatedStockSymbols) {
		this.commaSeparatedStockSymbols = commaSeparatedStockSymbols;
	}
}
