package com.tp.stockquote.dto;

import java.util.Date;
import java.util.List;

public class ScreenerObject {
	private int screenerId;
	private int masterScreenerId;
	private String title;
	private String description;
	private String status;
	private int createId;
	private Date signalDate;
	private String imageUrl;
	List<ScreenerObject> screenerObjects;
	private StockObject stockObject;
	
	
	
	
	
	public StockObject getStockObject() {
		return stockObject;
	}
	public void setStockObject(StockObject stockObject) {
		this.stockObject = stockObject;
	}
	public List<ScreenerObject> getScreenerObjects() {
		return screenerObjects;
	}
	public void setScreenerObjects(List<ScreenerObject> screenerObjects) {
		this.screenerObjects = screenerObjects;
	}
	public int getScreenerId() {
		return screenerId;
	}
	public void setScreenerId(int screenerId) {
		this.screenerId = screenerId;
	}
	public int getMasterScreenerId() {
		return masterScreenerId;
	}
	public void setMasterScreenerId(int masterScreenerId) {
		this.masterScreenerId = masterScreenerId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getCreateId() {
		return createId;
	}
	public void setCreateId(int createId) {
		this.createId = createId;
	}
	public Date getSignalDate() {
		return signalDate;
	}
	public void setSignalDate(Date signalDate) {
		this.signalDate = signalDate;
	}
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	
	

}
