package com.tp.stockquote.dto;

import org.springframework.web.multipart.MultipartFile;

public class FileUpload{

	MultipartFile file;
	private String autoCalcualte;
	private double perLotValue;
	private int portfolioId;
	

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

	public String getAutoCalcualte() {
		return autoCalcualte;
	}
	public void setAutoCalcualte(String autoCalcualte) {
		this.autoCalcualte = autoCalcualte;
	}
	public double getPerLotValue() {
		return perLotValue;
	}
	public void setPerLotValue(double perLotValue) {
		this.perLotValue = perLotValue;
	}
}