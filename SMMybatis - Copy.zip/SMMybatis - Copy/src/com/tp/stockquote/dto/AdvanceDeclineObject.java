package com.tp.stockquote.dto;

public class AdvanceDeclineObject {
	
	private String indexDescription;
	private int indexId;
	private int advances;
	private int declines;
	
	public String getIndexDescription() {
		return indexDescription;
	}
	public void setIndexDescription(String indexDescription) {
		this.indexDescription = indexDescription;
	}
	public int getIndexId() {
		return indexId;
	}
	public void setIndexId(int indexId) {
		this.indexId = indexId;
	}
	public int getAdvances() {
		return advances;
	}
	public void setAdvances(int advances) {
		this.advances = advances;
	}
	public int getDeclines() {
		return declines;
	}
	public void setDeclines(int declines) {
		this.declines = declines;
	}
	

}
