package com.tp.stockquote.dto;

import java.io.Serializable;
import java.util.Date;


public class BaseObject implements Serializable {
	private static final long serialVersionUID = 1L;
	private int id;
	private String name;
	private String description;
	private User createUser;
	private Date createDate;
	private int updateUserId;
	private Date updateDate;
	private String status;
	private User updateUser;
	private String flag;
	
	/** End */

	public BaseObject() {
		super();
		setCreateUser(new User());
		setUpdateUser(new User());
	}
	
	
	public BaseObject(String name) {
		super();
		this.name = name;
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getCreateDate() {
		return createDate;
	}

	public User getCreateUser() {
		return createUser;
	}

	public String getDescription() {
		return description;
	}


	public String getFlag() {
		return flag;
	}

	public int getId() {
		return id;
	}


	public String getStatus() {
		return status;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public int getUpdateUserId() {
		return updateUserId;
	}


	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public void setCreateUser(User createUser) {
		this.createUser = createUser;
	}

	public void setDescription(String description) {
		this.description = description;
	}


	public void setFlag(String flag) {
		this.flag = flag;
	}

	public void setId(int id) {
		this.id = id;
	}


	public void setStatus(String status) {
		this.status = status;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	public void setUpdateUserId(int updateUserId) {
		this.updateUserId = updateUserId;
	}

	public User getUpdateUser() {
		return updateUser;
	}

	public void setUpdateUser(User updateUser) {
		this.updateUser = updateUser;
	}

}
