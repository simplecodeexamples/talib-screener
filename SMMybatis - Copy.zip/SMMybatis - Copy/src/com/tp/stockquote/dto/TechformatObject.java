package com.tp.stockquote.dto;

import java.util.ArrayList;
import java.util.List;

public class TechformatObject extends BaseObject {

	private static final long serialVersionUID = 1L;
	private List<TechformatLineObject> techformatLineObjects;
	private String catalaogDesc;

	public TechformatObject() {
		super();
		techformatLineObjects = new ArrayList<TechformatLineObject>();
		catalaogDesc = new String();
		}

	public String getCatalaogDesc() {
		return catalaogDesc;
	}

	public List<TechformatLineObject> getTechformatLineObjects() {
		return techformatLineObjects;
	}

	public void setCatalaogDesc(String catalaogDesc) {
		this.catalaogDesc = catalaogDesc;
	}

	public void setTechformatLineObjects(
			List<TechformatLineObject> techformatLineObjects) {
		this.techformatLineObjects = techformatLineObjects;
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();

		buffer.append(techformatLineObjects.size() + " line items found:");
		for (TechformatLineObject techformatLineObject : techformatLineObjects) {
			buffer.append(techformatLineObject);
			buffer.append("\n");

			buffer.append("\n-----------");
		}

		return buffer.toString();
	}

}
