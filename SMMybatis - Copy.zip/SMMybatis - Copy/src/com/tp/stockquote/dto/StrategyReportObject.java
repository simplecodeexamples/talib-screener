package com.tp.stockquote.dto;

public class StrategyReportObject {
	private StrategyObject strategyObject;
	private int stockCount;
	private double profit;
	private int numGain;
	private int numLoss;
	private int numUnsettled;
	
	
	
	
	public StrategyReportObject() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public StrategyObject getStrategyObject() {
		return strategyObject;
	}


	public void setStrategyObject(StrategyObject strategyObject) {
		this.strategyObject = strategyObject;
	}


	public int getStockCount() {
		return stockCount;
	}
	public void setStockCount(int stockCount) {
		this.stockCount = stockCount;
	}
	public double getProfit() {
		return profit;
	}
	public void setProfit(double profit) {
		this.profit = profit;
	}
	public int getNumGain() {
		return numGain;
	}
	public void setNumGain(int numGain) {
		this.numGain = numGain;
	}
	public int getNumLoss() {
		return numLoss;
	}
	public void setNumLoss(int numLoss) {
		this.numLoss = numLoss;
	}
	public int getNumUnsettled() {
		return numUnsettled;
	}
	public void setNumUnsettled(int numUnsettled) {
		this.numUnsettled = numUnsettled;
	}
	
	@Override
	public boolean equals(Object object) {boolean result = false;
	if (object == null || object.getClass() != getClass()) {
		result = false;
	} else {
		StrategyReportObject tiger = (StrategyReportObject) object;
		if (this.numGain == tiger.getNumGain()) {
			result = true;
		}
	}
	return result;
	}
	
	@Override
	public int hashCode() {
		int hash = 3;
		hash = 7 * hash + this.numGain;
		return hash;
	}
	

}
