package com.tp.stockquote.dto;


public class UserObject {
	private Integer userId;
	private Integer userTypeId;
	private String loginId;
	private String password;
	private String firstName;
	private String lastName;
	private String email;
	private ServiceObject service;
	/**
	 * @return
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @return
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @return
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @return
	 */
	public String getLoginId() {
		return loginId;
	}

	/**
	 * @return
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return
	 */
	public ServiceObject getService() {
		return service;
	}

	/**
	 * @return
	 */
	public Integer getUserId() {
		return userId;
	}

	/**
	 * @return
	 */
	public Integer getUserTypeId() {
		return userTypeId;
	}

	/**
	 * @param string
	 */
	public void setEmail(String string) {
		email = string;
	}

	/**
	 * @param string
	 */
	public void setFirstName(String string) {
		firstName = string;
	}

	/**
	 * @param string
	 */
	public void setLastName(String string) {
		lastName = string;
	}

	/**
	 * @param string
	 */
	public void setLoginId(String string) {
		loginId = string;
	}

	/**
	 * @param string
	 */
	public void setPassword(String string) {
		password = string;
	}

	/**
	 * @param object
	 */
	public void setService(ServiceObject object) {
		service = object;
	}

	/**
	 * @param integer
	 */
	public void setUserId(Integer integer) {
		userId = integer;
	}

	/**
	 * @param integer
	 */
	public void setUserTypeId(Integer integer) {
		userTypeId = integer;
	}

}
