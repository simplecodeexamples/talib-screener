package com.tp.stockquote.dto;


public class TechformatLineObject extends BaseObject {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private LedgerObject auctionObject;
	private String productCode;
	
	

	public String getProductCode() {
		return productCode;
	}
	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}
	
	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		
		buffer.append(auctionObject.getId()+ ", ");
		buffer.append(auctionObject.getDescription() + ", ");

		buffer.append("ProductCode: " + productCode);
		return buffer.toString();
	}
	
}
