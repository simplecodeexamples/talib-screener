package com.tp.stockquote.dto;

import java.math.BigDecimal;

public class AdxObject extends TechnicalIndicatorObject {
	
	private int stockid;
	private int trSequence;
	private BigDecimal trValue;
	private BigDecimal dmPlusValue;
	private BigDecimal dmMinusValue;
	private BigDecimal dm14PlusValue;
	private BigDecimal dm14MinusValue;
	private BigDecimal atrValue;
	private BigDecimal dxValue;
	private BigDecimal adxValue;
	private int period;
	
	
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public int getStockid() {
		return stockid;
	}
	public void setStockid(int stockid) {
		this.stockid = stockid;
	}
	public int getTrSequence() {
		return trSequence;
	}
	public void setTrSequence(int trSequence) {
		this.trSequence = trSequence;
	}
	public BigDecimal getTrValue() {
		return trValue;
	}
	public void setTrValue(BigDecimal trValue) {
		this.trValue = trValue;
	}
	public BigDecimal getDmPlusValue() {
		return dmPlusValue;
	}
	public void setDmPlusValue(BigDecimal dmPlusValue) {
		this.dmPlusValue = dmPlusValue;
	}
	public BigDecimal getDmMinusValue() {
		return dmMinusValue;
	}
	public void setDmMinusValue(BigDecimal dmMinusValue) {
		this.dmMinusValue = dmMinusValue;
	}
	public BigDecimal getDm14PlusValue() {
		return dm14PlusValue;
	}
	public void setDm14PlusValue(BigDecimal dm14PlusValue) {
		this.dm14PlusValue = dm14PlusValue;
	}
	public BigDecimal getDm14MinusValue() {
		return dm14MinusValue;
	}
	public void setDm14MinusValue(BigDecimal dm14MinusValue) {
		this.dm14MinusValue = dm14MinusValue;
	}
	public BigDecimal getAtrValue() {
		return atrValue;
	}
	public void setAtrValue(BigDecimal atrValue) {
		this.atrValue = atrValue;
	}
	public BigDecimal getDxValue() {
		return dxValue;
	}
	public void setDxValue(BigDecimal dxValue) {
		this.dxValue = dxValue;
	}
	public BigDecimal getAdxValue() {
		return adxValue;
	}
	public void setAdxValue(BigDecimal adxValue) {
		this.adxValue = adxValue;
	}
	
	

}
