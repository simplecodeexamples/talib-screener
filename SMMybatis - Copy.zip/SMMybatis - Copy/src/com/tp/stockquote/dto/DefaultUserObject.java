package com.tp.stockquote.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class DefaultUserObject implements Serializable {
    private static final long serialVersionUID = 1L;
    private String attachmentPath;
    private String[] attachmentPathForMail;
    private String code;
    private String country;
    private String description;
    private String email;
    private String fax;
    private String firstName;
    private String fullName;
    private int id;
    private String lastName;
    private int level;
    private int mailId;
    private String mobile;
    private String organizationName;
    private String password;
    private String phone;
    private String region;
    private Map<Integer, String> roleMap;
    private String searchEmail;
    private int serviceId;
    private String status;
    private int userId;
    private String userType;
    private String vendorCode;
    private double balance;
    private double modebalance;
    private int tradingMode;
    
    
    
    
    public double getModebalance() {
		return modebalance;
	}

	public void setModebalance(double modebalance) {
		this.modebalance = modebalance;
	}

	public int getTradingMode() {
		return tradingMode;
	}

	public void setTradingMode(int tradingMode) {
		this.tradingMode = tradingMode;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public DefaultUserObject() {
	super();
	setRoleMap(new HashMap<Integer, String>());
    }

    public String getAttachmentPath() {
	return attachmentPath;
    }

    public String[] getAttachmentPathForMail() {
	return attachmentPathForMail;
    }

    public String getCode() {
	return code;
    }

    public String getCountry() {
	return country;
    }

    public String getDescription() {
	return description;
    }

    public String getEmail() {
	return email;
    }

    public String getFax() {
	return fax;
    }

    public String getFirstName() {
	return firstName;
    }

    public String getFullName() {
	return fullName;
    }

    public int getId() {
	return id;
    }

    public String getLastName() {
	return lastName;
    }

    public int getLevel() {
	return level;
    }

    public int getMailId() {
	return mailId;
    }

    public String getMobile() {
	return mobile;
    }

    public String getOrganizationName() {
	return organizationName;
    }

    public String getPassword() {
	return password;
    }

    public String getPhone() {
	return phone;
    }

    public String getRegion() {
	return region;
    }

    public Map<Integer, String> getRoleMap() {
	return roleMap;
    }

    public String getSearchEmail() {
	return searchEmail;
    }

    public int getServiceId() {
	return serviceId;
    }

    public String getStatus() {
	return status;
    }

    public int getUserId() {
	return userId;
    }

    public String getUserType() {
	return userType;
    }

    public String getVendorCode() {
	return vendorCode;
    }

    public void setAttachmentPath(String attachmentPath) {
	this.attachmentPath = attachmentPath;
    }

    public void setAttachmentPathForMail(String[] attachmentPathForMail) {
	this.attachmentPathForMail = attachmentPathForMail;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public void setCountry(String country) {
	this.country = country;
    }

    public void setDescription(String description) {
	this.description = description;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public void setFax(String fax) {
	this.fax = fax;
    }

    public void setFirstName(String firstName) {
	this.firstName = firstName;
    }

    public void setFullName() {
	this.fullName = firstName + " " + lastName;
    }

    public void setFullName(String fullName) {
	this.fullName = fullName;
    }

    public void setId(int id) {
	this.id = id;
    }

    public void setLastName(String lastName) {
	this.lastName = lastName;
    }

    public void setLevel(int level) {
	this.level = level;
    }

    public void setMailId(int mailId) {
	this.mailId = mailId;
    }

    public void setMobile(String mobile) {
	this.mobile = mobile;
    }

    public void setOrganizationName(String organizationName) {
	this.organizationName = organizationName;
    }

    public void setPassword(String password) {
	this.password = password;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public void setRegion(String region) {
	this.region = region;
    }

    public void setRoleMap(Map<Integer, String> roleMap) {
	this.roleMap = roleMap;
    }

    public void setSearchEmail(String searchEmail) {
	this.searchEmail = searchEmail;
    }

    public void setServiceId(int serviceId) {
	this.serviceId = serviceId;
    }

    public void setStatus(String status) {
	this.status = status;
    }

    public void setUserId(int userId) {
	this.userId = userId;
    }

    public void setUserType(String userType) {
	this.userType = userType;
    }

    public void setVendorCode(String vendorCode) {
	this.vendorCode = vendorCode;
    }

}
