package com.tp.stockquote.dto;

public class TechnicalIndicatorObject {

	private int timeframeId;
	private int daySpan;
	private String indicatorName;
	private int sequence;
	
	public int getSequence() {
		return sequence;
	}
	public void setSequence(int sequence) {
		this.sequence = sequence;
	}
	public int getTimeframeId() {
		return timeframeId;
	}
	public void setTimeframeId(int timeframeId) {
		this.timeframeId = timeframeId;
	}
	public int getDaySpan() {
		return daySpan;
	}
	public void setDaySpan(int daySpan) {
		this.daySpan = daySpan;
	}
	public String getIndicatorName() {
		return indicatorName;
	}
	public void setIndicatorName(String indicatorName) {
		this.indicatorName = indicatorName;
	}
	
	
}
