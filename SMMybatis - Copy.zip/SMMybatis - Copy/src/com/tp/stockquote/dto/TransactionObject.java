package com.tp.stockquote.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class TransactionObject {

  private int transactionId;
  private StockObject stockObject;
  private int positionType;
  private int transactionType;
  private int quantity;
  private double amount;
  private double stoploss;


  private double avgBuyAmount = 0.00;
  private double avgSellAmount = 0.00;

  private double totalBuyAmount;
  private double totalSellAmount;
  private User user;
  private int portfolioId;
  private int strategyId;
  private String strategyName;
  private Date createDate;
  private String createDateStr;
  private int buyquantity;
  private int sellquantity;

  private double avgBuyPrice;
  private double avgSellPrice;
  
  private int exchangeId;
  private String stockCode;
  private String portfolioName;
  
  
  
  
  public String getPortfolioName() {
	return portfolioName;
}



public void setPortfolioName(String portfolioName) {
	this.portfolioName = portfolioName;
}

private List<TransactionObject> transactionObjects;
  
  
  

  public List<TransactionObject> getTransactionObjects() {
	return transactionObjects;
}



public void setTransactionObjects(List<TransactionObject> transactionObjects) {
	this.transactionObjects = transactionObjects;
}



public String getCreateDateStr() {
	return createDateStr;
}



public void setCreateDateStr(String createDateStr) {
	this.createDateStr = createDateStr;
}



public int getExchangeId() {
	return exchangeId;
}



public void setExchangeId(int exchangeId) {
	this.exchangeId = exchangeId;
}



public String getStockCode() {
	return stockCode;
}



public void setStockCode(String stockCode) {
	this.stockCode = stockCode;
}

private List<TransactionObject> stockWiseTransactionList;



  /* This wil be set to false if buy amount and sell amount is same */
  private boolean tracking;


  public TransactionObject() {
    super();
    this.stockObject = new StockObject();
    stockWiseTransactionList = new ArrayList<TransactionObject>();
  }



  public List<TransactionObject> getStockWiseTransactionList() {
    return stockWiseTransactionList;
  }



  public void setStockWiseTransactionList(List<TransactionObject> stockWiseTransactionList) {
    this.stockWiseTransactionList = stockWiseTransactionList;
  }



  public boolean isTracking() {
    return tracking;
  }

  public void setTracking(boolean tracking) {
    this.tracking = tracking;
  }

  public double getStoploss() {
    return stoploss;
  }

  public void setStoploss(double stoploss) {
    this.stoploss = stoploss;
  }


  public double getAmount() {
    return amount;
  }

  public void setAmount(double amount) {
    this.amount = amount;
  }

  public double getAvgBuyAmount() {
    return avgBuyAmount;
  }

  public void setAvgBuyAmount(double avgBuyAmount) {
    this.avgBuyAmount = avgBuyAmount;
  }

  public double getAvgSellAmount() {
    return avgSellAmount;
  }

  public void setAvgSellAmount(double avgSellAmount) {
    this.avgSellAmount = avgSellAmount;
  }

  public String getStrategyName() {
    return strategyName;
  }

  public void setStrategyName(String strategyName) {
    this.strategyName = strategyName;
  }

  public double getAvgBuyPrice() {
    return avgBuyPrice;
  }

  public void setAvgBuyPrice(double avgBuyPrice) {
    this.avgBuyPrice = avgBuyPrice;
  }

  public double getAvgSellPrice() {
    return avgSellPrice;
  }

  public void setAvgSellPrice(double avgSellPrice) {
    this.avgSellPrice = avgSellPrice;
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }

  public double getTotalBuyAmount() {
    return totalBuyAmount;
  }

  public void setTotalBuyAmount(double totalBuyAmount) {
    this.totalBuyAmount = totalBuyAmount;
  }

  public double getTotalSellAmount() {
    return totalSellAmount;
  }

  public void setTotalSellAmount(double totalSellAmount) {
    this.totalSellAmount = totalSellAmount;
  }

  public int getBuyquantity() {
    return buyquantity;
  }

  public void setBuyquantity(int buyquantity) {
    this.buyquantity = buyquantity;
  }

  public int getSellquantity() {
    return sellquantity;
  }

  public void setSellquantity(int sellquantity) {
    this.sellquantity = sellquantity;
  }

  public Date getCreateDate() {
    return createDate;
  }

  public void setCreateDate(Date createDate) {
    this.createDate = createDate;
  }

  public int getPortfolioId() {
    return portfolioId;
  }

  public void setPortfolioId(int portfolioId) {
    this.portfolioId = portfolioId;
  }

  public int getStrategyId() {
    return strategyId;
  }

  public void setStrategyId(int strategyId) {
    this.strategyId = strategyId;
  }

  public User getUser() {
    return user;
  }

  public void setUser(User user) {
    this.user = user;
  }

  public int getTransactionId() {
    return transactionId;
  }

  public void setTransactionId(int transactionId) {
    this.transactionId = transactionId;
  }

  public StockObject getStockObject() {
    return stockObject;
  }

  public void setStockObject(StockObject stockObject) {
    this.stockObject = stockObject;
  }

  public int getPositionType() {
    return positionType;
  }

  public void setPositionType(int positionType) {
    this.positionType = positionType;
  }

  public int getTransactionType() {
    return transactionType;
  }

  public void setTransactionType(int transactionType) {
    this.transactionType = transactionType;
  }



}
