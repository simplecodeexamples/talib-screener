package com.tp.stockquote.dto;

public class SectorObject {
	
	private int sectorid;
	private String sectorCode;
	private String sectorName;
	private int stockCount;
	private double change;
	public int getSectorid() {
		return sectorid;
	}
	public void setSectorid(int sectorid) {
		this.sectorid = sectorid;
	}
	public String getSectorCode() {
		return sectorCode;
	}
	public void setSectorCode(String sectorCode) {
		this.sectorCode = sectorCode;
	}
	public String getSectorName() {
		return sectorName;
	}
	public void setSectorName(String sectorname) {
		this.sectorName = sectorname;
	}
	public int getStockCount() {
		return stockCount;
	}
	public void setStockCount(int stockCount) {
		this.stockCount = stockCount;
	}
	public double getChange() {
		return change;
	}
	public void setChange(double change) {
		this.change = change;
	}
	
	
	

}
