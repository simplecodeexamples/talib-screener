package com.tp.stockquote.dto;

import java.util.Date;
import java.util.List;

public class WatchlistObject {

	private int watchlistId;
	private String watchlistName;
	private String stockCode;
	private int stockId;
	private Date lastUpdatedOn;
	private int userid;
	private List<StockObject> stockList;
	
	
	
	
	
	
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	public Date getLastUpdatedOn() {
		return lastUpdatedOn;
	}
	public void setLastUpdatedOn(Date lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public List<StockObject> getStockList() {
		return stockList;
	}
	public void setStockList(List<StockObject> stockList) {
		this.stockList = stockList;
	}
	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	public int getWatchlistId() {
		return watchlistId;
	}
	public void setWatchlistId(int watchlistId) {
		this.watchlistId = watchlistId;
	}
	public String getWatchlistName() {
		return watchlistName;
	}
	public void setWatchlistName(String watchlistName) {
		this.watchlistName = watchlistName;
	}
	
	
}
