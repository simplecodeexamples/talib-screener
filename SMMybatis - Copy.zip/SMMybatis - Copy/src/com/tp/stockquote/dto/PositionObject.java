package com.tp.stockquote.dto;

import java.util.List;

public class PositionObject extends BaseObject {
	
	
	private StockObject stockObject;
	private OrderObject buyOrder;
	private OrderObject sellOrder;
	private OrderObject stopLossOrder;
	private OrderObject targetOrder;
	private int netQuantity;
	private double netAmount;
	private double avgAmount;
	private String positionType;
	private ProfitObject profit;
	private List<OrderObject> orders;
	private boolean stoplossMet;
	private boolean macdDownSide;
	private boolean targetMet;
	
	
	
	public boolean isStoplossMet() {
		return stoplossMet;
	}
	public void setStoplossMet(boolean stoplossMet) {
		this.stoplossMet = stoplossMet;
	}
	public boolean isMacdDownSide() {
		return macdDownSide;
	}
	public void setMacdDownSide(boolean macdDownSide) {
		this.macdDownSide = macdDownSide;
	}
	public boolean isTargetMet() {
		return targetMet;
	}
	public void setTargetMet(boolean targetMet) {
		this.targetMet = targetMet;
	}
	public List<OrderObject> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderObject> orders) {
		this.orders = orders;
	}
	public ProfitObject getProfit() {
		return profit;
	}
	public void setProfit(ProfitObject profit) {
		this.profit = profit;
	}
	public double getAvgAmount() {
		return avgAmount;
	}
	public void setAvgAmount(double avgAmount) {
		this.avgAmount = avgAmount;
	}
	public StockObject getStockObject() {
		return stockObject;
	}
	public void setStockObject(StockObject stockObject) {
		this.stockObject = stockObject;
	}
	public OrderObject getBuyOrder() {
		return buyOrder;
	}
	public void setBuyOrder(OrderObject buyOrder) {
		this.buyOrder = buyOrder;
	}
	public OrderObject getSellOrder() {
		return sellOrder;
	}
	public void setSellOrder(OrderObject sellOrder) {
		this.sellOrder = sellOrder;
	}
	public OrderObject getStopLossOrder() {
		return stopLossOrder;
	}
	public void setStopLossOrder(OrderObject stopLossOrder) {
		this.stopLossOrder = stopLossOrder;
	}
	public OrderObject getTargetOrder() {
		return targetOrder;
	}
	public void setTargetOrder(OrderObject targetOrder) {
		this.targetOrder = targetOrder;
	}
	public int getNetQuantity() {
		return netQuantity;
	}
	public void setNetQuantity(int netQuantity) {
		this.netQuantity = netQuantity;
	}
	public double getNetAmount() {
		return netAmount;
	}
	public void setNetAmount(double netAmount) {
		this.netAmount = netAmount;
	}
	public String getPositionType() {
		return positionType;
	}
	public void setPositionType(String positionType) {
		this.positionType = positionType;
	}
	
	

	
	
	
}
