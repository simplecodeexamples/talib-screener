package com.tp.stockquote.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class MailObject extends BaseObject {
    private static final long serialVersionUID = 1L;
    private String filePath;
    private String headerImage;
    private String isFile;
    private List<String> mailAttachments;
    private String mailBody;
    private String mailCC;
    private String mailCCCRM;
    private List<String> mailCCs;
    private String mailFrom;
    private String[] mailIdArray;
    private List<UserObject> mailSenders;
    private Timestamp mailSentDate;
    private String mailSubject;
    private List<String> mailTo;
    private String mobileTo;
    private String mobileToCRM;
    private int nextMailId;
    private int prevMailId;
    private int serviceId;

    public MailObject() {
	super();
	mailAttachments = new ArrayList<String>();
	mailCCs = new ArrayList<String>();
	mailTo = new ArrayList<String>();
	mailSenders = new ArrayList<UserObject>();
    }

    public String getFilePath() {
	return filePath;
    }

    public String getHeaderImage() {
	return headerImage;
    }

    public String getIsFile() {
	return isFile;
    }

    public List<String> getMailAttachments() {
	return mailAttachments;
    }

    public String getMailBody() {
	return mailBody;
    }

    public String getMailCC() {
	return mailCC;
    }

    public String getMailCCCRM() {
	return mailCCCRM;
    }

    public List<String> getMailCCs() {
	return mailCCs;
    }

    public String getMailFrom() {
	return mailFrom;
    }

    public String[] getMailIdArray() {
	return mailIdArray;
    }

    public List<UserObject> getMailSenders() {
	return mailSenders;
    }

    public Timestamp getMailSentDate() {
	return mailSentDate;
    }

    public String getMailSubject() {
	return mailSubject;
    }

    public List<String> getMailTo() {
	return mailTo;
    }

    public String getMobileTo() {
	return mobileTo;
    }

    public String getMobileToCRM() {
	return mobileToCRM;
    }

    public int getNextMailId() {
	return nextMailId;
    }

    public int getPrevMailId() {
	return prevMailId;
    }

    public int getServiceId() {
	return serviceId;
    }

    public void setFilePath(String filePath) {
	this.filePath = filePath;
    }

    public void setHeaderImage(String headerImage) {
	this.headerImage = headerImage;
    }

    public void setIsFile(String isFile) {
	this.isFile = isFile;
    }

    public void setMailAttachments(List<String> mailAttachments) {
	this.mailAttachments = mailAttachments;
    }

    public void setMailBody(String mailBody) {
	this.mailBody = mailBody;
    }

    public void setMailCC(String mailCC) {
	this.mailCC = mailCC;
    }

    public void setMailCCCRM(String mailCCCRM) {
	this.mailCCCRM = mailCCCRM;
    }

    public void setMailCCs(List<String> mailCCs) {
	this.mailCCs = mailCCs;
    }

    public void setMailFrom(String mailFrom) {
	this.mailFrom = mailFrom;
    }

    public void setMailIdArray(String[] mailIdArray) {
	this.mailIdArray = mailIdArray;
    }

    public void setMailSenders(List<UserObject> mailSenders) {
	this.mailSenders = mailSenders;
    }

    public void setMailSentDate(Timestamp mailSentDate) {
	this.mailSentDate = mailSentDate;
    }

    public void setMailSubject(String mailSubject) {
	this.mailSubject = mailSubject;
    }

    public void setMailTo(List<String> mailTo) {
	this.mailTo = mailTo;
    }

    public void setMobileTo(String mobileTo) {
	this.mobileTo = mobileTo;
    }

    public void setMobileToCRM(String mobileToCRM) {
	this.mobileToCRM = mobileToCRM;
    }

    public void setNextMailId(int nextMailId) {
	this.nextMailId = nextMailId;
    }

    public void setPrevMailId(int prevMailId) {
	this.prevMailId = prevMailId;
    }

    public void setServiceId(int serviceId) {
	this.serviceId = serviceId;
    }

}
