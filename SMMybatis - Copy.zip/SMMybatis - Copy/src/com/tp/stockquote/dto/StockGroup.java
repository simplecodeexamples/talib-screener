package com.tp.stockquote.dto;

import java.util.Map;

public class StockGroup {

	private int groupid;
	private String code;
	private String name;
	private double allocationPercentage;
	private int allocationQuantity;
	private int userid;
	private int modeid;
	private double perLotValue;
	private int remQuantity;
	
	private Map<String, Double> stockGroupMap;
	private Map<String, Integer> stockGroupQuantityMap;

	
	

	public Map<String, Integer> getStockGroupQuantityMap() {
		return stockGroupQuantityMap;
	}

	public void setStockGroupQuantityMap(Map<String, Integer> stockGroupQuantityMap2) {
		this.stockGroupQuantityMap = stockGroupQuantityMap2;
	}

	public int getAllocationQuantity() {
		return allocationQuantity;
	}

	public void setAllocationQuantity(int allocationQuantity) {
		this.allocationQuantity = allocationQuantity;
	}

	public int getRemQuantity() {
		return remQuantity;
	}

	public void setRemQuantity(int remQuantity) {
		this.remQuantity = remQuantity;
	}

	public double getPerLotValue() {
		return perLotValue;
	}

	public void setPerLotValue(double perLotValue) {
		this.perLotValue = perLotValue;
	}


	public Map<String, Double> getStockGroupMap() {
		return stockGroupMap;
	}

	public void setStockGroupMap(Map<String, Double> stockGroupMap2) {
		this.stockGroupMap = stockGroupMap2;
	}

	public int getModeid() {
		return modeid;
	}

	public void setModeid(int modeid) {
		this.modeid = modeid;
	}

	public double getAllocationPercentage() {
		return allocationPercentage;
	}

	public void setAllocationPercentage(double allocationPercentage) {
		this.allocationPercentage = allocationPercentage;
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public int getGroupid() {
		return groupid;
	}

	public void setGroupid(int groupid) {
		this.groupid = groupid;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
