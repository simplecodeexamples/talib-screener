package com.tp.stockquote.dto;

import java.io.Serializable;
import java.util.HashMap;

public class UserSignInSessionObject implements Serializable {
	private static final long serialVersionUID = 1L;
	private boolean isRoleAvailableFlag;
	private boolean validPassword=true;
	public boolean isValidPassword() {
		return validPassword;
	}

	public void setValidPassword(boolean validPassword) {
		this.validPassword = validPassword;
	}

	//private boolean mdEscalationPresent;
	private HashMap<Integer, String> roleMap;
	private ServiceObject serviceObject;
	private String sessionId;
	private User userObject;
	private int userRoleId;

	public UserSignInSessionObject() {
		super();
		userObject = new User();
		serviceObject = new ServiceObject();
		isRoleAvailableFlag = true;
		roleMap = new HashMap<Integer, String>();
	}

	public HashMap<Integer, String> getRoleMap() {
		return roleMap;
	}

	public ServiceObject getServiceObject() {
		return serviceObject;
	}

	public String getSessionId() {
		return sessionId;
	}

	public User getUserObject() {
		return userObject;
	}

	public int getUserRoleId() {
		return userRoleId;
	}

	public boolean isRoleAvailableFlag() {
		return isRoleAvailableFlag;
	}

	public void setRoleAvailableFlag(boolean isRoleAvailableFlag) {
		this.isRoleAvailableFlag = isRoleAvailableFlag;
	}

	public void setRoleMap(HashMap<Integer, String> roleMap) {
		this.roleMap = roleMap;
	}

	public void setServiceObject(ServiceObject serviceObject) {
		this.serviceObject = serviceObject;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public void setUserObject(User userObject) {
		this.userObject = userObject;
	}

	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}
}
