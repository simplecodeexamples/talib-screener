package com.tp.stockquote.dto;

import org.springframework.web.multipart.MultipartFile;

public class EarlyMorningFileUpload{

	MultipartFile nifty50;
	MultipartFile niftyNext50;
	MultipartFile niftyMidcap50;
	
	private double perLotValue;
	private int portfolioId;
	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public double getPerLotValue() {
		return perLotValue;
	}
	public void setPerLotValue(double perLotValue) {
		this.perLotValue = perLotValue;
	}

	public MultipartFile getNifty50() {
		return nifty50;
	}

	public void setNifty50(MultipartFile nifty50) {
		this.nifty50 = nifty50;
	}

	public MultipartFile getNiftyNext50() {
		return niftyNext50;
	}

	public void setNiftyNext50(MultipartFile niftyNext50) {
		this.niftyNext50 = niftyNext50;
	}

	public MultipartFile getNiftyMidcap50() {
		return niftyMidcap50;
	}

	public void setNiftyMidcap50(MultipartFile niftyMidcap50) {
		this.niftyMidcap50 = niftyMidcap50;
	}
	
}