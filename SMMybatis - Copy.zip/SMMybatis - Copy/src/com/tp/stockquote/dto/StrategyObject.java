package com.tp.stockquote.dto;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class StrategyObject {

	private int strategyId;
	@NotNull
	@Size(min = 1)
	private String description;
	@NotNull
	@Size(min = 1)
	private String detailDescription;
	@NotNull
	@Size(min = 1)
	private String source;
	private Date createDate;
	private int userId;
	private String creatorName;
	private String strategyType;
	private int likes;
	private int disLikes;
	private List<CommentObject> comments;
//	private List<FormulaObject> formulas;
	private int satisfaction;
	private String comment;
	private String entryLong;
	private String exitLong;
	private String entryShort;
	private String exitShort;
	private List<String> stockLists;
	
	

	public List<String> getStockLists() {
		return stockLists;
	}

	public void setStockLists(List<String> stockLists) {
		this.stockLists = stockLists;
	}

	public String getEntryLong() {
		return entryLong;
	}

	public void setEntryLong(String entryLong) {
		this.entryLong = entryLong;
	}

	public String getExitLong() {
		return exitLong;
	}

	public void setExitLong(String exitLong) {
		this.exitLong = exitLong;
	}

	public String getEntryShort() {
		return entryShort;
	}

	public void setEntryShort(String entryShort) {
		this.entryShort = entryShort;
	}

	public String getExitShort() {
		return exitShort;
	}

	public void setExitShort(String exitShort) {
		this.exitShort = exitShort;
	}

/*	public List<FormulaObject> getFormulas() {
		return formulas;
	}

	public void setFormulas(List<FormulaObject> formulas) {
		this.formulas = formulas;
	}*/

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getDisLikes() {
		return disLikes;
	}

	public void setDisLikes(int disLikes) {
		this.disLikes = disLikes;
	}

	public int getSatisfaction() {
		return satisfaction;
	}

	public void setSatisfaction(int satisfaction) {
		this.satisfaction = satisfaction;
	}

	public int getLikes() {
		return likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}

	public List<CommentObject> getComments() {
		return comments;
	}

	public void setComments(List<CommentObject> comments) {
		this.comments = comments;
	}

	public String getStrategyType() {
		return strategyType;
	}

	public void setStrategyType(String strategyType) {
		this.strategyType = strategyType;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getDetailDescription() {
		return detailDescription;
	}

	public void setDetailDescription(String detailDescription) {
		this.detailDescription = detailDescription;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public int getStrategyId() {
		return strategyId;
	}

	public void setStrategyId(int strategyId) {
		this.strategyId = strategyId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

}
