package com.tp.stockquote.dto;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.tp.stockquote.validator.PasswordMatches;
import com.tp.stockquote.validator.ValidEmail;
import com.tp.stockquote.validator.ValidPassword;


@PasswordMatches
public class User {
	
	private int userId;
		
	private String userName;

	@NotNull
	@Size(min = 1)
	private String firstName;

	@NotNull
	@Size(min = 1)
	private String lastName;
	
	@ValidPassword
	private String password;
	
	@NotNull
	@Size(min = 1)
	private String matchingPassword;
	
	@ValidEmail
	@NotNull
	@Size(min = 1)
	private String emailAddress;
	
	@NotNull
	@Size(min = 1)
	private Date dateOfBirth;
	
	private String account;
	
	private String status;
	
	@NotNull
	@Size(min = 1)
	private String phone;
	
	private double balance;
	
	private double modebalance;
	
	private String address;
	
	
	
	
    public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	@Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("User [firstName=").append(firstName).append(", lastName=").append(lastName).append(", password=").append(password).append(", matchingPassword=").append(matchingPassword).append(", emailAddress=").append(emailAddress).append("]");
        return builder.toString();
    }
    
	
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public double getModebalance() {
		return modebalance;
	}

	public void setModebalance(double modebalance) {
		this.modebalance = modebalance;
	}

	public String getMatchingPassword() {
		return matchingPassword;
	}

	public void setMatchingPassword(String matchingPassword) {
		this.matchingPassword = matchingPassword;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}
		
	public String getEmailAddress() {
		return emailAddress;
	}
	
	public String getFirstName() {
		return firstName;
	}


	public String getLastName() {
		return lastName;
	}

	public String getPassword() {
		return password;
	}

	public String getUserName() {
		return userName;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}	

}
