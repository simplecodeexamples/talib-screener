package com.tp.stockquote.dto;

public class StopLossQuantityObject {
	
	private double stockPrice;
	private double stoplossPercentage;
	private double perLotMaxLoss;
	private double totalBalance;
	private int numberOfLots;
	private int quantity;
	private double stopLoss;
	private double leverage=20.8;
	private int tranType;
	
	
	
	
	public int getTranType() {
		return tranType;
	}
	public void setTranType(int tranType) {
		this.tranType = tranType;
	}
	public double getStockPrice() {
		return stockPrice;
	}
	public void setStockPrice(double stockPrice) {
		this.stockPrice = stockPrice;
	}
	public double getLeverage() {
		return leverage;
	}
	public void setLeverage(double leverage) {
		this.leverage = leverage;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getStopLoss() {
		return stopLoss;
	}
	public void setStopLoss(double stopLoss) {
		this.stopLoss = stopLoss;
	}
	public double getStoplossPercentage() {
		return stoplossPercentage;
	}
	public void setStoplossPercentage(double stoplossPercentage) {
		this.stoplossPercentage = stoplossPercentage;
	}
	public double getPerLotMaxLoss() {
		return perLotMaxLoss;
	}
	public void setPerLotMaxLoss(double perLotMaxLoss) {
		this.perLotMaxLoss = perLotMaxLoss;
	}
	public double getTotalBalance() {
		return totalBalance;
	}
	public void setTotalBalance(double totalBalance) {
		this.totalBalance = totalBalance;
	}
	public int getNumberOfLots() {
		return numberOfLots;
	}
	public void setNumberOfLots(int numberOfLots) {
		this.numberOfLots = numberOfLots;
	}
	
	

}
