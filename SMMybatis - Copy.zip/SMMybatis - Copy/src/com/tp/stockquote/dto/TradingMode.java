package com.tp.stockquote.dto;

import java.util.Date;
import java.util.Map;

public class TradingMode {
	
	private int modeid;
	private String name;
	private String description;
	private Date createdate;
	private double allocationPercentage;
	private int userid;
	private Map<String, Double> tradingModeMap;
	
	
	
	
	public Map<String, Double> getTradingModeMap() {
		return tradingModeMap;
	}
	public void setTradingModeMap(Map<String, Double> tradingModeMap2) {
		this.tradingModeMap = tradingModeMap2;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public double getAllocationPercentage() {
		return allocationPercentage;
	}
	public void setAllocationPercentage(double allocationPercentage) {
		this.allocationPercentage = allocationPercentage;
	}
	public int getModeid() {
		return modeid;
	}
	public void setModeid(int modeid) {
		this.modeid = modeid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Date getCreatedate() {
		return createdate;
	}
	public void setCreatedate(Date createdate) {
		this.createdate = createdate;
	}
	
	
}
