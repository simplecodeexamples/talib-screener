package com.tp.stockquote.dto;

import java.util.Date;

public class EmaObject extends TechnicalIndicatorObject {
	
	private int stockid;
	private int period;
	private int emaid;
	private Date createDate;
	private double emaValue;

	public int getStockid() {
		return stockid;
	}
	public void setStockid(int stockid) {
		this.stockid = stockid;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public int getEmaid() {
		return emaid;
	}
	public void setEmaid(int emaid) {
		this.emaid = emaid;
	}

	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public double getEmaValue() {
		return emaValue;
	}
	public void setEmaValue(double emaValue) {
		this.emaValue = emaValue;
	}
	
	

}
