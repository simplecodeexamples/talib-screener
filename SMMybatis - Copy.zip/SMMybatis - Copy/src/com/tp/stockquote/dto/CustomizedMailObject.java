package com.tp.stockquote.dto;

import java.util.List;

public class CustomizedMailObject {
	
	private List<String> sendToList;
	private List<String> sendCCList;
	private List<String> sendBCCList;
	private String mailFrom;
	private String subject;
	private String body;
	private String time;
	
	
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public List<String> getSendToList() {
		return sendToList;
	}
	public void setSendToList(List<String> sendToList) {
		this.sendToList = sendToList;
	}
	public List<String> getSendCCList() {
		return sendCCList;
	}
	public void setSendCCList(List<String> sendCCList) {
		this.sendCCList = sendCCList;
	}
	public List<String> getSendBCCList() {
		return sendBCCList;
	}
	public void setSendBCCList(List<String> sendBCCList) {
		this.sendBCCList = sendBCCList;
	}
	public String getMailFrom() {
		return mailFrom;
	}
	public void setMailFrom(String mailFrom) {
		this.mailFrom = mailFrom;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	
	

}
