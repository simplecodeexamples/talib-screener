package com.tp.stockquote.dto;

import java.util.List;



public class OrderTypeObject  extends BaseObject{
	
	
	public enum ORDERTYPE{
		
		BO(new OrderTypeObject("BO",20)),MIS(new OrderTypeObject("MIS",11.6)),AMO(new OrderTypeObject("AMO",0)),CNC(new OrderTypeObject("CNC",0));
		
	   	private OrderTypeObject value;

	   	private ORDERTYPE(OrderTypeObject value) { this.value = value; }
	    
	    public OrderTypeObject getOrderType() { return this.value; } 
	    
	    public void setOrderType(OrderTypeObject value){
	    this.value = value; }
	}
	
	
	
	public OrderTypeObject(String name,double leverage) {
		super(name);
		this.leverage = leverage;
	}
	
	private double leverage;
	private int period;
	
	public double getLeverage() {
		return leverage;
	}
	public void setLeverage(double leverage) {
		this.leverage = leverage;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	
	
	
}
