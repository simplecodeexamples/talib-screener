package com.tp.stockquote.dto;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;

public class StockObject extends BaseStockObject implements
		Comparator<StockObject> {

	/* Basic attributes */
	private String searchString;
	private double open;
	private double high;
	private double low;
	private double close;
	private double lastPrice;
	private double change;
	private double pChange;
	private double previousClose;
	private double dayHigh;
	private double dayLow;
	private double totalTradedVolume;
	private double totalTradedValue;
	
	
	
	/* Basic attributes end */

	/* Attributes for signal */


	private String signal;

	private int quantity;

	private double trailingStop;

	private double target;

	private double stoploss;
	
	
	
	/* Attribute end for signal */

	private double extremeLossMargin;
	

	private double sellPrice;
	private double quantityTraded;
	private double low52;
	private String marketType;

	private int faceValue;
	private double varmargin;
	private String companyName;
	private double totalBuyQuantity;
	private double high52;
	private double closePrice;
	private double totalSellQuantity;

	private double applicableMargin;

	private double deliveryToTradedQuantity;

	/* suggested quantities */

	private int suggestedQuantity;
	private double suggestedStoploss;
	private String froSourceName;
	private boolean found;
	private double fefteenMinPrice;
	private double fefteenMinPChange;
	
	
	private Map<Integer,EmaObject> emaMap=null;
	private MacdObject macd;
	
	private int portfolioId;
	private int exchangeId;
	private int timeFrameId;
	
	
	
	
	

	public double getHigh() {
		return high;
	}

	public void setHigh(double high) {
		this.high = high;
	}

	public double getLow() {
		return low;
	}

	public void setLow(double low) {
		this.low = low;
	}

	public double getClose() {
		return close;
	}

	public void setClose(double close) {
		this.close = close;
	}

	public int getTimeFrameId() {
		return timeFrameId;
	}

	public void setTimeFrameId(int timeFrameId) {
		this.timeFrameId = timeFrameId;
	}

	public int getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}

	public int getExchangeId() {
		return exchangeId;
	}

	public void setExchangeId(int exchangeId) {
		this.exchangeId = exchangeId;
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(String searchString) {
		this.searchString = searchString;
	}

	public Map<Integer, EmaObject> getEmaMap() {
		return emaMap;
	}

	public void setEmaMap(Map<Integer, EmaObject> emaMap) {
		this.emaMap = emaMap;
	}

	public MacdObject getMacd() {
		return macd;
	}

	public void setMacd(MacdObject macd) {
		this.macd = macd;
	}

	public StockObject() {
		super();
		emaMap=new HashMap<Integer, EmaObject>();
	}

	public double getFefteenMinPrice() {
		return fefteenMinPrice;
	}

	public void setFefteenMinPrice(double fefteenMinPrice) {
		this.fefteenMinPrice = fefteenMinPrice;
	}

	public double getFefteenMinPChange() {
		return fefteenMinPChange;
	}

	public void setFefteenMinPChange(double fefteenMinPChange) {
		this.fefteenMinPChange = fefteenMinPChange;
	}

	public double getStoploss() {
		return stoploss;
	}

	public void setStoploss(double stoploss) {
		this.stoploss = stoploss;
	}

	public boolean isFound() {
		return found;
	}

	public void setFound(boolean found) {
		this.found = found;
	}

	public String getFroSourceName() {
		return froSourceName;
	}

	public void setFroSourceName(String froSourceName) {
		this.froSourceName = froSourceName;
	}

	private double leverage;

	public int getSuggestedQuantity() {
		return suggestedQuantity;
	}

	public void setSuggestedQuantity(int suggestedQuantity) {
		this.suggestedQuantity = suggestedQuantity;
	}

	public double getSuggestedStoploss() {
		return suggestedStoploss;
	}

	public void setSuggestedStoploss(double suggestedStoploss) {
		this.suggestedStoploss = suggestedStoploss;
	}

	public double getLeverage() {
		return leverage;
	}

	public void setLeverage(double leverage) {
		this.leverage = leverage;
	}

	public double getExtremeLossMargin() {
		return extremeLossMargin;
	}

	public void setExtremeLossMargin(double extremeLossMargin) {
		this.extremeLossMargin = extremeLossMargin;
	}


	public double getChange() {
		return change;
	}

	public void setChange(double change) {
		this.change = change;
	}


	public double getSellPrice() {
		return sellPrice;
	}

	public void setSellPrice(double sellPrice) {
		this.sellPrice = sellPrice;
	}


	public double getQuantityTraded() {
		return quantityTraded;
	}

	public void setQuantityTraded(double quantityTraded) {
		this.quantityTraded = quantityTraded;
	}


	public double getOpen() {
		return open;
	}

	public void setOpen(double open) {
		this.open = open;
	}

	public double getLow52() {
		return low52;
	}

	public void setLow52(double low52) {
		this.low52 = low52;
	}


	public String getMarketType() {
		return marketType;
	}

	public void setMarketType(String marketType) {
		this.marketType = marketType;
	}


	public double getTotalTradedValue() {
		return totalTradedValue;
	}

	public void setTotalTradedValue(double totalTradedValue) {
		this.totalTradedValue = totalTradedValue;
	}

	public int getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(int faceValue) {
		this.faceValue = faceValue;
	}


	public double getPreviousClose() {
		return previousClose;
	}

	public void setPreviousClose(double previousClose) {
		this.previousClose = previousClose;
	}

	public double getVarmargin() {
		return varmargin;
	}

	public void setVarmargin(double varmargin) {
		this.varmargin = varmargin;
	}

	public double getLastPrice() {
		return lastPrice;
	}

	public void setLastPrice(double lastPrice) {
		this.lastPrice = lastPrice;
	}

	public double getpChange() {
		return pChange;
	}

	public void setpChange(double pChange) {
		this.pChange = pChange;
	}


	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}



	public double getTotalBuyQuantity() {
		return totalBuyQuantity;
	}

	public void setTotalBuyQuantity(double totalBuyQuantity) {
		this.totalBuyQuantity = totalBuyQuantity;
	}

	public double getHigh52() {
		return high52;
	}

	public void setHigh52(double high52) {
		this.high52 = high52;
	}


	public double getClosePrice() {
		return closePrice;
	}

	public void setClosePrice(double closePrice) {
		this.closePrice = closePrice;
	}


	public double getTotalSellQuantity() {
		return totalSellQuantity;
	}

	public void setTotalSellQuantity(double totalSellQuantity) {
		this.totalSellQuantity = totalSellQuantity;
	}

	public double getDayHigh() {
		return dayHigh;
	}

	public void setDayHigh(double dayHigh) {
		this.dayHigh = dayHigh;
	}



	public double getApplicableMargin() {
		return applicableMargin;
	}

	public void setApplicableMargin(double applicableMargin) {
		this.applicableMargin = applicableMargin;
	}


	public double getDayLow() {
		return dayLow;
	}

	public void setDayLow(double dayLow) {
		this.dayLow = dayLow;
	}

	public double getDeliveryToTradedQuantity() {
		return deliveryToTradedQuantity;
	}

	public void setDeliveryToTradedQuantity(double deliveryToTradedQuantity) {
		this.deliveryToTradedQuantity = deliveryToTradedQuantity;
	}

	public double getTotalTradedVolume() {
		return totalTradedVolume;
	}

	public void setTotalTradedVolume(double totalTradedVolume) {
		this.totalTradedVolume = totalTradedVolume;
	}
	public String getSignal() {
		return signal;
	}

	public void setSignal(String signal) {
		this.signal = signal;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getTrailingStop() {
		return trailingStop;
	}

	public void setTrailingStop(double trailingStop) {
		this.trailingStop = trailingStop;
	}

	public double getTarget() {
		return target;
	}

	public void setTarget(double target) {
		this.target = target;
	}

	@Override
	public int compare(StockObject st1, StockObject st2) {
		if (Math.abs(st1.getpChange()) > Math.abs(st2.getpChange()))
			return -1;
		if (Math.abs(st1.getpChange()) < Math.abs(st2.getpChange()))
			return 1;
		return 0;
	}

}
