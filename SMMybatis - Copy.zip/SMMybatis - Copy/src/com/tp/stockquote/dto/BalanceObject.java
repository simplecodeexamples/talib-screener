package com.tp.stockquote.dto;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;


public class BalanceObject{
	
		private User userObject;
		private double balance;
		private double modeBalance;
		private int transactionTypeId;
		private  double marginUsed;
		private double totalProfit;
		private double currentProfit;
		private double currentProfitPercent;
		private int accountTypeId;
		@NotNull
		@Size(min = 1)
		private int  balanceMode;
		
		
		
		
		
		
		
		public int getBalanceMode() {
			return balanceMode;
		}
		public void setBalanceMode(int balanceMode) {
			this.balanceMode = balanceMode;
		}
		public int getTransactionTypeId() {
			return transactionTypeId;
		}
		public void setTransactionTypeId(int transactionTypeId) {
			this.transactionTypeId = transactionTypeId;
		}
		public int getAccountTypeId() {
			return accountTypeId;
		}
		public void setAccountTypeId(int accountTypeId) {
			this.accountTypeId = accountTypeId;
		}
		public double getModeBalance() {
			return modeBalance;
		}
		public void setModeBalance(double modeBalance) {
			this.modeBalance = modeBalance;
		}
		public double getCurrentProfit() {
			return currentProfit;
		}
		public void setCurrentProfit(double currentProfit) {
			this.currentProfit = currentProfit;
		}
		public double getCurrentProfitPercent() {
			return currentProfitPercent;
		}
		public void setCurrentProfitPercent(double currentProfitPercent) {
			this.currentProfitPercent = currentProfitPercent;
		}
		public double getMarginUsed() {
			return marginUsed;
		}
		public void setMarginUsed(double marginUsed) {
			this.marginUsed = marginUsed;
		}
		public double getTotalProfit() {
			return totalProfit;
		}
		public void setTotalProfit(double totalProfit) {
			this.totalProfit = totalProfit;
		}
		public User getUserObject() {
			return userObject;
		}
		public void setUserObject(User userObject) {
			this.userObject = userObject;
		}
		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		
}
