package com.tp.stockquote.dto;

public class TransactionJSONObject {

	private int transactionId;
	private int posType;
	private int exchangeId;
	private int tranType;
	private double currentPrice;
	private int quantity;
	private int portfolioId;
	private String stockCode;
	private int strategyId;
	
	
	
	
	public int getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(int strategyId) {
		this.strategyId = strategyId;
	}
	public String getStockCode() {
		return stockCode;
	}
	public void setStockCode(String stockCode) {
		this.stockCode = stockCode;
	}
	public int getTranType() {
		return tranType;
	}
	public void setTranType(int tranType) {
		this.tranType = tranType;
	}
	public int getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public TransactionJSONObject() {
	}
	public int getPosType() {
		return posType;
	}
	public void setPosType(int posType) {
		this.posType = posType;
	}
	public int getExchangeId() {
		return exchangeId;
	}
	public void setExchangeId(int exchangeId) {
		this.exchangeId = exchangeId;
	}
	public double getCurrentPrice() {
		return currentPrice;
	}
	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	  @Override
      public String toString() {
          return "TransactionJSONObject [transactionId="+transactionId+","+"stockCode=" + stockCode +"," +"posType"+posType+","+"exchangeId"+exchangeId+","+"tranType"+tranType+","+"currentPrice"+currentPrice+","+"quantity"+quantity+","+"portfolioId"+portfolioId+","+"strategyId"+strategyId+"]";
      }

	
	
}
