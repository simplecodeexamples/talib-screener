package com.tp.stockquote.dto;


import java.util.HashSet;
import java.util.Set;

public class ServiceObject extends BaseObject {
	private static final long serialVersionUID = 1L;
	private Set category;
	private String description;
	private int serviceId;
	private Set user;

	public ServiceObject() {
		super();
		category = new HashSet();
		user = new HashSet();
	}

	public Set getCategory() {
		return category;
	}

	public String getDescription() {
		return description;
	}

	public int getServiceId() {
		return serviceId;
	}

	public Set getUser() {
		return user;
	}

	public void setCategory(Set category) {
		this.category = category;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}

	public void setUser(Set user) {
		this.user = user;
	}

}
