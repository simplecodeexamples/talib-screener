package com.tp.stockquote.dto;

import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class TransactionListJSONObject {

	private List<TransactionJSONObject> transactionList;

	public List<TransactionJSONObject> getTransactionList() {
		return transactionList;
	}

	@JsonDeserialize(contentAs = TransactionJSONObject.class)
	public void setTransactionList(List<TransactionJSONObject> transactionList) {
		this.transactionList = transactionList;
	}
	
	 @Override
     public String toString() {
         return "TransactionListJSONObject [transactionList=" + transactionList + "]";
     }


}
