package com.tp.stockquote.dto.jsonmodels;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonView;
import com.tp.stockquote.jsonviews.Views;

public class AjaxResponseBody {

	@JsonView(Views.Public.class)
	 String msg;

	@JsonView(Views.Public.class)
	 String code;
	
	@JsonView(Views.Public.class)
	public List<String> ipList;
	
	@JsonView(Views.Public.class)
	public List<String> senderIdList;
	
	@JsonView(Views.Public.class)
	public Object[] templateArr;
	
	
	
	
	
	

	public Object[] getTemplateArr() {
		return templateArr;
	}

	public void setTemplateArr(Object[] templateArr) {
		this.templateArr = templateArr;
	}

	public List<String> getSenderIdList() {
		return senderIdList;
	}

	public void setSenderIdList(List<String> senderIdList) {
		this.senderIdList = senderIdList;
	}

	public List<String> getIpList() {
		return ipList;
	}

	public void setIpList(List<String> ipList) {
		this.ipList = ipList;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}
	
	

}
