package com.tp.stockquote.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MacdObject extends TechnicalIndicatorObject {
	

	private static final int POSITIVE=1;
	private static final int NEGETIVE=2;

	/*public enum CROSSOVERTYPE {

		POSITIVE(1), NEGETIVE(2);

		private final int attr;

		private CROSSOVERTYPE(int attr) {
			this.attr = attr;
		}

		public int getAttr() {
			return attr;
		}
	}
	
	public enum CROSSOVERPOSITION {

		ABOVERZERO(1), BELOWZERO(2);

		private final int attr;

		private CROSSOVERPOSITION(int attr) {
			this.attr = attr;
		}

		public int getAttr() {
			return attr;
		}
	}*/
	
	private int stockid;
	private int shortPeriod;
	private int longPeriod;
	private int signalPeriod;
	private double macdValue;
	private double signalLineValue;
	private Date createDate;
	
	
	
	private List<Double> last5DayMacdList;
	private List<Double> last5DaySignalList;
	
	private boolean crossOver;
	private String crossOverType;
	private String crossOverPosition;
	
	
	
	
	
	
	
	
	
	public String getCrossOverPosition() {
		return crossOverPosition;
	}


	public void setCrossOverPosition(String crossOverPosition) {
		this.crossOverPosition = crossOverPosition;
	}


	public String getCrossOverType() {
		return crossOverType;
	}


	public void setCrossOverType(String crossOverType) {
		this.crossOverType = crossOverType;
	}


	public boolean isCrossOver() {
		return crossOver;
	}


	public void setCrossOver(boolean crossOver) {
		this.crossOver = crossOver;
	}


	public MacdObject() {
		super();
		last5DayMacdList = new ArrayList<Double>();
		last5DaySignalList = new ArrayList<Double>();
	}
	
	
	public void setLast5DayMacdList(List<Double> last5DayMacdList) {
		this.last5DayMacdList = last5DayMacdList;
	}


	public void setLast5DaySignalList(List<Double> last5DaySignalList) {
		this.last5DaySignalList = last5DaySignalList;
	}


	public List<Double> getLast5DayMacdList() {
		return last5DayMacdList;
	}

	public List<Double> getLast5DaySignalList() {
		return last5DaySignalList;
	}


	public double getSignalLineValue() {
		return signalLineValue;
	}
	public void setSignalLineValue(double signalLineValue) {
		this.signalLineValue = signalLineValue;
	}
	public int getStockid() {
		return stockid;
	}
	public void setStockid(int stockid) {
		this.stockid = stockid;
	}
	public int getShortPeriod() {
		return shortPeriod;
	}
	public void setShortPeriod(int shortPeriod) {
		this.shortPeriod = shortPeriod;
	}
	public int getLongPeriod() {
		return longPeriod;
	}
	public void setLongPeriod(int longPeriod) {
		this.longPeriod = longPeriod;
	}
	public int getSignalPeriod() {
		return signalPeriod;
	}
	public void setSignalPeriod(int signalPeriod) {
		this.signalPeriod = signalPeriod;
	}
	public double getMacdValue() {
		return macdValue;
	}
	public void setMacdValue(double macdValue) {
		this.macdValue = macdValue;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	

}
