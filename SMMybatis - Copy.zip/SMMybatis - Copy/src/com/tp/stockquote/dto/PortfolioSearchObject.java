package com.tp.stockquote.dto;

import java.util.Date;

public class PortfolioSearchObject {
	
	private String protFolioName;
	private Date fromDate;
	private Date toDate;
	private double fromAmount;
	private double toAmount;
	private int fromCount;
	private int toCount;
	private int portfolioId;
	private int  userId;
	private int positionType;
	
	
	public int getPositionType() {
		return positionType;
	}
	public void setPositionType(int positionType) {
		this.positionType = positionType;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}
	public int getFromCount() {
		return fromCount;
	}
	public void setFromCount(int fromCount) {
		this.fromCount = fromCount;
	}
	public int getToCount() {
		return toCount;
	}
	public void setToCount(int toCount) {
		this.toCount = toCount;
	}
	public String getProtFolioName() {
		return protFolioName;
	}
	public void setProtFolioName(String protFolioName) {
		this.protFolioName = protFolioName;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public double getFromAmount() {
		return fromAmount;
	}
	public void setFromAmount(double fromAmount) {
		this.fromAmount = fromAmount;
	}
	public double getToAmount() {
		return toAmount;
	}
	public void setToAmount(double toAmount) {
		this.toAmount = toAmount;
	}
	

}
