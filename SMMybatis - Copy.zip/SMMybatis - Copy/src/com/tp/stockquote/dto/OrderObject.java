package com.tp.stockquote.dto;


public class OrderObject extends BaseObject {

	private StockObject stockObject;
	private OrderTypeObject orderTypeObject;
	private String transactionType;
	private String status;
	private int quantity;
	private double amount;
	
	
	
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public OrderTypeObject getOrderTypeObject() {
		return orderTypeObject;
	}
	public void setOrderTypeObject(OrderTypeObject orderTypeObject) {
		this.orderTypeObject = orderTypeObject;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public StockObject getStockObject() {
		return stockObject;
	}
	public void setStockObject(StockObject stockObject) {
		this.stockObject = stockObject;
	}
	
	
	
}
