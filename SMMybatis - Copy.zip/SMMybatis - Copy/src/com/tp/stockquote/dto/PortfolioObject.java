package com.tp.stockquote.dto;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

public class PortfolioObject {

	private int portfolioId;
	@NotNull
	@Size(min = 1)
	private String portfolioName;
	private Date createDate;
	private int currencyId;
	private List<StockObject> stockList;
	private int tranType;
	private double totalBuy;
	private double totalSell;
	private double profitPercentage;
	private Map<Integer,StockObject> stockMap;
	private User user;
	private List<TransactionObject> transactionList;
	
	private int numberofUnsettled;
	private int numberOfGain;
	private int numberOfLoss;
	private double profit;
	private int stockCount;
	private int fromAmount;
	private int toAmount;
	private int fromCount;
	private int toCount;
	
	private Date fromDate;
	private Date toDate;
	private int holdingCapacity;
	private int groupId;
	
	private int modeId;
	private boolean includeHistory;
	private int strategyId;
	
	private List<PortfolioObject> portfolioList;
	
	
	
	
	public List<PortfolioObject> getPortfolioList() {
		return portfolioList;
	}
	public void setPortfolioList(List<PortfolioObject> portfolioList) {
		this.portfolioList = portfolioList;
	}
	public int getStrategyId() {
		return strategyId;
	}
	public void setStrategyId(int strategyId) {
		this.strategyId = strategyId;
	}
	public boolean isIncludeHistory() {
		return includeHistory;
	}
	public void setIncludeHistory(boolean includeHistory) {
		this.includeHistory = includeHistory;
	}
	public int getModeId() {
		return modeId;
	}
	public void setModeId(int modeId) {
		this.modeId = modeId;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public int getHoldingCapacity() {
		return holdingCapacity;
	}
	public void setHoldingCapacity(int holdingCapacity) {
		this.holdingCapacity = holdingCapacity;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public int getFromAmount() {
		return fromAmount;
	}
	public void setFromAmount(int fromAmount) {
		this.fromAmount = fromAmount;
	}
	public int getToAmount() {
		return toAmount;
	}
	public void setToAmount(int toAmount) {
		this.toAmount = toAmount;
	}
	public int getFromCount() {
		return fromCount;
	}
	public void setFromCount(int fromCount) {
		this.fromCount = fromCount;
	}
	public int getToCount() {
		return toCount;
	}
	public void setToCount(int toCount) {
		this.toCount = toCount;
	}
	List<PositionObject> positionList;
	
	
	private String enableMailAlert;
	protected Map<Integer, String> attrValueMap;
	protected Map<String, String> attrValueDisplay;
	
	
	
	
	
	
	public List<PositionObject> getPositionList() {
		return positionList;
	}
	public void setPositionList(List<PositionObject> positionList) {
		this.positionList = positionList;
	}
	
	public Map<String, String> getAttrValueDisplay() {
		return attrValueDisplay;
	}
	public void setAttrValueDisplay(Map<String, String> attrValueDisplay) {
		this.attrValueDisplay = attrValueDisplay;
	}
	public String getEnableMailAlert() {
		return enableMailAlert;
	}
	public void setEnableMailAlert(String enableMailAlert) {
		this.enableMailAlert = enableMailAlert;
	}
	public Map<Integer, String> getAttrValueMap() {
		return attrValueMap;
	}
	public void setAttrValueMap(Map<Integer, String> map) {
		this.attrValueMap = map;
	}
	public double getProfit() {
		return profit;
	}
	public void setProfit(double profit) {
		this.profit = profit;
	}
	public int getStockCount() {
		return stockCount;
	}
	public void setStockCount(int stockCount) {
		this.stockCount = stockCount;
	}
	public int getNumberOfGain() {
		return numberOfGain;
	}
	public void setNumberOfGain(int numberOfGain) {
		this.numberOfGain = numberOfGain;
	}
	public int getNumberOfLoss() {
		return numberOfLoss;
	}
	public void setNumberOfLoss(int numberOfLoss) {
		this.numberOfLoss = numberOfLoss;
	}
	public int getNumberofUnsettled() {
		return numberofUnsettled;
	}
	public void setNumberofUnsettled(int numberofUnsettled) {
		this.numberofUnsettled = numberofUnsettled;
	}
	public int getPortfolioId() {
		return portfolioId;
	}
	public void setPortfolioId(int portfolioId) {
		this.portfolioId = portfolioId;
	}
	public List<TransactionObject> getTransactionList() {
		return transactionList;
	}
	public void setTransactionList(List<TransactionObject> transactionList) {
		this.transactionList = transactionList;
	}
	public PortfolioObject() {
		user=new User();
	}

	public String getPortfolioName() {
		return portfolioName;
	}
	public void setPortfolioName(String portfolioName) {
		this.portfolioName = portfolioName;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public int getCurrencyId() {
		return currencyId;
	}
	public void setCurrencyId(int currencyId) {
		this.currencyId = currencyId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User User) {
		this.user = User;
	}
	public List<StockObject> getStockList() {
		return stockList;
	}
	public void setStockList(List<StockObject> stockList) {
		this.stockList = stockList;
	}
	public int getTranType() {
		return tranType;
	}
	public void setTranType(int tranType) {
		this.tranType = tranType;
	}
	public double getTotalBuy() {
		return totalBuy;
	}
	public void setTotalBuy(double totalBuy) {
		this.totalBuy = totalBuy;
	}
	public double getTotalSell() {
		return totalSell;
	}
	public void setTotalSell(double totalSell) {
		this.totalSell = totalSell;
	}
	public double getProfitPercentage() {
		return profitPercentage;
	}
	public void setProfitPercentage(double profitPercentage) {
		this.profitPercentage = profitPercentage;
	}
	public Map<Integer, StockObject> getStockMap() {
		return stockMap;
	}
	public void setStockMap(Map<Integer, StockObject> stockMap) {
		this.stockMap = stockMap;
	}
	


}
