package com.tp.stockquote.dto;

import java.util.Date;

public class BaseStockObject {

	private int stockid;
	private String symbol;
	private String name;
	private String group;
	private Date createDate;
	private String exchange;
	private SectorObject sector;
	private String groupId;
	private String status;
	private int timeframeId;
	private int period;
	
	
	
	
	public int getTimeframeId() {
		return timeframeId;
	}
	public void setTimeframeId(int timeframeId) {
		this.timeframeId = timeframeId;
	}
	public int getPeriod() {
		return period;
	}
	public void setPeriod(int period) {
		this.period = period;
	}
	public String getGroupId() {
    return groupId;
  }
  public void setGroupId(String groupId) {
    this.groupId = groupId;
  }
  public String getStatus() {
    return status;
  }
  public void setStatus(String status) {
    this.status = status;
  }
  public BaseStockObject() {
		sector=new SectorObject();
	}
	public int getStockid() {
		return stockid;
	}
	public void setStockid(int stockid) {
		this.stockid = stockid;
	}
	public String getSymbol() {
		return symbol;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getExchange() {
		return exchange;
	}
	public void setExchange(String exchange) {
		this.exchange = exchange;
	}
	public SectorObject getSector() {
		return sector;
	}
	public void setSector(SectorObject sector) {
		this.sector = sector;
	} 
	
}
