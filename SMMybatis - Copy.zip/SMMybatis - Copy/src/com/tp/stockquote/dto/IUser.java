package com.tp.stockquote.dto;

import java.util.List;


public interface IUser {
	public UserObject getUser(String loginId) throws Exception;
	public List getService(String serviceId) throws Exception;
}
