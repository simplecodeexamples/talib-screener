package com.tp.stockquote.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.tp.stockquote.dto.ScreenerObject;
import com.tp.stockquote.service.ScreenerService;

@Controller
public class ScreenerController {
	
	@Autowired
	ScreenerService screenerService;
	
	  @RequestMapping(value="/screenershow", method=RequestMethod.GET)
	  public String screenershow(@RequestParam("screenerId") int screenerId,Model model) {
		  try {
			  List<ScreenerObject> masterScreenerObjects=screenerService.getAllMasterScreeners();
			  List<ScreenerObject> screenerObjects=screenerService.getScreenersByMasterScreenerId(screenerId);
			  model.addAttribute("masterScreenerObjects", masterScreenerObjects);
			  model.addAttribute("screenerObjects", screenerObjects);
		  } catch (Exception e) {
				e.printStackTrace();
			}
	      return "screenerlist";
	  }
	  
	  @RequestMapping(value="/screenerdatashow", method=RequestMethod.GET)
	  public String screenerdatashow(@RequestParam("screenerId") int screenerId,Model model) {
		  try {
			  ScreenerObject screenerObject=screenerService.getScreenerByScreenerId(screenerId);
			  List<ScreenerObject> screenerObjects=screenerService.getScreenersByScreenerId(screenerId);
			  model.addAttribute("screenerObjectMaster", screenerObject);
			  model.addAttribute("screenerObjects", screenerObjects);
		  } catch (Exception e) {
			e.printStackTrace();
		}
		  return "screenerresult";
	  }

}
