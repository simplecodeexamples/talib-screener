package com.tp.stockquote.controller.rest;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.jsonmodels.AjaxResponseBody;
import com.tp.stockquote.jsonviews.Views;
import com.tp.stockquote.service.PortfolioService;
import com.tp.stockquote.service.StockService;
import com.tp.stockquote.service.StrategyService;

@RestController
public class StockRestController {

	@Autowired
	private StockService stockService;

	@Autowired
	PortfolioService portfolioService;

	@JsonView(Views.Public.class)
	@RequestMapping(value = "/searchstock", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String searchstock(@RequestBody StockObject stockObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			List<String> list = stockService.getAllStockNames(stockObject
					.getSearchString());
			result = new AjaxResponseBody();
			result.setCode("200");
			if (list != null) {
				result.setTemplateArr(list.toArray());
			}
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result.getTemplateArr());

	}

	@JsonView(Views.Public.class)
	@RequestMapping(value = "/getstockinformation", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String getstockinformation(@RequestBody StockObject stockObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			PortfolioObject portfolioObject = new PortfolioObject();
			portfolioObject.setPortfolioId(stockObject.getPortfolioId());
			portfolioObject = portfolioService.getPortfolio(portfolioObject);
			int timeFrameId = portfolioObject.getPortfolioName().equals("POSITIONS") ? 1:5;
			stockObject.setTimeFrameId(timeFrameId);
			StockObject stockObjectOut = stockService
					.getStockDetailsByStockName(stockObject);

			result = new AjaxResponseBody();
			result.setCode("200");
			result.setTemplateArr(new Object[] { stockObjectOut });
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result.getTemplateArr());

	}
}
