package com.tp.stockquote.controller.rest;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.ArrayUtils;
import org.biswa.ta.pojo.BackTestObject;
import org.biswa.ta.pojo.BacktestExpressionsObject;
import org.biswa.ta.pojo.FormulaObject;
import org.biswa.ta.pojo.ResultObject;
import org.biswa.ta.pojo.TradeObject;
import org.biswa.ta.screens.BackTestPerformance;
import org.biswa.ta.screens.ExecuteScreens;
import org.biswa.ta.screens.formula.FormulaParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tp.stockquote.dto.CommentObject;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.jsonmodels.AjaxResponseBody;
import com.tp.stockquote.jsonviews.Views;
import com.tp.stockquote.service.StockService;
import com.tp.stockquote.service.StrategyService;

@RestController
public class StrategyRestController {
	@Autowired
	private StrategyService strategyService;
	
	@Autowired
	private StockService stockService;


	@JsonView(Views.Public.class)
	@RequestMapping(value = "/searchstrategy", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String searchstock(@RequestBody StrategyObject strategyObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			List<String> list = strategyService
					.getAllStrategyNames(strategyObject.getDescription());
			result = new AjaxResponseBody();
			result.setCode("200");
			if (list != null) {
				result.setTemplateArr(list.toArray());
			}
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result.getTemplateArr());

	}
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/sharestrategy", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String sharestrategy(@RequestBody StrategyObject strategyObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		AjaxResponseBody result = new AjaxResponseBody();
		try {
			strategyService.shareStrategy(strategyObject);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result);

	}
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/addstrategycomment", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String addstrategycomment(@RequestBody StrategyObject strategyObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = new ObjectMapper();
		AjaxResponseBody result = new AjaxResponseBody();
		try {
			User user=(User) sessionObj.getAttribute("userObj");
			CommentObject commentObject=new CommentObject();
			commentObject.setDescription(strategyObject.getComment());
			commentObject.setUser(user);
			strategyService.addStrategyComment(strategyObject.getStrategyId(),commentObject);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result);

	}
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/showstrategycomments", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String showstrategycomments(@RequestBody StrategyObject strategyObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		List<CommentObject> comments=null;
		AjaxResponseBody result = new AjaxResponseBody();
		try {
			mapper = new ObjectMapper();
			User user=(User) sessionObj.getAttribute("userObj");
			strategyObject.setUserId(user.getUserId());
			comments=strategyService.showStrategyComments(strategyObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mapper.writeValueAsString(comments);
	}
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/strategysatisfaction", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String strategysatisfaction(@RequestBody StrategyObject strategyObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = new AjaxResponseBody();
		try {
			mapper = new ObjectMapper();
			User user=(User) sessionObj.getAttribute("userObj");
			strategyObject.setUserId(user.getUserId());
			StrategyObject strategyObject2=strategyService.getStrategySatisfactionById(strategyObject);
			if (strategyObject2!=null && strategyObject2.getSatisfaction()==strategyObject.getSatisfaction()) {
				result.setMsg("You already given same feedback");
			}
			else
			strategyService.addStrategySatisfaction(strategyObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mapper.writeValueAsString(result);
	}
	

	@RequestMapping(value="/backteststrategy", method=RequestMethod.POST)
	  public String editstrategy(@RequestBody StrategyObject strategyObject, HttpServletRequest request,Model model,HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = new AjaxResponseBody();
		List<ResultObject> resultObjects= new ArrayList<ResultObject>();
		try {
			mapper = new ObjectMapper();
			User user=(User) sessionObj.getAttribute("userObj");
			StockObject stockObjectLocal = new StockObject();
			stockObjectLocal.setTimeframeId(5);
			stockObjectLocal.setSymbol("ABB");
			stockObjectLocal.setName("ABB");
			StockObject stockObject = stockService.getStockDetailsByStockName(stockObjectLocal);
			List<StockObject> stockObjects = stockService.getLastNdaysData(539592, 100);
			List<Double> closeList = new ArrayList<Double>();
			for (StockObject stocks : stockObjects) {
				closeList.add(stocks.getClose());
			}
			Double[] resultObjArray = (Double[]) closeList.toArray(new Double[0]);
			resultObjects.add(computePerformance(strategyObject,ArrayUtils.toPrimitive(resultObjArray, Double.NaN),stockObjectLocal));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return mapper.writeValueAsString(resultObjects);
	}
	
	private ResultObject computePerformance(StrategyObject strategyObject, double[] close,StockObject stockObject) {
		// expressionObjects.add(expressionObject2);
		FormulaObject formulaObject = new FormulaObject();
		// formulaObject.setEntryLongFormula("EMA(5) > EMA(20) AND RSI(14) > 75");
		// formulaObject.setExitLongFormula("EMA(5) < EMA(20)");

		formulaObject.setEntryLongFormula(strategyObject.getEntryLong());
		formulaObject.setExitLongFormula(strategyObject.getExitLong());
		formulaObject.setEntryShortFormula(strategyObject.getEntryShort());
		formulaObject.setExitShortFormula(strategyObject.getExitShort());
		FormulaParser formulaParser = new FormulaParser();
		BacktestExpressionsObject backtestExpressionsObject = formulaParser.generateBackTestExpressions(formulaObject);

		ExecuteScreens executeScreens = new ExecuteScreens(backtestExpressionsObject.getEntryLongExpressionObject(),
				backtestExpressionsObject.getExitLongExpressionObject(), null, null,close);
		List<BackTestObject> backTestObjects = executeScreens.getBackTestResults();

		BackTestPerformance backTestPerformance = new BackTestPerformance();
		backTestPerformance.setPerLotRisk(75);
		backTestPerformance.setStoplossPercent(1);
		ResultObject resultObject = backTestPerformance.computePerformance(backTestObjects);
		resultObject.setStockName(stockObject.getName());
		resultObject.setStockSymbol(stockObject.getSymbol());
		System.out.println(
				"Buy Index\tBuy Price\tBuy Quantity\tSell Index\tSell Price\tSell Quantity\tProfit\tProfit Percent");
		if (resultObject.getTrades() == null) {
			System.out.println("No trades generated");
		} else {
			for (TradeObject tradeObject : resultObject.getTrades()) {

				System.out.println(tradeObject.getBuyIndex() + "\t" + tradeObject.getBuyPrice() + "\t"
						+ tradeObject.getBuyQuantity() + "\t" + tradeObject.getSellIndex() + "\t"
						+ tradeObject.getSellPrice() + "\t" + tradeObject.getSellQuantity() + "\t"
						+ tradeObject.getProfit() + "\t" + tradeObject.getProfitPercent());
			}

		}
		System.out.println("Total Number of Trades " + resultObject.getTotalNumberOfTrades());
		System.out.println("Total Number of Win " + resultObject.getTotalNumWin());
		System.out.println("Total Number of Loss " + resultObject.getTotalNumLoss());
		System.out.println("Profit " + resultObject.getProfit());
		System.out.println("Profit Percent " + resultObject.getProfitPercent());
		System.out.println("Largest Profit " + resultObject.getLargestProfit());
		System.out.println("Largest Loss " + resultObject.getLargestLoss());

		return resultObject;
	}

	
	

}
