package com.tp.stockquote.controller.rest;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.commons.httpclient.HttpHost;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rainmatter.kiteconnect.KiteConnect;
import com.rainmatter.kitehttp.SessionExpiryHook;
import com.rainmatter.kitehttp.exceptions.KiteException;
import com.rainmatter.models.UserModel;
import com.tp.stockquote.dto.LedgerObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.MacdObject;
import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.dto.PositionObject;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.TransactionObject;
import com.tp.stockquote.dto.jsonmodels.AjaxResponseBody;
import com.tp.stockquote.jsonviews.Views;
import com.tp.stockquote.service.PortfolioService;
import com.tp.stockquote.service.StockService;
import com.tp.stockquote.utility.IConstant;
import com.tp.stockquote.utility.KiteApi;
import com.tp.stockquote.utility.Util;

@RestController
public class PortfolioRestController {
	@Autowired
	private PortfolioService portfolioService;
	
	@Autowired
	private StockService stockService;

	

	@JsonView(Views.Public.class)
	@RequestMapping(value = "/getallportfolios", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String getallportfolios(@RequestBody PortfolioObject portfolioObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			User user = (User) sessionObj
					.getAttribute("userObj");
			portfolioObject.setUser(user);
			List<PortfolioObject> portfolioList = portfolioService
					.getAllPortfolio(portfolioObject);

			List<Object[]> portfolioArrs = new ArrayList<Object[]>();
			for (PortfolioObject portfolioObjectInner : portfolioList) {

				Object[] portfolioArr = {
						portfolioObjectInner.getPortfolioName(),
						portfolioObjectInner.getStockCount(),
						portfolioObjectInner.getProfit(),
						portfolioObjectInner.getNumberOfGain(),
						portfolioObjectInner.getNumberOfLoss(),
						Util.formatDatetoString(portfolioObjectInner.getCreateDate(), "dd-MM-YYYY HH:mm:ss") };
						portfolioArrs.add(portfolioArr);
			}
			result = new AjaxResponseBody();
			result.setCode("200");
			result.setTemplateArr(portfolioArrs.toArray());
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result.getTemplateArr());

	}
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/getpositions", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String getpositions(@RequestBody PortfolioObject portfolioObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			User user = (User) sessionObj
					.getAttribute("userObj");
			portfolioObject.setUser(user);
			if (portfolioObject.getPortfolioName().equals(IConstant.POSITIONS_TEXT)) {
			     	portfolioObject.setPortfolioId(3);
			     	portfolioObject.setPortfolioName("POSITIONS");
			}
			List<PositionObject> positionList=portfolioService.getPositions(portfolioObject);
			boolean includeHistory=portfolioObject.isIncludeHistory();
			Date fromDate=portfolioObject.getFromDate();
			Date toDate=portfolioObject.getToDate();
		 	portfolioObject=portfolioService.getPortfolio(portfolioObject);
		 	portfolioObject.setIncludeHistory(includeHistory);
		 	portfolioObject.setFromDate(fromDate);
		 	portfolioObject.setToDate(toDate);
		 	double stopLoss=Double.valueOf(portfolioObject.getAttrValueDisplay().get("Stoploss"));
		 	double target=Double.valueOf(portfolioObject.getAttrValueDisplay().get("Target Percent"));
			List<Object[]> portfolioArrs = new ArrayList<Object[]>();
			for (PositionObject positionObjectInner : positionList) {
				double avgAmt=positionObjectInner.getAvgAmount();
				double lastPrice=positionObjectInner.getStockObject().getLastPrice();
				double targetPrice=(double)avgAmt*(1+target/100);
				double stopLossPrice=(double)avgAmt*(1-stopLoss/100);
				MacdObject macd=portfolioService.getCurrentMacdValues(positionObjectInner.getStockObject());
				String flags=" ";
				if (lastPrice>=targetPrice) {
					flags+="TM,";
				}
				if(lastPrice<=stopLossPrice){
					flags+="SM,";
				}
				if(macd.getMacdValue()<macd.getSignalLineValue())
				{
					flags+="DMC,";
				}
				flags=flags.substring(0,flags.length()-1);
				
				boolean[] fiveDayPerformance={false,true,true,false,true};
				fiveDayPerformance=stockService.getLastFiveDayPerformance(positionObjectInner.getStockObject());
				if (includeHistory) {
					Object[] portfolioArr = {
							"",
							positionObjectInner.getStockObject().getSymbol(),
							positionObjectInner.getStockObject().getExchange(),
							positionObjectInner.getNetQuantity(),
							positionObjectInner.getAvgAmount(),
							positionObjectInner.getNetAmount(),
							positionObjectInner.getProfit().getAmount(),
							};
							portfolioArrs.add(portfolioArr);
				}
				else
				{
					Object[] portfolioArr = {
							"",
							positionObjectInner.getStockObject().getSymbol(),
							positionObjectInner.getStockObject().getExchange(),
							positionObjectInner.getStockObject().getLastPrice(),
							positionObjectInner.getNetQuantity(),
							positionObjectInner.getAvgAmount(),
							positionObjectInner.getNetAmount(),
							positionObjectInner.getProfit().getPercent(),
							positionObjectInner.getProfit().getAmount(),
							flags,
							fiveDayPerformance
							};
							portfolioArrs.add(portfolioArr);
				}
				
			}
			result = new AjaxResponseBody();
			result.setCode("200");
			result.setTemplateArr(portfolioArrs.toArray());
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result.getTemplateArr());

	}
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/addstocktoportfolio", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String addstocktoportfolio(@RequestBody List<TransactionObject> transactionObjectList,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			User user = (User) sessionObj
					.getAttribute("userObj");
			for (final TransactionObject transactionObject : transactionObjectList) {
				StockObject stockObject=new StockObject();
				stockObject.setSymbol(transactionObject.getStockCode());
				stockObject.setExchangeId(transactionObject.getExchangeId());
				stockObject.setTimeFrameId(5);
				stockObject=stockService.getStockDetailsByStockName(stockObject);
				transactionObject.setStockObject(stockObject);
				transactionObject.setUser(user);
				
				 /*try {
		                // First you should get request_token, public_token using kitconnect login and then use request_token, public_token, api_secret to make any kiteconnect api call.
		                // Initialize KiteSdk with your apiKey.
		                KiteConnect kiteconnect = new KiteConnect("csej439rz31ffnu7");

		                // set userId
		                kiteconnect.setUserId("RB1373");

		                //set proxy is optional, if you want to set proxy.
		                //kiteconnect.setProxy(new HttpHost("host_name"));

		                // Get login url
		                String url = kiteconnect.getLoginUrl();

		                // Set session expiry callback.
		                kiteconnect.registerHook(new SessionExpiryHook() {
		                    @Override
		                    public void sessionExpired() {
		                        System.out.println("session expired");
		                    }
		                });

		                // Set request token and public token which are obtained from login process.
		                UserModel userModel =  kiteconnect.requestAccessToken("csej439rz31ffnu7", "g9mgaizxa6p48a6axqr221q6awn4lz4z");
		                kiteconnect.setAccessToken(userModel.accessToken);
		                kiteconnect.setPublicToken(userModel.publicToken);

		                Map<String, Object> param = new HashMap<String, Object>(){
			            {
			                put("quantity", "1");
			                put("order_type", "MARKET");
			                put("tradingsymbol", transactionObject.getStockObject().getSymbol());
			                put("product", "CNC");
			                put("exchange", "NSE");
			                put("transaction_type", "BUY");
			                put("validity", "DAY");
			                put("price", "0");
			                put("trigger_price", "0");
			                put("tag", "myTag");   //tag is optional and it cannot be more than 8 characters and only alphanumeric is allowed
			            }
			        };
			        KiteApi kiteApi = new KiteApi();
	                kiteApi.placeOrder(kiteconnect,param,"amo");
				 }catch (KiteException e) {
					e.printStackTrace();
				}*/
			        
				portfolioService.addStockToPortfolio(transactionObject);
			}
				 
			
			result = new AjaxResponseBody();
			result.setCode("200");
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result.getTemplateArr());

	}
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/gettransactions", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String gettransactions(@RequestBody TransactionObject transactionObject,
			HttpSession sessionObj) throws JsonProcessingException, ParseException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			transactionObject.setUser(user);
			List<TransactionObject> transactionList=portfolioService.getTransactions(transactionObject);
			for (TransactionObject transactionObject2 : transactionList) {
				SimpleDateFormat sf = new SimpleDateFormat(
						"yyyy-MM-dd");
				transactionObject2.setCreateDateStr(sf.format(transactionObject2.getCreateDate()));
			}
			result = new AjaxResponseBody();
			result.setCode("200");
			result.setTemplateArr(transactionList.toArray());
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result.getTemplateArr());

	}
	
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/edittransactions", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String edittransactions(@RequestBody TransactionObject transactionObject,
			HttpSession sessionObj) throws JsonProcessingException {

		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			/*int tranId=Integer.parseInt(request.getParameter("tranId"));
			SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy HH:mm:ss");
	    	Date tranDate=sdf.parse(request.getParameter("tranDate"));
			int tranQty=Integer.parseInt(request.getParameter("tranQty"));
			double tranAmt=Double.parseDouble(request.getParameter("tranAmt"));*/
			portfolioService.editTransaction(transactionObject);
			
			result = new AjaxResponseBody();
			result.setCode("200");
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(result.getTemplateArr());

	}
	
	@JsonView(Views.Public.class)
	@RequestMapping(value = "/showledger", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String showledger(@RequestBody TransactionObject transactionObject,
			HttpSession sessionObj) throws JsonProcessingException {
		
		User user = (User) sessionObj.getAttribute("userObj");
		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		List<Object[]> ledgerArrs = new ArrayList<Object[]>();
		
		try {
			List<LedgerObject> ledgerList=portfolioService.getLedgerList(user);
			double debitAmount=0,creditAmount = 0,openingBalance=0;
			for (LedgerObject ledgerObject : ledgerList) {
				if(ledgerObject.getTransactionType()==1)
					debitAmount=ledgerObject.getAmount();
				else
					creditAmount=ledgerObject.getAmount();
				openingBalance+=debitAmount+creditAmount;
				Object[] ledgerArr = {ledgerObject.getId(),ledgerObject.getDescription(),debitAmount,creditAmount,openingBalance};
				ledgerArrs.add(ledgerArr);
			}
			result = new AjaxResponseBody();
			result.setCode("200");
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(ledgerArrs.toArray());

	}
	
	
	
	
	
}
