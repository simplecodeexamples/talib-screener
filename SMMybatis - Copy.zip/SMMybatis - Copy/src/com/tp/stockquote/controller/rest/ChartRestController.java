package com.tp.stockquote.controller.rest;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JsonView;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tp.stockquote.dto.AdxObject;
import com.tp.stockquote.dto.ChartObject;
import com.tp.stockquote.dto.CommentObject;
import com.tp.stockquote.dto.EmaObject;
import com.tp.stockquote.dto.MacdObject;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.jsonmodels.AjaxResponseBody;
import com.tp.stockquote.jsonviews.Views;
import com.tp.stockquote.service.ChartService;
import com.tp.stockquote.service.StockService;
import com.tp.stockquote.service.StrategyService;

@RestController
public class ChartRestController {
	@Autowired
	private ChartService chartService;
	
	@Autowired
	private StockService stockService;

	@JsonView(Views.Public.class)
	@RequestMapping(value = "/showchart", headers = "Accept=*/*", produces = "application/json")
	public @ResponseBody
	String showchart(@RequestBody StockObject stockObject,
			HttpSession sessionObj) throws JsonProcessingException {
		
		List<Object[]> objList=new ArrayList<Object[]>();
		ObjectMapper mapper = null;
		AjaxResponseBody result = null;
		try {
			stockObject.setTimeFrameId(5);
			stockObject=stockService.getStockDetailsByStockName(stockObject);
			
			EmaObject emaObj1=new EmaObject();
	    	emaObj1.setDaySpan(200);
	    	emaObj1.setPeriod(12);
	    	emaObj1.setTimeframeId(5);
	    	emaObj1.setStockid(stockObject.getStockid());
	    	
	    	EmaObject emaObj2=new EmaObject();
	    	emaObj2.setDaySpan(200);
	    	emaObj2.setPeriod(26);
	    	emaObj2.setTimeframeId(5);
	    	emaObj2.setStockid(stockObject.getStockid());
	    	
	    	
	    	
	    	MacdObject macd=new MacdObject();
	    	macd.setShortPeriod(12);
	    	macd.setLongPeriod(26);
	    	macd.setSignalPeriod(9);
	    	macd.setDaySpan(200);
	    	macd.setTimeframeId(5);
	    	macd.setStockid(stockObject.getStockid());
	    	
	    	
	    	stockObject.setMacd(macd);
	    	
			chartService.getCurrentMacdValues(stockObject);
			List<AdxObject> adx=chartService.getCurrentAdxValues(stockObject);
			
			List<ChartObject> listChart = chartService.getCharts(stockObject);
			int count=0;
			int macdcount=0;
			int emacount=0;
			int adxcount=0;
			for (ChartObject chartObject : listChart) {
				double macdValue=0;
				double emaValue=0;
				double adxValue=0;
				if (count>=24 && stockObject.getMacd().getLast5DayMacdList()!=null && stockObject.getMacd().getLast5DayMacdList().size()>0 && macdcount<stockObject.getMacd().getLast5DayMacdList().size()) {
					List<Double> macdList=stockObject.getMacd().getLast5DayMacdList();
					macdValue=macdList.get(macdcount++).doubleValue();
				}
				if (count>=32 && stockObject.getMacd().getLast5DaySignalList()!=null && stockObject.getMacd().getLast5DaySignalList().size()>0 && emacount<stockObject.getMacd().getLast5DaySignalList().size()) {
					List<Double> signalList=stockObject.getMacd().getLast5DaySignalList();
					emaValue=signalList.get(emacount++).doubleValue();
				}
				if (count>=26 && adx.size()>0 && adxcount<adx.size()) {
					adxValue=adx.get(adxcount++).getAdxValue().doubleValue();
				}
				Calendar currentTime = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
				currentTime.setTimeInMillis(chartObject.getCreateDate().getTimezoneOffset());
				Object[] strArr={chartObject.getCreateDate().getTime()+(24*60*60*1000),chartObject.getLow(),chartObject.getOpen(),chartObject.getClose(),chartObject.getHigh(),chartObject.getVolume(),macdValue,emaValue,adxValue};
				objList.add(strArr);
				count++;
			}
			result = new AjaxResponseBody();
			result.setCode("200");
			if (objList != null) {
				result.setTemplateArr(objList.toArray());
			}
			mapper = new ObjectMapper();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return mapper.writeValueAsString(objList.toArray());

	}

}
