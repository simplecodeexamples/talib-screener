package com.tp.stockquote.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.tp.stockquote.dto.BalanceObject;
import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.dto.PositionObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.service.BalanceService;
import com.tp.stockquote.service.PortfolioService;

@Controller
public class BalanceController {
	
	@Autowired
	private BalanceService balanceService;
	
	@Autowired
	@Qualifier("balanceValidator")
	private Validator validator;
	
	@InitBinder("balance")
	private void initBinder(WebDataBinder binder) {
			binder.setValidator(validator);
	}
	
	@Autowired
	PortfolioService portfolioService;
	
	  @RequestMapping(value="/balanceshow", method=RequestMethod.GET)
	  public String balanceshow(Model model,HttpSession session) {
		  User user=(User) session.getAttribute("userObj");
		  try {
				  BalanceObject balanceObject=balanceService.getBalance(user);
			      PortfolioObject portfolioObject=new PortfolioObject();
			      portfolioObject.setPortfolioName("CURRENT HOLDING");
			      portfolioObject.setUser(user);
			      portfolioObject=portfolioService.getPortfolio(portfolioObject);
			      List<PositionObject> positionObjects=null;
			      double currentProfit=0;
			      double currentProfitPercent=0;
			      if (portfolioObject!=null) {
			    	  positionObjects=portfolioService.getPositions(portfolioObject);
			    	  for (PositionObject positionObject : positionObjects) {
				    	  currentProfit+=positionObject.getProfit().getAmount();
				      }
			    	  currentProfitPercent=(double)currentProfit*100/balanceObject.getBalance();
			      }
			      balanceObject.setCurrentProfit(currentProfit);
			      balanceObject.setCurrentProfitPercent(currentProfitPercent);
			      model.addAttribute("user", user);
			      model.addAttribute("balanceObject", balanceObject);
			} catch (Exception e) {
				e.printStackTrace();
			}
	      return "balanceshow";
	  }
	  @RequestMapping(value="/addbalance", method=RequestMethod.GET)
	  public String addbalance(Model model,HttpSession session) {
		BalanceObject balance=new BalanceObject();
		model.addAttribute("balance", balance);
		return "balanceadd";
	  }
	  @RequestMapping(value="/addbalance", method=RequestMethod.POST)
	  public ModelAndView addbalance(@ModelAttribute("balance") @Valid BalanceObject balance,
				BindingResult result,Model model,HttpServletRequest request, Errors errors,HttpSession session) {
		  User user=(User) session.getAttribute("userObj");
		  balance.setUserObject(user);
		  try {
			  if (!result.hasErrors()) {
					balanceService.addBalance(balance);
					user.setBalance(user.getBalance()+balance.getBalance());
					request.getSession().setAttribute("userObj", user);
					model.addAttribute("successMsg", "Balance Added Successfully");
				}
		} catch (Exception e) {
			e.printStackTrace();
		}
		  return new ModelAndView("balanceadd", "balance", balance);
	  }

}
