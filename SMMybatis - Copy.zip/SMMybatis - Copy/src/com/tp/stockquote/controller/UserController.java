package com.tp.stockquote.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.tp.stockquote.dto.User;
import com.tp.stockquote.service.UserService;
import com.tp.stockquote.utility.PasswordEncryption;
import com.tp.stockquote.validator.EmailExistsException;

@Controller
@SessionAttributes("user")
public class UserController {

	@Autowired
	private UserService userService;
	
	@Autowired
	@Qualifier("userValidator")
	private Validator validator;

	@InitBinder("user")
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	@RequestMapping(value = "/signup", method = RequestMethod.GET)
	public String signup(Model model) {

		User user = new User();		model.addAttribute("user", user);
		return "signup";
	}

	@RequestMapping(value = "/signup", method = RequestMethod.POST)
	public ModelAndView signup(@ModelAttribute("user") @Valid User user,
			BindingResult result,  Model model,WebRequest request, Errors errors) {
		User registered = null;
		user.setPassword(PasswordEncryption.encrypt(user.getPassword()));
		if (!result.hasErrors()) {
			registered=createUserAccount(user, result); 
		}
		if (registered != null) {
			result.rejectValue("emailAddress", "message.regError");
		}
		if (result.hasErrors()) {
	        return new ModelAndView("signup", "user", user);
	    } 
	    else {
	        return new ModelAndView("login", "user", user);
	    }
	

	}
	
	private User createUserAccount(User user, BindingResult result) {
	    User registered = null;
	    registered=userService.getUserByLogin(user);
	    try {
	    	if (registered != null) {
				throw new EmailExistsException(
						"There is an account with that email adress: "
								+ user.getEmailAddress());
			}
	    	else
	    	{
	    		userService.insertUser(user);
	    	}
	    } catch (EmailExistsException e) {
	        return null;
	    }    
	    return registered;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model) {
		User user = new User();
		model.addAttribute("user", user);
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(Model model, HttpSession session) {
		session.removeAttribute("user");
		User user = new User();
		model.addAttribute("user", user);
		return "logoutsuccess";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(@ModelAttribute("user") User user,
			HttpServletRequest request, Model model) {
		User userObj = new User();
		userObj.setUserId(6);
		userObj.setEmailAddress(user.getUserName());
		request.getSession().setAttribute("userObj", userObj);
		/*try {
			user.setPassword(PasswordEncryption.encrypt(user.getPassword()));
			user.setEmailAddress(user.getUserName());
			userObj = userService.getUserByLogin(user);

		} catch (Exception e) {
			e.printStackTrace();
		}
		if (userObj != null) {
			request.getSession().setAttribute("userObj", userObj);
			return "loginsuccess";
		} else {
			model.addAttribute("message", "User creadentials are not correct");
			return "failure";
		}*/
		return "loginsuccess";

	}

}
