package com.tp.stockquote.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.tp.stockquote.service.WatchListService;

public class WatchListController {
	
	@Autowired
	private WatchListService watchListService;

}
