package com.tp.stockquote.controller;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tp.stockquote.dto.EarlyMorningFileUpload;
import com.tp.stockquote.dto.FileUpload;
import com.tp.stockquote.dto.LedgerObject;
import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.TransactionObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.PortfolioObject;
import com.tp.stockquote.dto.StockGroup;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.TradingMode;
import com.tp.stockquote.service.BalanceService;
import com.tp.stockquote.service.PortfolioService;
import com.tp.stockquote.service.StockService;
import com.tp.stockquote.service.StrategyService;
import com.tp.stockquote.utility.IConstant;
import com.tp.stockquote.utility.TechformatExcel;

@Controller
public class PortfolioController {

	@Autowired
	private PortfolioService portfolioService;

	@Autowired
	private StrategyService strategyService;

	@Autowired
	private BalanceService balanceService;

	@Autowired
	private StockService stockService;

	@Autowired
	@Qualifier("fileUploadValidator")
	private Validator fileUploadValidator ;

	@InitBinder("fileUpload")
	private void initFileBinder(WebDataBinder binder) {
		binder.setValidator(fileUploadValidator );
	}
	
	@Autowired
	@Qualifier("portfolioValidator")
	private Validator portfolioValidator;

	@InitBinder("portfolioObject")
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(portfolioValidator);
	}

	@RequestMapping(value = "/createportfolio", method = RequestMethod.GET)
	public ModelAndView createportfolio(Model model) {

		PortfolioObject portfolioObject = new PortfolioObject();
		TreeMap<String, String> portfolioAttrMap = new TreeMap<String, String>();
		portfolioAttrMap.put("Stoploss Percent", "");
		portfolioAttrMap.put("Target Percent", "");
		portfolioAttrMap.put("Trailing Stoploss Percent", "");
		portfolioObject.setAttrValueDisplay(portfolioAttrMap);
		return new ModelAndView("createportfolio", "portfolioObject",
				portfolioObject);
	}

	@RequestMapping(value = "/createportfolio", method = RequestMethod.POST)
	public ModelAndView createportfolio(
			@ModelAttribute("portfolioObject") @Valid PortfolioObject portfolioObject,
			BindingResult result, Model model, WebRequest request,
			Errors errors, HttpSession sessionObj) {
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			portfolioObject.setUser(user);
			int count = 1;
			Map<Integer, String> portfolioAttr = new HashMap<Integer, String>();
			if (!result.hasErrors()) {
				for (Entry<String, String> portfolioAttrTemp : portfolioObject
						.getAttrValueDisplay().entrySet()) {
					portfolioAttr.put(count++, portfolioAttrTemp.getValue());
				}
				portfolioObject.setAttrValueMap(portfolioAttr);
				PortfolioObject portfolio = portfolioService
						.getPortfolio(portfolioObject);
				if (portfolio != null) {
					model.addAttribute("failureMsg", "Portfolio Already exists");
					return new ModelAndView("failure", "portfolioObject",
							portfolioObject);
				} else {

					portfolioService.createPortfolio(portfolioObject);
					model.addAttribute("succesMsg",
							"Portfolio Added successfully");

				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ModelAndView("createportfolio", "portfolioObject",
				portfolioObject);
	}

	@RequestMapping(value = "/editportfolioattributes", method = RequestMethod.POST)
	public String editportfolioattributes(
			@ModelAttribute("portfolioObject") PortfolioObject portfolioObject,
			Model model, HttpSession sessionObj,
			RedirectAttributes redirectAttributes) {
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			portfolioObject.setUser(user);
			int count = 1;
			Map<Integer, String> portfolioAttr = new HashMap<Integer, String>();
			for (Entry<String, String> portfolioAttrTemp : portfolioObject
					.getAttrValueDisplay().entrySet()) {
				portfolioAttr.put(count++, portfolioAttrTemp.getValue());
			}
			portfolioObject.setAttrValueMap(portfolioAttr);
			portfolioObject = portfolioService.getPortfolio(portfolioObject);
			if (portfolioObject != null) {
				portfolioService.createOrEditPortfolioAttributes(portfolioAttr,
						portfolioObject.getPortfolioId());
				model.addAttribute("succesMsg", "Portfolio Edited successfully");
			} else {
				model.addAttribute("failureMsg", "Could not edit Portfolio");
				return "failure";

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		redirectAttributes
				.addFlashAttribute("portfolioObject", portfolioObject);
		return "redirect:getpositions.html";
	}

	@RequestMapping(value = "/getpositions", method = RequestMethod.GET)
	public String getpositions(
			@ModelAttribute("portfolioObject") PortfolioObject portfolioObject,
			Model model, HttpSession sessionObj) {
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			double amountAllocatedToTrading;
			List<TradingMode> modes = stockService.getTradingModes(user);
			if (portfolioObject.getPortfolioName().equals(IConstant.CURRENT_HOLDING_TEXT)) {
				portfolioObject.setModeId(1);
			}
			else if(portfolioObject.getPortfolioName().equals(IConstant.POSITIONS_TEXT))
			{
				portfolioObject.setModeId(0);
			}
			portfolioObject.setUser(user);
			amountAllocatedToTrading = (double) (user
					.getModebalance() * modes.get(portfolioObject.getModeId())
					.getAllocationPercentage()) / 100;

			List<StockGroup> stockGroups = stockService.getStockGroups(user
					.getUserId(), modes.get(portfolioObject.getModeId())
					.getModeid());

			int totalHoldingCapacity = 0;

			portfolioObject = portfolioService.getPortfolio(portfolioObject);

			if (portfolioObject.getAttrValueDisplay() != null
					&& portfolioObject.getAttrValueDisplay().get(
							"Maximum Lots Allowed") != null)
				totalHoldingCapacity = Integer.valueOf(portfolioObject
						.getAttrValueDisplay().get("Maximum Lots Allowed"));

			for (StockGroup stockGroup : stockGroups) {
				double amtQty;
				amtQty = (double) (amountAllocatedToTrading*stockGroup.getAllocationPercentage() / 100);
				if (portfolioObject.getPortfolioName().equals(IConstant.POSITIONS_TEXT)) {
					//intraday risk amount is percentage of risk you want to take for day trading
					//suppose you have 6000 rs for day trading if intraday risk percent is 10 then 600 will total risk
					amtQty = (amountAllocatedToTrading*IConstant.INTRADAY_RISK)/100;
				}
				portfolioObject.setGroupId(stockGroup.getGroupid());
				int quantity = portfolioService
						.getGroupCountByPortfolio(portfolioObject);
				double perLotValue = (double) amtQty
						/ stockGroup.getAllocationQuantity();
				stockGroup.setPerLotValue(perLotValue);
				stockGroup.setRemQuantity(stockGroup.getAllocationQuantity()
						- quantity);
			}

			model.addAttribute("amountAllocatedToSwingTrading",
					amountAllocatedToTrading);

			portfolioObject = portfolioService.getPortfolio(portfolioObject);
			List<StrategyObject> strategyList = new ArrayList<StrategyObject>();
			strategyList = strategyService.getAllStrategies(user);

			model.addAttribute("strategyList", strategyList);
			model.addAttribute("portfolioId", portfolioObject.getPortfolioId());
			model.addAttribute("portfolioObject", portfolioObject);
			model.addAttribute("stockGroups", new ObjectMapper()
					.writeValueAsString(stockGroups.toArray()));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "positionlist";
	}

	@RequestMapping(value = "/getallportfolios", method = RequestMethod.GET)
	public String getallportfolios(
			@ModelAttribute("portfolioObject") PortfolioObject portfolioObject,
			Model model, HttpSession sessionObj) {
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			portfolioObject.setUser(user);
			List<PortfolioObject> portfolioList = portfolioService
					.getAllPortfolio(portfolioObject);
			model.addAttribute("portfolioList", portfolioList);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "portfoliolist";
	}

	@RequestMapping(value = "/showreport", method = RequestMethod.GET)
	public String showreport(
			@ModelAttribute("portfolioObject") PortfolioObject portfolioObject,
			Model model, HttpSession sessionObj) {
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			portfolioObject.setUser(user);
			List<PortfolioObject> portfolioList = portfolioService
					.getAllPortfolio(portfolioObject);
			model.addAttribute("portfolioList", portfolioList);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "showreport";
	}

	@RequestMapping(value = "/showledger", method = RequestMethod.GET)
	public String showledger(
			@ModelAttribute("ledgerObject") LedgerObject ledgerObject,
			Model model, HttpSession sessionObj) {
		return "showledger";
	}

	@RequestMapping(value = "/smartportfolio", method = RequestMethod.GET)
	public String smartportfolio(
			@ModelAttribute("fileUpload") FileUpload fileUpload,
			Model model, HttpSession sessionObj) {
		try {
			PortfolioObject portfolioObject=new PortfolioObject();
			portfolioObject.setPortfolioId(fileUpload.getPortfolioId());
			User user = (User) sessionObj.getAttribute("userObj");
			portfolioObject.setUser(user);
			List<PortfolioObject> portfolioList = portfolioService
					.getAllPortfolio(portfolioObject);
			model.addAttribute("portfolioList", portfolioList);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "smartportfolio";
	}
	
	@RequestMapping(value = "/smartportfolio", method = RequestMethod.POST)
	public String smartportfolio(
			@ModelAttribute("fileUpload") @Valid FileUpload fileUpload,
			Model model, HttpSession sessionObj,
			RedirectAttributes redirectAttributes) throws IOException {
		InputStream inputStream = null;
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			MultipartFile multipartFile = fileUpload.getFile();

			String fileName="";

			if(multipartFile!=null){
				fileName = multipartFile.getOriginalFilename();
				inputStream = multipartFile.getInputStream();
		        String extension=getFileExtension(fileName);
		        List<TransactionObject> transactionObjects = TechformatExcel.readStockListFromSheet(inputStream,extension);
		        for (TransactionObject transactionObject : transactionObjects) {
		        	transactionObject.setUser(user);
		        	transactionObject.setPortfolioId(fileUpload.getPortfolioId());
		        	
				}
		        TransactionObject transactionObject=new TransactionObject();
		        transactionObject.setPortfolioId(fileUpload.getPortfolioId());
	        	transactionObject.setUser(user);
	        	transactionObject.setTransactionObjects(transactionObjects);
		        model.addAttribute("transactionObject", transactionObject);
		} 
		
	}
		catch (Exception e) {
			e.printStackTrace();
		} 
		finally {
	        if (inputStream != null) {
		          inputStream.close();
		        }
		      }
		return "smartportfolioview";
	}

	private String getFileExtension(String formFile){
	    try {
	        return formFile.substring(formFile.lastIndexOf(".") + 1);
	    } catch (Exception e) {
	        return "";
	    }
	}
	
	@RequestMapping(value = "/smartportfolioview", method = RequestMethod.POST)
	public String smartportfolioview(
			@ModelAttribute("transactionObject") TransactionObject transactionObject,
			Model model, HttpSession sessionObj,
			RedirectAttributes redirectAttributes) throws IOException {
		try {
			for (TransactionObject transactionObject2 : transactionObject.getTransactionObjects()) {
				portfolioService.addStockToPortfolio(transactionObject2);
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		} 
		return "smartportfolio";
	}
	
	@RequestMapping(value = "/smartportfolioadd", method = RequestMethod.POST)
	public String smartportfolioadd(
			@ModelAttribute("transactionObject") TransactionObject transactionObject,
			Model model, HttpSession sessionObj,
			RedirectAttributes redirectAttributes) throws IOException {
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			for (TransactionObject transactionObject2 : transactionObject.getTransactionObjects()) {
				transactionObject2.setUser(user);
				transactionObject2.getStockObject().setTimeFrameId(5);
	        	StockObject stockObject=stockService.getStockDetailsByStockName(transactionObject2.getStockObject());
	        	stockObject.setExchangeId(transactionObject2.getStockObject().getExchangeId());
	        	transactionObject2.setStockObject(stockObject);
				portfolioService.addStockToPortfolio(transactionObject2);
			}
			model.addAttribute("succesMsg", "Stocks added successfully");
		}
		catch (Exception e) {
			e.printStackTrace();
		} 
		return "smartportfolioview";
	}
	
	@RequestMapping(value = "/earlymorningbuysell", method = RequestMethod.GET)
	public String earlymorningbuysell(
			@ModelAttribute("earlyMorningFileUpload") EarlyMorningFileUpload earlyMorningFileUpload,
			Model model, HttpSession sessionObj) {
		try {
			PortfolioObject portfolioObject=new PortfolioObject();
			portfolioObject.setPortfolioId(earlyMorningFileUpload.getPortfolioId());
			User user = (User) sessionObj.getAttribute("userObj");
			portfolioObject.setUser(user);
			List<PortfolioObject> portfolioList = portfolioService
					.getAllPortfolio(portfolioObject);
			model.addAttribute("portfolioList", portfolioList);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return "earlymorning";
	}
	
	
	@RequestMapping(value = "/earlymorningbuysell", method = RequestMethod.POST)
	public String earlymorningbuysell(
			@ModelAttribute("earlyMorningFileUpload")  EarlyMorningFileUpload earlyMorningFileUpload,
			Model model, HttpSession sessionObj,
			RedirectAttributes redirectAttributes) throws IOException {
		
		InputStream inputStreamNifty50 = null;
		InputStream inputStreamNiftyNext50 = null;
		InputStream inputStreamNiftyMidcap50 = null;
		
		MultipartFile fileNifty50 = null;
		MultipartFile fileNiftyNext50 = null;
		MultipartFile fileNiftyMidcap50 = null;


		try {
			inputStreamNifty50 = earlyMorningFileUpload.getNifty50().getInputStream();
			inputStreamNiftyNext50 = earlyMorningFileUpload.getNiftyNext50().getInputStream();
			inputStreamNiftyMidcap50 = earlyMorningFileUpload.getNiftyMidcap50().getInputStream();
			
			String fileName = earlyMorningFileUpload.getNifty50().getOriginalFilename();
			String extensionNifty50 = getFileExtension(fileName);
			
			List<StockObject> stockNifty50 = TechformatExcel
					.readStockListFromNSEIndia(inputStreamNifty50,
							extensionNifty50);
			List<StockObject> stockNiftyNext50 = TechformatExcel
					.readStockListFromNSEIndia(inputStreamNiftyNext50,
							extensionNifty50);
			List<StockObject> stockeNiftyMidcap50 = TechformatExcel
					.readStockListFromNSEIndia(inputStreamNiftyMidcap50,
							extensionNifty50);
			List<StockObject> consolidateStocks=new ArrayList<StockObject>();
			consolidateStocks.addAll(stockNifty50);
			consolidateStocks.addAll(stockNiftyNext50);
			consolidateStocks.addAll(stockeNiftyMidcap50);
			
			
			List<StockObject> selectedStocks=strategyService.generateBuySellDate(consolidateStocks);
			
			Collections.sort(selectedStocks,new StockObject());
			
			ArrayList<StockObject> finalSelection=null;
			int size=0;
			
			if (selectedStocks.size()>7) {
				finalSelection = new ArrayList<StockObject>(selectedStocks.subList(0, 7));
				size=7;
			}
			else
			{
				finalSelection=(ArrayList<StockObject>) selectedStocks;
				size=selectedStocks.size();
			}
		
			User user = (User) sessionObj.getAttribute("userObj");
			List<TransactionObject> transactionObjects= strategyService.setQuantities(finalSelection,size,user);
			TransactionObject transactionObject=new TransactionObject();
			transactionObject.setTransactionObjects(transactionObjects);
			model.addAttribute("transactionObject", transactionObject);
			

		} catch (Exception e) {
			e.printStackTrace();

		}
		return "smartportfolioview";
	}



}
