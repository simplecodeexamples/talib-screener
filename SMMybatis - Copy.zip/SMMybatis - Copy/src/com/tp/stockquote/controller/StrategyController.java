package com.tp.stockquote.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.ModelAndView;

import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.StrategyObject;
import com.tp.stockquote.dto.User;
import com.tp.stockquote.service.StrategyService;
import com.tp.stockquote.service.UserService;

@Controller
public class StrategyController {

	@Autowired
	private StrategyService strategyService;

	@Autowired
	private UserService userService;

	@Autowired
	@Qualifier("strategyValidator")
	private Validator validator;

	@InitBinder("strategyObject")
	private void initBinder(WebDataBinder binder) {
		binder.setValidator(validator);
	}

	@RequestMapping(value = "/showmystrategies", method = RequestMethod.GET)
	public String showmystrategies(@RequestParam("status") String status, @RequestParam("pageNum") int pageNum,
			@RequestParam("sortBy") String sortBy, Model model, HttpSession sessionObj) {
		List<StrategyObject> strategyList = null;
		int lastIndex = 100;
		try {

			User user = (User) sessionObj.getAttribute("userObj");
			lastIndex = strategyService.getAllStrategies(user).size();
			strategyList = strategyService.getStrategiesByPageNumber(user, pageNum, sortBy, lastIndex, status);
			for (StrategyObject strategyObject : strategyList) {
				User userObj = userService.getUserByuserId(strategyObject.getUserId());
				strategyObject.setCreatorName(userObj.getFirstName() + " " + userObj.getLastName());
				strategyObject.setStrategyType(status);
				int likeCount = strategyService.getSatisfactionCount(strategyObject, 1);
				int disLikeCount = strategyService.getSatisfactionCount(strategyObject, 2);
				strategyObject.setLikes(likeCount);
				strategyObject.setDisLikes(disLikeCount);
			}
			model.addAttribute("strategyList", strategyList);
			model.addAttribute("curpage", pageNum);
			model.addAttribute("lastIndex", lastIndex / 5);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "strategylist";

	}

	@RequestMapping(value = "/showmystrategiesbyname", method = RequestMethod.POST)
	public String showmystrategies(@RequestParam("description") String description, Model model,
			HttpSession sessionObj) {
		List<StrategyObject> strategyList = null;
		int lastIndex = 100;
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			strategyList = strategyService.getStrategyDetailsByStrategyName(description);
			lastIndex = strategyService.getAllStrategies(user).size();
			model.addAttribute("strategyList", strategyList);
			model.addAttribute("curpage", 1);
			model.addAttribute("lastIndex", 1);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "strategylist";

	}

	@RequestMapping(value = "/createstrategy", method = RequestMethod.GET)
	public String createstrategy(Model model) {
		StrategyObject strategyObject = new StrategyObject();
		model.addAttribute("strategyObject", strategyObject);
		model.addAttribute("mode", "createstrategy");
		return "createstrategy";
	}

	@RequestMapping(value = "/createstrategy", method = RequestMethod.POST)
	public ModelAndView createstrategy(@ModelAttribute("strategyObject") @Valid StrategyObject strategyObject,
			BindingResult result, Model model, WebRequest request, Errors errors, HttpSession sessionObj) {
		try {
			User user = (User) sessionObj.getAttribute("userObj");
			if (!result.hasErrors()) {
				strategyObject.setUserId(user.getUserId());
				strategyService.addStrategy(strategyObject);
				model.addAttribute("succesMsg", "Successfully added strategy");
			}
		} catch (Exception e) {
			model.addAttribute("failureMsg", "Failed to add strategy");
			e.printStackTrace();
		}
		return new ModelAndView("createstrategy", "strategyObject", strategyObject);

	}

	@RequestMapping(value = "/editstrategy", method = RequestMethod.GET)
	public String editstrategy(@RequestParam("strategyId") int strategyId, Model model) {
		StrategyObject strategyObject = new StrategyObject();
		strategyObject.setStrategyId(strategyId);
		strategyObject = strategyService.getStrategyById(strategyObject);
		model.addAttribute("mode", "editstrategy");
		model.addAttribute("strategyObject", strategyObject);
		return "editstrategy";
	}

	@RequestMapping(value="/editstrategy", method=RequestMethod.POST)
	  public String editstrategy(@ModelAttribute("strategyObject") StrategyObject strategyObject,HttpServletRequest request,Model model,HttpSession sessionObj) {
		  try {
			  User user=(User) sessionObj.getAttribute("userObj");
			  strategyObject.setUserId(user.getUserId());
			  strategyService.editStrategy(strategyObject);
			  model.addAttribute("succesMsg", "Successfully edited strategy");
		} catch (Exception e) {
			model.addAttribute("succesMsg", "Failed to edit strategy");
			e.printStackTrace();
		}
		  return "editstrategy";
		  
	  }


}
