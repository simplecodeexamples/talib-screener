package com.tp.stockquote.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.tp.stockquote.dto.User;
import com.tp.stockquote.dto.StockGroup;
import com.tp.stockquote.dto.TradingMode;
import com.tp.stockquote.service.StockService;
import com.tp.stockquote.utility.Util;

@Controller
public class StockController {

	@Autowired
	private StockService stockService;

	@RequestMapping(value = "/createmode", method = RequestMethod.GET)
	public String createmode(Model model) {
		TradingMode tradingModeObject = new TradingMode();
		model.addAttribute("tradingModeObject", tradingModeObject);
		return "createmode";
	}

	@RequestMapping(value = "/createmode", method = RequestMethod.POST)
	public String createmode(
			@ModelAttribute("tradingModeObject") TradingMode tradingModeObject,
			HttpSession sessionObj, Model model) {
		try {
			User userObj=(User) sessionObj.getAttribute("userObj");
			tradingModeObject.setUserid(userObj.getUserId());
			stockService.addTradingMode(tradingModeObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "createmode";
	}

	@RequestMapping(value = "/editmode", method = RequestMethod.GET)
	public String editmode(Model model) {
		TradingMode tradingModeObject = new TradingMode();
		model.addAttribute("tradingModeObject", tradingModeObject);
		return "tradingModeObject";
	}

	@RequestMapping(value = "/editmode", method = RequestMethod.POST)
	public String editmode(
			@ModelAttribute("tradingModeObject") TradingMode tradingModeObject,
			HttpSession sessionObj, Model model) {
		try {
			User userObj=(User) sessionObj.getAttribute("userObj");
			tradingModeObject.setUserid(userObj.getUserId());
			stockService.editTradingMode(tradingModeObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "tradingModeObject";
	}
	
	@RequestMapping(value = "/deletemode", method = RequestMethod.GET)
	public String deletemode(Model model) {
		TradingMode tradingModeObject = new TradingMode();
		model.addAttribute("tradingModeObject", tradingModeObject);
		return "tradingModeObject";
	}

	@RequestMapping(value = "/deletemode", method = RequestMethod.POST)
	public String deletemode(
			@ModelAttribute("tradingModeObject") TradingMode tradingModeObject,
			HttpSession sessionObj, Model model) {
		try {
			User userObj=(User) sessionObj.getAttribute("userObj");
			tradingModeObject.setUserid(userObj.getUserId());
			stockService.deleteTradingMode(tradingModeObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "tradingModeObject";
	}

	@RequestMapping(value = "/modewiseallocation", method = RequestMethod.GET)
	public String modewiseallocation(Model model,HttpSession sessionObj) {
		TradingMode tradingModeObject = new TradingMode();
		User userObj=(User) sessionObj.getAttribute("userObj");
		List<TradingMode> tradingModes=stockService.getTradingModes(userObj);
		TreeMap<String, Double> tradingModeMap=new TreeMap<String, Double>();
		for (TradingMode tradingModeInner : tradingModes) {
			tradingModeMap.put(tradingModeInner.getName(), tradingModeInner.getAllocationPercentage());
		}
		tradingModeObject.setTradingModeMap(tradingModeMap);
		model.addAttribute("tradingModeObject", tradingModeObject);
		return "addtradingmodevalues";
	}

	@RequestMapping(value="/modewiseallocation", method=RequestMethod.POST)
	  public String modewiseallocation(@ModelAttribute("user") TradingMode tradingModeObject,HttpSession sessionObj ,Model model) {
			try {
				  User userObj=(User) sessionObj.getAttribute("userObj");
				  for (Entry<String, Double> tradingIterator : tradingModeObject.getTradingModeMap().entrySet()) {
					tradingModeObject.setName(tradingIterator.getKey());
					tradingModeObject.setUserid(userObj.getUserId());
					tradingModeObject=stockService.getTradingModeByName(tradingModeObject);
					tradingModeObject.setAllocationPercentage(tradingIterator.getValue());
					stockService.editTradingModeValue(tradingModeObject);
				  }
			} catch (Exception e) {
				  model.addAttribute("successMsg","Modewise allocation done");

				e.printStackTrace();
			}
			  model.addAttribute("successMsg","Modewise allocation done");

	      return "addtradingmodevalues";
	  }
	
	@RequestMapping(value = "/getgroupwiseallocation", method = RequestMethod.GET)
	public String getgroupwiseallocation(@RequestParam("modeid") int modeid,Model model,HttpSession sessionObj) {
		try {
			StockGroup stockGroupObject = new StockGroup();
			User userObj=(User) sessionObj.getAttribute("userObj");
			List<StockGroup> stockGroups=stockService.getStockGroups(userObj.getUserId(),modeid);
			List<TradingMode> tradingModes=stockService.getTradingModes(userObj);

			TreeMap<String, Double> stockGroupMap=new TreeMap<String, Double>();
			TreeMap<String, Integer> stockGroupQuantityMap=new TreeMap<String, Integer>();
			
			for (StockGroup stockGroupInner : stockGroups) {
				stockGroupMap.put(stockGroupInner.getName(), stockGroupInner.getAllocationPercentage());
				stockGroupQuantityMap.put(stockGroupInner.getName(), stockGroupInner.getAllocationQuantity());
			}
			stockGroupObject.setStockGroupMap(stockGroupMap);
			stockGroupObject.setStockGroupQuantityMap(stockGroupQuantityMap);
			model.addAttribute("modeid", modeid);
			model.addAttribute("tradingModes", tradingModes);
			model.addAttribute("stockGroupObject", stockGroupObject);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return "addgroupwiseallocation";
	}

	@RequestMapping(value="/addgroupwiseallocation", method=RequestMethod.POST)
	  public String groupwiseallocation(@ModelAttribute("stockGroupObject") StockGroup stockGroupObject,HttpSession sessionObj ,Model model) {
			try {
				  User userObj=(User) sessionObj.getAttribute("userObj");
				  Map<String,Integer> stockGroupQuantityMap=stockGroupObject.getStockGroupQuantityMap();
				  for (Entry<String, Double> tradingIterator : stockGroupObject.getStockGroupMap().entrySet()) {
					  stockGroupObject.setName(tradingIterator.getKey());
					  int modeid=stockGroupObject.getModeid();
					  stockGroupObject=stockService.getStockGroupByName(stockGroupObject);
					  stockGroupObject.setModeid(modeid);
					  stockGroupObject.setAllocationPercentage(tradingIterator.getValue());
					  stockGroupObject.setAllocationQuantity(stockGroupQuantityMap.get(tradingIterator.getKey()));
					  if (stockGroupObject.getAllocationPercentage()>=0 && stockGroupObject.getUserid()!=0) {
						  stockService.editStockGroupValue(stockGroupObject);
					  }
					  else if(stockGroupObject.getAllocationPercentage()>=0  && stockGroupObject.getUserid()==0){
						  stockGroupObject.setUserid(userObj.getUserId());
						  stockService.addStockGroupValue(stockGroupObject);
					  }
					  
				  }
			} catch (Exception e) {
				model.addAttribute("failureMsg","Groupwise allocation failed");
				e.printStackTrace();
			}
		  model.addAttribute("successMsg","Groupwise allocation done");
	      return "addgroupwiseallocation";
	  }
}
