package com.tp.stockquote.exception;

public class KeywordExcepion extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public KeywordExcepion(String msg){
		super(msg);
	}

}
