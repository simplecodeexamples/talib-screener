package com.tp.stockquote.mail.service;

import java.util.List;

import com.tp.stockquote.dto.PortfolioObject;

public interface CustomizedMailService {

	void sendSenderIdMail(PortfolioObject subscriber, List<String> sendToList,
			String message);

}
