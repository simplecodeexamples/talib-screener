package com.tp.stockquote.mail.service.impl;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.Message;
import org.springframework.integration.MessageChannel;
import org.springframework.integration.MessagingException;
import org.springframework.integration.message.GenericMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMailMessage;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.tp.stockquote.dto.CustomizedMailObject;
import com.tp.stockquote.dto.PortfolioObject;

@Service("customizedMailService")
public class CustomizedMailServiceImpl implements com.tp.stockquote.mail.service.CustomizedMailService{
	
	@Autowired
	private MessageChannel inputChannelCustomizedMail;
	@Autowired
	private JavaMailSender cutomizedMailSender;
	@Autowired
	private VelocityEngine velocityEngine;
	private static final String MAIL_FROM = "esb@mjunction.in";


	@Override
	public void sendSenderIdMail(PortfolioObject portfolioObject,
			List<String> sendToList, String message) {

		CustomizedMailObject mailObject = new CustomizedMailObject();
		mailObject.setSendToList(sendToList);
		String assigneMails="biswarup.banerjee@mjunction.in,ranjit.mondal@mjunction.in";
		List<String> sendCcList = new ArrayList<String>();
		for (String mail : assigneMails.split(","))
			sendCcList.add(mail);
		mailObject.setSendCCList(sendCcList);
		mailObject.setMailFrom(MAIL_FROM);
		mailObject.setSubject("Sender Id # " + portfolioObject.getPortfolioId()
				+ "need to be registered");
		String mailBody = "";
		Map<String, Object> templateModel = new HashMap<String, Object>();
		templateModel.put("subscriber", portfolioObject);


		String mailDesc = VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "com/tp/stockquote/template/mail_SenderIdAdd.vm",templateModel);
		mailObject.setBody(mailDesc);
		
		sendCustomizedMail(mailObject);

		
	}
	
	public boolean sendCustomizedMail(CustomizedMailObject customizedMail){
		 boolean sendFlag =  false;
		 try{
			 String mailSubjectKey = "";
			 String toMailId = "";
			 String toCCId="";
			 
			 mailSubjectKey=customizedMail.getSubject();
			 
			 String mailSubject = mailSubjectKey;
			 
			 MimeMessage mimeMessage = cutomizedMailSender.createMimeMessage();
			 MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);			 
			 helper.setSubject(mailSubject);
			 
			 Timestamp catalogStartTime =new Timestamp(Calendar.getInstance().getTime().getTime());
			 String pattern = "dd/MM/yy hh:mm:ss a";
			 SimpleDateFormat sdfFormat = new SimpleDateFormat(pattern);
			 customizedMail.setTime(sdfFormat.format(catalogStartTime));
			 
			 String mailDesc = customizedMail.getBody();
			 toMailId=String.join(",", customizedMail.getSendToList());
			 helper.setTo(processMultipleImailAddresses(toMailId));
			 if (customizedMail.getSendCCList()!=null && customizedMail.getSendCCList().size()>0) {
				 toCCId=String.join(",", customizedMail.getSendCCList());
				 helper.setCc(processMultipleImailAddresses(toCCId));
			 }
			
			 helper.setText(mailDesc, true);
			 if (customizedMail.getSendBCCList()!=null && customizedMail.getSendBCCList().size()>0) {
				 String bccMailId =String.join(",", customizedMail.getSendBCCList());
				 helper.setBcc(processMultipleImailAddresses(bccMailId));
			 }
			 
			 
			 
			 MimeMailMessage actualMsg = new MimeMailMessage(mimeMessage);
			 final Message<MimeMailMessage> genericMessage = new GenericMessage<MimeMailMessage>(actualMsg);
			 sendFlag = inputChannelCustomizedMail.send(genericMessage);
			
		 }catch(Exception ex){
			 ex.printStackTrace();
		 }
		 return sendFlag;
	}
	 
	 
	 
	 private InternetAddress[] processMultipleImailAddresses(String to) throws MessagingException, AddressException { 
	        ArrayList<String> recipientsArray = new ArrayList<String>(); 
	        StringTokenizer st = new StringTokenizer(to, ","); 
	        while (st.hasMoreTokens()) { 
	            recipientsArray.add(st.nextToken()); 
	        } 
	 
	        int sizeTo = recipientsArray.size(); 
	        InternetAddress[] addressTo = new InternetAddress[sizeTo]; 
	        for (int i = 0; i < sizeTo; i++) { 
	            addressTo[i] = new InternetAddress(recipientsArray.get(i).toString()); 
	        } 
	        return addressTo;
	    } 

}
