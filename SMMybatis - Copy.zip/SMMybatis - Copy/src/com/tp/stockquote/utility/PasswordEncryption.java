package com.tp.stockquote.utility;
import java.security.MessageDigest;

import org.apache.commons.codec.binary.Base64;

public final class PasswordEncryption {
    public static String encrypt(String plaintext) {
	String hashString = null;
	try {
	    MessageDigest digest = MessageDigest.getInstance("SHA-256");
	    digest.reset();
	    byte[] input = digest.digest(plaintext.getBytes("UTF-8"));
	    hashString = new String(Base64.encodeBase64(input));
	} catch (Exception e) {
	    e.printStackTrace();
	}
	return hashString;
    }
}