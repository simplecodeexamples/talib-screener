package com.tp.stockquote.utility;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

// import com.mj.metal.utility.GetSrvContxt;
// import javax.servlet.http.HttpServletRequest;
import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Border;
import jxl.format.BorderLineStyle;
import jxl.format.Colour;
import jxl.read.biff.BiffException;
import jxl.write.Label;
import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.tp.stockquote.dto.StockObject;
import com.tp.stockquote.dto.TechformatObject;
import com.tp.stockquote.dto.TransactionObject;

public class TechformatExcel {

	private static final String TRANSACTION_DATE = "Transaction Date";
	private static final String TRANSACTION_REF_NO = "Transaction Reference Number";
	private static final String CHEQUE_NO = "Transaction Cheque Number";
	private static final String NARRATION = "Narration";
	private static final String AMOUNT = "Amount";
	private static final String BALANCE = "Balance";

	private static final int ROW_CAPTION = 0;
	private static final int COL_CAPTION = 0;

	private static final String HEADING = "STOCKNAME";
	private static final int ROW_HEADER_START = 0;

	private static final DateFormat DATE_FORMAT_OUT = new SimpleDateFormat(
			"MMM d, yyyy");
	private static final String DATE_FORMAT_IN_STRING = "yyyy-MM-dd HH:mm:ss";
	private static final DateFormat DATE_FORMAT_IN = new SimpleDateFormat(
			DATE_FORMAT_IN_STRING);

	private static final String DATE_FORMAT_IN_STRING_MJEMD_UPLOD = "yyyy-MM-dd";
	private static final DateFormat DATE_FORMAT_IN_MJEMD_UPLOD = new SimpleDateFormat(
			DATE_FORMAT_IN_STRING_MJEMD_UPLOD);

	private static final String ID_REGEX = "(^-?\\d\\d*$)";
	private static final String INT_REGEX = "(^-?\\d\\d*$)";
	private static final String FLOAT_REGEX = "(^-?\\d\\d*\\.\\d*$)|(^-?\\d\\d*$)|(^-?\\.\\d\\d*$)";
	private static final String PRICE_REGEX = "(^-?\\d\\d*\\.\\d*$)|(^-?\\d\\d*$)|(^-?\\.\\d\\d*$)";
	private static final String HEADING_ITEM = "Ledger";
	private static final int COL_ATTR_START_ITEM = 11;

	public List<String> getColumnNames() {
		List<String> columnNames = new ArrayList<String>();

		columnNames.add(TRANSACTION_DATE);
		columnNames.add(TRANSACTION_REF_NO);
		columnNames.add(CHEQUE_NO);
		columnNames.add(NARRATION);
		columnNames.add(AMOUNT);
		columnNames.add(BALANCE);

		return columnNames;
	}

	public static WritableWorkbook write(TechformatObject techformatObject,
			WritableWorkbook workbook) throws IOException, WriteException {

		WritableSheet sheet = workbook.createSheet("Sheet1", 0);
		sheet.getSettings().setDefaultColumnWidth(12);

		WritableFont fh = new WritableFont(WritableFont.ARIAL, 9,
				WritableFont.BOLD);
		fh.setColour(Colour.WHITE);

		WritableFont fb = new WritableFont(fh);
		fb.setColour(Colour.BLACK);

		WritableFont fl = new WritableFont(fb);
		fl.setColour(Colour.INDIGO);

		WritableCellFormat cfh = new WritableCellFormat(fh);
		cfh.setWrap(true);
		cfh.setBorder(Border.ALL, BorderLineStyle.THIN);
		cfh.setBackground(Colour.INDIGO);
		cfh.setAlignment(Alignment.CENTRE);

		WritableCellFormat cfl = new WritableCellFormat(cfh);
		cfl.setFont(fl);
		// cfl.setLocked(true);

		WritableCellFormat cfb = new WritableCellFormat(fh);
		cfb.setFont(fb);
		cfb.setWrap(true);
		cfb.setBorder(Border.ALL, BorderLineStyle.THIN);
		cfb.setBackground(Colour.WHITE);

		WritableCellFormat cfh2 = new WritableCellFormat(cfb);
		cfh2.setAlignment(Alignment.LEFT);

		int colIndx = COL_CAPTION;
		int rowIndx = ROW_CAPTION;

		// Techformat description header
		Label label = new Label(colIndx, rowIndx, HEADING, cfh2);
		sheet.addCell(label);
		/*
		 * sheet.mergeCells(colIndx, rowIndx, colIndx+COL_ATTR_START-1,
		 * rowIndx);
		 */
		rowIndx++;

		String caption = "Generated on: " + DATE_FORMAT_OUT.format(new Date())
				+ "";
		label = new Label(colIndx, rowIndx, caption, cfh2);
		sheet.addCell(label);

		/*
		 * sheet.mergeCells(colIndx, rowIndx, colIndx+COL_ATTR_START-1,
		 * rowIndx);
		 */rowIndx++;

		/*
		 * StringBuffer allowedProducts = new StringBuffer(); for
		 * (Iterator<CategoryObject> iterator =
		 * techformatObject.getCategoryProductObject().iterator();
		 * iterator.hasNext();) { CategoryObject categoryObject =
		 * (CategoryObject) iterator.next();
		 * allowedProducts.append(categoryObject.getCode()); if
		 * (iterator.hasNext()) allowedProducts.append(","); } label = new
		 * Label(colIndx, rowIndx, allowedProducts.toString(), cfh2);
		 * sheet.addCell(label); sheet.mergeCells(colIndx, rowIndx,
		 * colIndx+COL_ATTR_START-1, rowIndx); rowIndx++;
		 */

		// ------------------------------------------------------------------------------------------------
		// Table headers
		// ------------------------------------------------------------------------------------------------

		int row1 = ROW_HEADER_START;
		int row2 = row1 + 1;
		int row3 = row2 + 1;

		// Code
		label = new Label(colIndx, row1, TRANSACTION_DATE, cfh);
		sheet.addCell(label);
		sheet.mergeCells(colIndx, row1, colIndx, row3);
		colIndx++;

		// Description
		label = new Label(colIndx, row1, TRANSACTION_REF_NO, cfh);
		sheet.addCell(label);
		sheet.mergeCells(colIndx, row1, colIndx, row3);
		colIndx++;

		// Currency
		label = new Label(colIndx, row1, CHEQUE_NO, cfh);
		sheet.addCell(label);
		sheet.mergeCells(colIndx, row1, colIndx, row3);
		colIndx++;

		// Quantity
		label = new Label(colIndx, row1, NARRATION, cfh);
		sheet.addCell(label);
		sheet.mergeCells(colIndx, row1, colIndx, row3);
		colIndx++;

		// Tax
		label = new Label(colIndx, row1, AMOUNT, cfh);
		sheet.addCell(label);
		sheet.mergeCells(colIndx, row1, colIndx, row3);
		colIndx++;

		// UOM
		label = new Label(colIndx, row1, BALANCE, cfh);
		sheet.addCell(label);
		sheet.mergeCells(colIndx, row1, colIndx, row3);
		colIndx++;

		/*
		 * if (!techformatObject.getAttributeObjects().isEmpty()) { //
		 * ----------
		 * ------------------------------------------------------------
		 * -------------- // Auction Attributes //
		 * ------------------------------
		 * ------------------------------------------------------ label = new
		 * Label(colIndx, row1, ATTRIBUTES, cfh); sheet.addCell(label);
		 * sheet.mergeCells(colIndx, row1, colIndx +
		 * techformatObject.getAttributeObjects().size() - 1, row1);
		 * 
		 * // Display the headers for product attributes for (AttributeObject
		 * attributeObject : techformatObject.getAttributeObjects()) { label =
		 * new Label(colIndx, row2, Integer.toString(attributeObject.getId()),
		 * cfl); sheet.addCell(label); label = new Label(colIndx, row3,
		 * attributeObject.getDescription(), cfh); sheet.addCell(label);
		 * colIndx++;
		 * 
		 * } }
		 */
		// sheet.getSettings().setProtected(true);

		return workbook;
	}

	public static List<TransactionObject> readStockListFromSheet(
			InputStream inputStream, String extension) throws IOException,
			BiffException {
		List<TransactionObject> transactionObjects = null;
		Workbook workbook;
		Sheet sheet;
		// Read the xls
		try {
			/*
			 * String mimeType=
			 * URLConnection.guessContentTypeFromStream(inputStream);
			 */if (extension.equals("xls")) {
				transactionObjects = readXLSFile(inputStream);
			} else if (extension.equals("xlsx")) {
				transactionObjects = readXLSXFile(inputStream);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return transactionObjects;

	}

	public static List<TransactionObject> readXLSFile(InputStream inputStream)
			throws IOException {
		List<TransactionObject> transactionObjects = new ArrayList<TransactionObject>();
		HSSFWorkbook wb = new HSSFWorkbook(inputStream);

		HSSFSheet sheet = wb.getSheetAt(0);
		HSSFRow row;
		HSSFCell cell;

		Iterator<Row> rows = sheet.rowIterator();

		row = (HSSFRow) rows.next();
		while (rows.hasNext()) {
			row = (HSSFRow) rows.next();
			Iterator<Cell> cells = row.cellIterator();
			while (cells.hasNext()) {
				TransactionObject transactionObject = new TransactionObject();
				cell = (HSSFCell) cells.next();
				transactionObject.getStockObject().setSymbol(
						cell.getStringCellValue());
				cell = (HSSFCell) cells.next();
				String tranTypeString = cell.getStringCellValue();
				int trantypeId = tranTypeString.equals("BUY") ? 1 : 2;
				transactionObject.setTransactionType(trantypeId);
				cell = (HSSFCell) cells.next();
				String exchangeString = cell.getStringCellValue();
				int exchangeId = exchangeString.equals("BSE") ? 1 : 2;
				transactionObject.getStockObject().setExchangeId(exchangeId);
				cell = (HSSFCell) cells.next();
				int positionTypeId = exchangeString.equals("BSE") ? 1 : 2;
				transactionObject.setPositionType(positionTypeId);
				cell = (HSSFCell) cells.next();
				transactionObject.setQuantity((int) cell.getNumericCellValue());
				cell = (HSSFCell) cells.next();
				transactionObject.setAmount(cell.getNumericCellValue());
				transactionObjects.add(transactionObject);
			}

		}
		return transactionObjects;
	}

	public static List<TransactionObject> readXLSXFile(InputStream inputStream)
			throws IOException {
		List<TransactionObject> transactionObjects = new ArrayList<TransactionObject>();
		XSSFWorkbook wb = new XSSFWorkbook(inputStream);
		XSSFWorkbook test = new XSSFWorkbook();
		XSSFSheet sheet = wb.getSheetAt(0);
		XSSFRow row;
		XSSFCell cell;

		Iterator<Row> rows = sheet.rowIterator();
		row = (XSSFRow) rows.next();
		while (rows.hasNext()) {
			row = (XSSFRow) rows.next();
			Iterator<Cell> cells = row.cellIterator();
			while (cells.hasNext()) {
				TransactionObject transactionObject = new TransactionObject();
				cell = (XSSFCell) cells.next();
				transactionObject.getStockObject().setSymbol(
						cell.getStringCellValue());
				cell = (XSSFCell) cells.next();
				String tranTypeString = cell.getStringCellValue();
				int trantypeId = tranTypeString.equals("BUY") ? 1 : 2;
				transactionObject.setTransactionType(trantypeId);
				cell = (XSSFCell) cells.next();
				String exchangeString = cell.getStringCellValue();
				int exchangeId = exchangeString.equals("BSE") ? 1 : 2;
				transactionObject.getStockObject().setExchangeId(exchangeId);
				cell = (XSSFCell) cells.next();
				int positionTypeId = exchangeString.equals("BSE") ? 1 : 2;
				transactionObject.setPositionType(positionTypeId);
				cell = (XSSFCell) cells.next();
				transactionObject.setQuantity((int) cell.getNumericCellValue());
				cell = (XSSFCell) cells.next();
				transactionObject.setAmount(cell.getNumericCellValue());
				transactionObjects.add(transactionObject);
			}
			System.out.println();
		}
		return transactionObjects;

	}

	public static void writeXLSFile(String excelFileName) throws IOException {

		String sheetName = "Sheet1";// name of sheet

		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet(sheetName);

		// iterating r number of rows
		for (int r = 0; r < 5; r++) {
			HSSFRow row = sheet.createRow(r);

			// iterating c number of columns
			for (int c = 0; c < 5; c++) {
				HSSFCell cell = row.createCell(c);

				cell.setCellValue("Cell " + r + " " + c);
			}
		}

		FileOutputStream fileOut = new FileOutputStream(excelFileName);

		// write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	public static void writeXLSXFile(String excelFileName) throws IOException {

		String sheetName = "Sheet1";// name of sheet

		XSSFWorkbook wb = new XSSFWorkbook();
		XSSFSheet sheet = wb.createSheet(sheetName);

		// iterating r number of rows
		for (int r = 0; r < 5; r++) {
			XSSFRow row = sheet.createRow(r);

			// iterating c number of columns
			for (int c = 0; c < 5; c++) {
				XSSFCell cell = row.createCell(c);

				cell.setCellValue("Cell " + r + " " + c);
			}
		}

		FileOutputStream fileOut = new FileOutputStream(excelFileName);

		// write this workbook to an Outputstream.
		wb.write(fileOut);
		fileOut.flush();
		fileOut.close();
	}

	public static List<StockObject> readStockListFromNSEIndia(
			InputStream inputStream, String extensionNifty50) {
		List<StockObject> stockNames = null;
		Workbook workbook;
		Sheet sheet;
		// Read the xls
		try {
			/*
			 * String mimeType=
			 * URLConnection.guessContentTypeFromStream(inputStream);
			 */if (extensionNifty50.equals("xls")) {
				stockNames = readXLSFileNifty(inputStream);
			} else if (extensionNifty50.equals("xlsx")) {
				stockNames = readXLSXFileNifty(inputStream);
			} else if (extensionNifty50.equals("csv")) {
				stockNames = readCSVFileNifty(inputStream);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return stockNames;

	}

	private static final char DEFAULT_SEPARATOR = ',';
	private static final char DEFAULT_QUOTE = '"';

	private static List<StockObject> readCSVFileNifty(InputStream inputStream)
			throws ParseException {

		List<StockObject> stockNames = new ArrayList<StockObject>();
		BufferedReader br = null;
		String line = "";
		String cvsSplitBy = ",";
		int lineCount = 0;

		try {

			br = new BufferedReader(new InputStreamReader(inputStream));
			while ((line = br.readLine()) != null) {
				if (lineCount > 0) {
					StockObject stockObject = new StockObject();
					line = line.replaceAll("\"", "");
					List<String> stockLine = parseLine(line);
					System.out.print("Line Val");
					for (String string : stockLine) {
						System.out.print(string + " ");

					}
					System.out.println();
					DecimalFormat df = new DecimalFormat("#,##0.00");
					stockObject.setSymbol(stockLine.get(0));
					stockObject.setOpen(Double.parseDouble(stockLine.get(1)));
					stockObject.setDayHigh(df.parse(stockLine.get(2))
							.doubleValue());
					stockObject.setDayLow(df.parse(stockLine.get(3))
							.doubleValue());
					stockObject.setLastPrice(df.parse(stockLine.get(4))
							.doubleValue());
					stockObject.setpChange(df.parse(stockLine.get(5))
							.doubleValue());
					stockObject.setTotalTradedVolume(df.parse(stockLine.get(6))
							.doubleValue());
					stockObject.setTotalTradedValue(df.parse(stockLine.get(7))
							.doubleValue());
					if (stockObject.getSymbol() != null) {
						stockNames.add(stockObject);
					}

				}

				lineCount++;

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		System.out.println("Done");
		return stockNames;

	}

	public static List<String> parseLine(String cvsLine) {
		return parseLine(cvsLine, DEFAULT_SEPARATOR, DEFAULT_QUOTE);
	}

	public static List<String> parseLine(String cvsLine, char separators) {
		return parseLine(cvsLine, separators, DEFAULT_QUOTE);
	}

	public static List<String> parseLine(String cvsLine, char separators,
			char customQuote) {

		List<String> result = new ArrayList<>();

		// if empty, return!
		if (cvsLine == null && cvsLine.isEmpty()) {
			return result;
		}

		if (customQuote == ' ') {
			customQuote = DEFAULT_QUOTE;
		}

		if (separators == ' ') {
			separators = DEFAULT_SEPARATOR;
		}

		StringBuffer curVal = new StringBuffer();
		boolean inQuotes = false;
		boolean startCollectChar = false;
		boolean doubleQuotesInColumn = false;

		char[] chars = cvsLine.toCharArray();

		for (char ch : chars) {

			if (inQuotes) {
				startCollectChar = true;
				if (ch == customQuote) {
					inQuotes = false;
					doubleQuotesInColumn = false;
				} else {

					// Fixed : allow "" in custom quote enclosed
					if (ch == '\"') {
						if (!doubleQuotesInColumn) {
							curVal.append(ch);
							doubleQuotesInColumn = true;
						}
					} else {
						curVal.append(ch);
					}

				}
			} else {
				if (ch == customQuote) {

					inQuotes = true;

					// Fixed : allow "" in empty quote enclosed
					if (chars[0] != '"' && customQuote == '\"') {
						curVal.append('"');
					}

					// double quotes in column will hit this!
					if (startCollectChar) {
						curVal.append('"');
					}

				} else if (ch == separators) {

					result.add(curVal.toString());

					curVal = new StringBuffer();
					startCollectChar = false;

				} else if (ch == '\r') {
					// ignore LF characters
					continue;
				} else if (ch == '\n') {
					// the end, break!
					break;
				} else {
					curVal.append(ch);
				}
			}

		}

		result.add(curVal.toString());

		return result;
	}

	private static List<StockObject> readXLSXFileNifty(InputStream inputStream) {
		List<StockObject> stockNames = new ArrayList<StockObject>();
		XSSFWorkbook wb = null;
		XSSFSheet sheet = null;
		XSSFRow row;
		XSSFCell cell;
		try {
			wb = new XSSFWorkbook(inputStream);
			sheet = wb.getSheetAt(0);

			Iterator<Row> rows = sheet.rowIterator();

			while (rows.hasNext()) {
				row = (XSSFRow) rows.next();
				StockObject stockObject = new StockObject();
				Iterator<Cell> cells = row.cellIterator();

				if (row.getRowNum() != 0) {

					while (cells.hasNext()) {
						cell = (XSSFCell) cells.next();
						int columnIndex = cell.getColumnIndex();

						switch (columnIndex) {
						case 0:
							stockObject.setSymbol((String) getCellValue(cell));
							break;
						case 1:
							stockObject.setOpen((double) getCellValue(cell));
							break;
						case 2:
							stockObject.setDayHigh((double) getCellValue(cell));
							break;
						case 3:
							stockObject.setDayLow((double) getCellValue(cell));
							break;
						case 4:
							stockObject
									.setLastPrice((double) getCellValue(cell));
							break;
						case 6:
							stockObject.setpChange((double) getCellValue(cell));
							break;
						case 7:
							stockObject
									.setTotalTradedVolume((double) getCellValue(cell));
							break;
						case 8:
							stockObject
									.setTotalTradedValue((double) getCellValue(cell));
							break;
						}

						System.out.println();
					}
				}
				if (stockObject.getSymbol() != null) {
					stockNames.add(stockObject);
				}
			}

			//wb.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return stockNames;

	}

	private static Object getCellValue(Cell cell) {
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING:
			return cell.getStringCellValue();

		case Cell.CELL_TYPE_BOOLEAN:
			return cell.getBooleanCellValue();

		case Cell.CELL_TYPE_NUMERIC:
			return cell.getNumericCellValue();
		}

		return null;
	}

	private static List<StockObject> readXLSFileNifty(Object inputStream) {
		// TODO Auto-generated method stub
		return null;
	}

}
