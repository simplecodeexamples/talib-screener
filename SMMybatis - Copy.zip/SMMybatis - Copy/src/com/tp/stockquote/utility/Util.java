package com.tp.stockquote.utility;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

public class Util {
	public static TreeMap<String, String> stringMapFromListOfMap(
			List<Map<String, String>> portfolioAttrMapList) {
		TreeMap<String, String> map = new TreeMap<String, String>();

		for (int i = 0; i < portfolioAttrMapList.size(); i++) {
			String key = (String) portfolioAttrMapList.get(i).get("attrname");
			String value = (String) portfolioAttrMapList.get(i).get("value");
			map.put(key, value);
		}
		return map;
	} 
	
	public static String formatDatetoString(Date date,String formatString){
		SimpleDateFormat format=new SimpleDateFormat(formatString);
		String dateStr="";
		try {
			dateStr= format.format(date);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dateStr;
	}
	public static Date formatStringToDate(String dateInp,String formatString){

		SimpleDateFormat format=new SimpleDateFormat(formatString);
		Date date=null;
		try {
			date= format.parse(dateInp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return date;
	
	}
}