package com.tp.stockquote.utility;

public interface IConstant {
	public static final String ACTION_FLAG_RESPONSE_ADD = "O";
	public static final String ACTION_TYPE_FLAG_REOPEN = "RO";
	public static final String ACTION_TYPE_FLAG_RESOLUTION = "C";
	public static final String ACTION_TYPE_FLAG_RESOLUTION_RESOLVE = "R";
	public static final String ACTIVATE_MESSAGE = "mj.cchp.ACTIVATE_MESSAGE";
	public static final String ACTIVATE_PROJCT_SIZE_UNIT_MESSAGE = "mj.cchp.ACTIVATE_PROJCT_SIZE_UNIT_MESSAGE";
	// below four are added for holiday add,delete,modify
	public static final String ADD_HOLIDAY_LIST = "mj.cchp.ADD_HOLIDAY_LIST";
	public static final String ADD_ROW_MESSAGE = "mj.cchp.ADD_ROW_MESSAGE";
	public static final String AREA_DESCRIPTION_DEFAULT = "NO AREA";
	public static final String AREA_DESCRIPTION_OTHER = "OTHERS";
	public static final String AREA_VECTOR_KEY = "mj.cchp.AREA_VECTOR_KEY";
	public static final String AREAMAPPING = "mj.cchp.AREAMAPPING";
	public static final String ATTACHMENT_ID = "mj.cchp.ATTACHMENT_ID";
	public static final String ATTRIBUTE_RECEIPT_SLA = "RECEIPT SLA";
	public static final int ATTRIBUTE_TYPE_CLIENT = 100;
	public static final int ATTRIBUTE_TYPE_EVENTDATE = 101;
	public static final int ATTRIBUTE_VALUE_TYPE_FEEDBACK_CLOSE = 107;
	public static final String CCHP_PROJECT_MAP = "mj.cchp.CCHP_PROJECT_MAP";
	public static final String CLIENT_RELATED_QUERY = "CLIENT QUERY";
	public static final String CLIENT_VECTOR = "mj.cchp.CLIENT_VECTOR";
	public static final String CLIENTMAPPING = "mj.cchp.CLIENTMAPPING";
	public static final String CURRENT_REQUEST_ATTRIBUTES = "mj.cchp.view.CURRENT_REQUEST_ATTRIBUTES";
	public static final String CURRENT_REQUEST_PARAMETERS = "mj.cchp.view.CURRENT_REQUEST_PARAMETERS";
	public static final String CURRENT_SCREEN = "mj.cchp.view.CURRENT_SCREEN";
	public static final String CURRENT_SCREEN_NAME = "mj.cchp.view.CURRENT_SCREEN_NAME";
	public static final String CURRENT_URL = "mj.cchp.view.CURRENT_URL";
	public static final String DATA_TYPE_DATETIME = "DT";
	public static final String DATA_TYPE_DECIMAL = "ND";
	public static final String DATA_TYPE_INTEGER = "NI";
	public static final String DATA_TYPE_LIST_ARRAY = "LA";
	public static final String DATA_TYPE_LIST_MULTIPLE = "LM";
	public static final String DATA_TYPE_LIST_SINGLE = "LS";
	public static final String DATA_TYPE_TEXT = "TS";
	public static final String DATA_TYPE_TEXTAREA = "TM";
	public static final String DATE_LIST = "mj.cchp.DATE_LIST";
	public static final String DEACTIVATE_MESSAGE = "mj.cchp.DEACTIVATE_MESSAGE";
	public static final String DEACTIVATE_PROJCT_SIZE_UNIT_MESSAGE = "mj.cchp.DEACTIVATE_PROJCT_SIZE_UNIT_MESSAGE";
	public static final int DEFAULT_CLOSED_FEEDBACK_USER = 100;
	public static final String DEFAULTAREAFLAG_NO = "N";
	public static final String DEFAULTAREAFLAG_YES = "Y";
	public static final String DEFAULTCLIENT_FORALL = "-";
	public static final String DELETE_MESSAGE = "mj.cchp.DELETE_MESSAGE";
	public static final String DEPARTMENT_VECTOR = "mj.cchp.DEPARTMENT_VECTOR";
	public static final String DOCUMENT_CONTAINER_KEY = "mj.cchp.DOCUMENT_CONTAINER_KEY";
	public static final String DOCUMENT_DESCRIPTION_FEEDBACK = "FEEDBACK";
	public static final String DOCUMENT_DESCRIPTION_RECEIPT = "RECEIPT";
	// to
	// get
	// feedback
	// Escalation
	// Date
	// below four field are added for post sign in action.
	public static final int DOCUMENT_DESCRIPTION_RECEIPT_KEY = 101;
	public static final String DOCUMENT_DESCRIPTION_RESOLUTION = "RESOLUTION";
	public static final String DOCUMENT_DESCRIPTION_RESPONSE = "RESPONSE";
	public static final int DOCUMENT_DESCRIPTION_RESPONSE_KEY = 102;
	public static final int DOCUMENT_TYPE_FEEDBACK = 100;
	public static final int DOCUMENT_TYPE_ISSUE = 104;
	public static final int DOCUMENT_TYPE_RECEIPT = 101;
	public static final int DOCUMENT_TYPE_RESOLUTION = 103;
	public static final int DOCUMENT_TYPE_RESPONSE = 102;
	public static final String DOMAIN_AREA = "AREA";
	public static final String DOMAIN_DETAILS_VECTOR = "mj.cchp.DOMAIN_DETAILS_VECTOR";
	public static final String DOMAIN_FEEDBACKTYPE = "FEEDBACKTYPE";
	public static final String DOMAIN_LIST_VECTOR = "mj.cchp.DOMAIN_LIST_VECTOR";
	public static final String DOMAIN_PRIORITY = "PRIORITY";
	public static final String DOMAIN_RECEIPT = "('PRIORITY','AREA','FEEDBACKTYPE')";
	public static final String DOMAIN_SATISFACTION_LEVEL = "'SATISFACTIONLEVEL'";
	public static final String EMAIL_VECTOR = "mj.cchp.EMAIL_VECTOR";
	public static final int EPS_FINAL_RESOLVER_ID = 114;
	public static final String ERROR_MESSAGE_KEY = "mj.cchp.ERROR_MESSAGE_KEY";
	// to
	// get
	// attachment
	// file
	// for
	// a
	// feedback
	public static final String ESCALATION_DATE = "mj.cchp.ESCALATION_DATE";// Added
	public static final String ESCALATION_FLAG_NO = "N";
	public static final String ESCALATION_FLAG_YES = "Y";
	public static final String EXCEL_SHOW_FLAG = "mj.cchp.EXCEL_SHOW_FLAG";
	public static final String FEEDBACK_AREA_CODE_CRMT = "CRMT";
	public static final String FEEDBACK_ASSIGNED_VECTOR = "mj.cchp.FEEDBACK_ASSIGNED_VECTOR";
	public static final String FEEDBACK_CLASSIFICATION_EXTERNAL_DESCRIPTION = "EXTERNALFEEDBACK";
	public static final String fEEDBACK_CLASSIFICATION_EXTERNAL_ID = "101";
	public static final String FEEDBACK_CLASSIFICATION_INTERNAL_DESCRIPTION = "INTERNALFEEDBACK";
	public static final String FEEDBACK_CLASSIFICATION_INTERNAL_ID = "100";
	public static final String FEEDBACK_CLOSE_OPTION = "mj.cchp.FEEDBACK_CLOSE_OPTION";
	public static final String FEEDBACK_CLOSED = "CLOSED";
	public static final String FEEDBACK_CODE = "mj.cchp.FEEDBACK_CODE";
	public static final String FEEDBACK_COMMENT_ADD = "ADD";
	/**
	 * End
	 */
	public static final String FEEDBACK_COMMENT_VECTOR = "mj.cchp.FEEDBACK_COMMENT_VECTOR";
	public static final int FEEDBACK_ESCALATIONFLAG_APPROVAL_WARNING = 106;
	public static final int FEEDBACK_ESCALATIONFLAG_APPROVAL_WARNING_TIMERANGE = 2 * 60 * 60 * 1000;
	public static final int FEEDBACK_ESCALATIONFLAG_BUH = 103;
	public static final int FEEDBACK_ESCALATIONFLAG_SPOC1 = 100;
	public static final int FEEDBACK_ESCALATIONFLAG_SPOC2 = 101;
	public static final int FEEDBACK_ESCALATIONFLAG_SPOC3 = 102;

	public static final int FEEDBACK_ESCALATIONFLAG_WARNING = 105;
	// added for
	// year
	// calculation
	public static final String FEEDBACK_FILE_ATTACHED_VECTOR = "mj.cchp.FEEDBACK_FILE_ATTACHED_VECTOR";// Added
	public static final String FEEDBACK_FLAG_CLOSE = "C";
	public static final String FEEDBACK_FLAG_FORWARDCLIENT = "FW";
	public static final String FEEDBACK_FLAG_OPEN = "O";
	public static final String FEEDBACK_FLAG_RESOLVED = "R";
	public static final String FEEDBACK_FOR_INCIDENT = "INCIDENT";
	public static final String FEEDBACK_FORWARDEDTOCLIENT_VECTOR = "mj.cchp.FEEDBACK_FORWARDEDTOCLIENT_VECTOR";
	public static final String FEEDBACK_ID = "mj.cchp.FEEDBACK_ID";
	public static final int FEEDBACK_INTERNAL_SOURCE_ID = 105;
	public static final String FEEDBACK_LIST = "mj.cchp.FEEDBACK_LIST";

	public static final String FEEDBACK_MYSTATUS_ASSIGNED = "ASSIGNED";
	public static final String FEEDBACK_MYSTATUS_CLOSE = "CLOSE";
	public static final String FEEDBACK_MYSTATUS_COMPLETE = "COMPLETE";
	public static final String FEEDBACK_MYSTATUS_FORWARDTOCLIENT = "FW";
	public static final String FEEDBACK_MYSTATUS_RELEASED = "RELEASED";
	public static final String FEEDBACK_NATURE_NEW = "NEW";
	public static final String FEEDBACK_NEW_VECTOR = "mj.cchp.FEEDBACK_NEW_VECTOR";
	public static final String FEEDBACK_OBJECT = "mj.cchp.FEEDBACK_OBJECT";
	public static final String FEEDBACK_OBJECT_KEY = "mj.cchp.FEEDBACK_OBJECT_KEY";
	public static final String FEEDBACK_OPEN = "OPEN";
	public static final String FEEDBACK_REOPEN_ASSIGNFLAG = "RA";
	public static final String FEEDBACK_RESOLVED_VECTOR = "mj.cchp.FEEDBACK_RESOLVED_VECTOR";
	public static final String FEEDBACK_SEARCH_OBJECT = "mj.cchp.FEEDBACK_SEARCH_OBJECT";
	public static final int FEEDBACK_SOURCE_ONLINE = 100;
	public static final String FEEDBACK_STATUS = "mj.cchp.FEEDBACK_STATUS";
	public static final String FEEDBACK_STATUS_CLOSED = "C";
	public static final String FEEDBACK_STATUS_CLOSED_PROCEDURE = "Closed";
	public static final String FEEDBACK_STATUS_OPEN = "O";
	public static final String FEEDBACK_STATUS_REGISTERED_PROCEDURE = "Registered";
	public static final String FEEDBACK_STATUS_RESOLVED = "RESOLVED";
	public static final String FEEDBACK_TYPE = "mj.cchp.FEEDBACK_TYPE";
	public static final int FEEDBACK_TYPE_All = 0;
	public static final String FEEDBACK_TYPE_ALL_DESCRIPTION = "ALL";
	public static final int FEEDBACK_TYPE_BUGFIX = 117;
	public static final int FEEDBACK_TYPE_CLIENTQUERY = 104;
	public static final String FEEDBACK_TYPE_CLIENTQUERY_DESCRIPTION = "CLIENT QUERY";
	public static final int FEEDBACK_TYPE_COMPLAINT = 100;
	public static final String FEEDBACK_TYPE_COMPLAINT_DESCRIPTION = "COMPLAINT";
	public static final int FEEDBACK_TYPE_DATAISSUE = 120;
	public static final int FEEDBACK_TYPE_DEVELOPMENT_REQUEST = 122;
	public static final String FEEDBACK_TYPE_EVENT_DESCRIPTION = "EVENT";
	public static final int FEEDBACK_TYPE_GENERALQUERY = 103;
	public static final String FEEDBACK_TYPE_GENERALQUERY_DESCRIPTION = "GENERAL QUERY";
	public static final int FEEDBACK_TYPE_MD = 141;
	public static final int FEEDBACK_TYPE_MODIFICATION = 118;
	public static final int FEEDBACK_TYPE_NEWREGISTERED = 0;
	public static final int FEEDBACK_TYPE_OPERATINALSUPPORT = 119;
	public static final int FEEDBACK_TYPE_OTHERS = 102;
	public static final String FEEDBACK_TYPE_OTHERS_DESCRIPTION = "OTHERS";
	public static final int FEEDBACK_TYPE_SUGGESTION = 101;
	public static final String FEEDBACK_TYPE_SUGGESTION_DESCRIPTION = "SUGGESTION";
	public static final int FEEDBACK_TYPE_TRANSACTIONAL_FEEDBACK = 105;
	public static final String FEEDBACK_TYPE_TRANSACTIONAL_FEEDBACK_DESCRIPTION = "TRANSACTION FEEDBACK";
	public static final String FEEDBACK_USER_ID = "mj.cchp.FEEDBACK_USER_ID";
	public static final String FEEDBACK_USER_OBJECT = "mj.cchp.FEEDBACK_USER_OBJECT";
	public static final String FEEDBACK_VECTOR = "mj.cchp.FEEDBACK_VECTOR";
	public static final String FEEDBACK_VECTOR_KEY = "mj.cchp.FEEDBACK_VECTOR_KEY";
	public static final String FEEDBACK_VECTOR_KEY1 = "mj.cchp.FEEDBACK_VECTOR_KEY1";
	public static final String FEEDBACK_VECTOR_KEY3 = "mj.cchp.FEEDBACK_VECTOR_KEY3";
	public static final String FEEDBACK_VECTOR_KEY4 = "mj.cchp.FEEDBACK_VECTOR_KEY4";
	public static final String FEEDBACK_VECTOR_SIZE = "mj.cchp.FEEDBACK_VECTOR_SIZE";
	public static final String FEEDBACK_VECTOR_SIZE1 = "mj.cchp.FEEDBACK_VECTOR_SIZE1";
	public static final String FEEDBACK_VECTOR_SIZE3 = "mj.cchp.FEEDBACK_VECTOR_SIZE3";
	public static final String FEEDBACK_VECTOR_SIZE4 = "mj.cchp.FEEDBACK_VECTOR_SIZE4";
	public static final String FEEDBACK_WARNINGFLAG_NO = "N";
	public static final String FEEDBACK_WARNINGFLAG_YES = "Y";
	public static final String FEEDBACKNATURE_VECTOR_KEY = "mj.cchp.FEEDBACKNATURE_VECTOR_KEY";
	public static final String FEEDBACKSOURCE_VECTOR = "mj.cchp.FEEDBACKSOURCE_VECTOR";
	public static final String FEEDBACKTYPE_DESCRIPTION = "mj.cchp.FEEDBACKTYPE_DESCRIPTION";
	public static final String FEEDBACKTYPE_ID = "mj.cchp.FEEDBACKTYPE_ID";
	public static final int FEEDBACKTYPE_ID_SUGGESTION = 101;
	public static final String FEEDBACKTYPE_MAP_KEY = "mj.cchp.FEEDBACKTYPE_MAP_KEY";
	public static final String FEEDBACKTYPE_VECTOR = "mj.cchp.FEEDBACKTYPE_VECTOR";
	public static final String FEEDBACKTYPE_VECTOR_KEY = "mj.cchp.FEEDBACKTYPE_VECTOR_KEY";
	public static final String FILE_UPLOAD_FLAG = "mj.cchp.FILE_UPLOAD_FLAG";
	public static final String FILENAME = "mj.cchp.FILENAME";
	public static final String FORWARD_TO_FMSIT_EMAIL = "itservicedesk@mjunction.in";
	public static final String FORWARDEDTOCLIENT_VECTOR = "mj.cchp.FORWARDEDTOCLIENT_VECTOR";
	public static final String Global_CATEGORY_APPROVE = "A";
	public static final String Global_CATEGORY_PENDING = "P";
	// Entry for Global Category
	public static final String Global_CATEGORY_VECTOR = "mj.cchp.GLOBAL_CATEGORY_VECTOR";
	public static final String GRAPHTYPEPATH = "mj.cchp.GRAPHTYPEPATH";
	public static final String HEADER_ID = "mj.cchp.survey.HEADER_ID";
	public static final String HEADER_LIST = "mj.cchp.survey.HEADER_LIST";
	public static final String HOLIDAY_LIST_VECTOR = "mj.cchp.HOLIDAY_LIST_VECTOR";
	public static final String INCIDENT_ASSIGNED_VECTOR = "mj.cchp.INCIDENT_ASSIGNED_VECTOR";
	public static final String INCIDENT_FLAG_CLOSE = "C";
	public static final String INCIDENT_FLAG_OPEN = "O";
	public static final String INFO_NOT_ENTER = "/NE/";
	public static final String ISSUE_NEWISSUE_CODE = "NEW ISSUE";
	public static final String ISSUE_REOPEN = "REOPEN";
	public static final String ISSUE_SLA_FLAG_OFF = "N";
	// For Issue SLA
	public static final String ISSUE_SLA_FLAG_ON = "Y";
	public static final String ISSUESERVICE_VECTOR = "mj.cchp.ISSUESERVICE_VECTOR";
	public static final String ISSUESTATUS_CLOSE = "CLOSE";
	public static final String ISSUESTATUS_NEW = "NEW";
	public static final String ISSUESTATUS_OPEN = "OPEN";
	public static final String ISSUESTATUS_PENDING = "PENDING";
	public static final String ISSUESTATUS_REJECTED = "REJECTED";
	public static final String ISSUESTATUSLIST = "mj.cchp.ISSUESTATUSLIST";
	public static final String ISSUETYPEFLAG_EVENT = "E";
	public static final String ISSUETYPEFLAG_EVENT_CLOSE = "EC";
	public static final String ISSUETYPEFLAG_INCIDENT = "I";
	public static final String ISSUETYPEFLAG_INCIDENT_CLOSE = "IC";
	public static final String ISSUETYPEFLAG_NO = "N";
	public static final String ISSUETYPEFLAG_PENDING = "P";
	// ********************* Prasenjit : Start ************************//
	public static final String ISSUETYPEFLAG_REJECTED = "R"; // For Issue
	public static final String ISSUETYPEFLAG_YES = "Y";
	public static final String ISSUEUNIT_ESTIMATION = "ESTIMATION";
	public static final String ISSUEUNIT_SIZE = "SIZE";
	public static final String ISSUEUNITLIST = "mj.cchp.ISSUEUNITLIST";
	public static final String LIST_OF_VALUE_VECTOR = "mj.cchp.LIST_OF_VALUE_VECTOR";
	public static final String LOGGER_SATISFACTION_LEVEL_BLANK = "-";
	public static final String LOGGER_SATISFACTION_LEVEL_FROM_ADMIN = "REOPEN BY ADMIN";
	public static final String LOGGER_SATISFACTION_LEVEL_NOT_SATISFIED = "NOT SATISFIED";
	public static final String CSTEAM_SATISFACTION_LEVEL_BLANK = "-";
	public static final String CSTEAM_SATISFACTION_LEVEL_SATISFIED = "SATISFIED";
	public static final String CSTEAM_SATISFACTION_LEVEL_NOT_SATISFIED = "NOT SATISFIED";
	
	public static final String MAIL_ARCHIVE_INBOX_STATUS = "ArchiveInbox";
	public static final String MAIL_ARCHIVE_STATUS = "ArchiveLoggedCall";
	public static final String MAIL_ID = "mj.cchp.MAIL_ID";
	public static final String MAIL_INBOX_STATUS = "Raw";
	public static final String MAIL_LOGGEDCALL_STATUS = "Call Logged";
	public static final String MAIL_TRASH_ARCHIVE_STATUS = "Trash_Archive";
	public static final String MAIL_TRASH_STATUS = "Trash";
	public static final String MAPPING_AREA_HASHMAP = "mj.cchp.MAPPING_AREA_HASHMAP";
	public static final String MESSAGE_KEY = "mj.cchp.MESSAGE_KEY";
	public static final String MODIFY_HOLIDAY_LIST = "mj.cchp.MODIFY_HOLIDAY_LIST";
	public static final String MODIFY_MESSAGE = "mj.cchp.MODIFY_MESSAGE";
	public static final String MODIFYFLAG = "mj.cchp.survey.MODIFYFLAG";
	public static final String NEWFEEDBACK_HASHMAP = "mj.cchp.NEWFEEDBACK_HASHMAP";
	public static final String ORG_COMPLAINT_CLIENT_RELATED = "101";
	public static final String ORG_COMPLAINT_MJ_RELATED = "100";
	public static final String ORGANIZATION_VECTOR = "mj.cchp.ORGANIZATION_VECTOR";
	public static final String PAN_VECTOR = "mj.cchp.PAN_VECTOR";
	public static final String PATH = "mj.cchp.PATH";
	public static final String PHONE_VECTOR = "mj.cchp.PHONE_VECTOR";
	public static final String PREVIOUS_REQUEST_ATTRIBUTES = "mj.cchp.view.PREVIOUS_REQUEST_ATTRIBUTES";
	public static final String PREVIOUS_REQUEST_PARAMETERS = "mj.cchp.view.PREVIOUS_REQUEST_PARAMETERS";
	public static final String PREVIOUS_SCREEN = "mj.cchp.view.PREVIOUS_SCREEN";
	public static final String PRIORITY_VECTOR_KEY = "mj.cchp.PRIORITY_VECTOR_KEY";
	public static final String PRIVILEGE_CODE_DELETE = "DELETE";
	public static final String PRIVILEGE_CODE_MODIFY = "MODIFY";
	public static final String PRIVILEGE_CODE_NEW = "NEW";
	public static final String PRIVILEGE_CODE_VIEW = "VIEW";
	public static final String PROCESS_COMPLAINT_OPERATION_RELATED = "103";
	public static final String PROCESS_COMPLAINT_POLICY_RELATED = "102";
	public static final String PROJCT_SIZE_UNIT_OBJECT = "mj.cchp.PROJCT_SIZE_UNIT_OBJECT";
	public static final String PROJCT_SIZE_UNIT_VECTOR = "mj.cchp.PROJCT_SIZE_UNIT_VECTOR";
	public static final String PROJECT_CLIENT_VECTOR = "mj.cchp.PROJECT_CLIENT_VECTOR";
	public static final String PROJECT_DEACT_CLIENT_VECTOR = "mj.cchp.PROJECT_DEACT_CLIENT_VECTOR";
	public static final int PROJECT_ROLE_PROJECTRECEIVER = 102;
	public static final int PROJECT_ROLE_RECEIVER = 100;
	public static final String PROJECT_VECTOR = "mj.cchp.PROJECT_VECTOR";
	public static final String PROJECTESTIMATIONUNIT = "mj.cchp.PROJECTESTIMATIONUNIT";
	public static final String PROJECTORGANIZATION_VECTOR = "mj.cchp.PROJECTORGANIZATION_VECTOR";
	// end: vikas
	public static final String PROJECTROLE = "mj.cchp.PROJECTROLE";
	public static final String PROJECTSIZEUNIT = "mj.cchp.PROJECTSIZEUNIT";
	public static final String PROJECTUSER_VECTOR = "mj.cchp.PROJECTUSER_VECTOR";
	public static final String QUESTION_HASHMAP = "mj.cchp.survey.QUESTION_HASHMAP";
	public static final String QUESTION_ID = "mj.cchp.survey.QUESTION_ID";
	public static final String QUESTIONOPTION_LIST = "mj.cchp.survey.QUESTIONOPTION_LIST";
	public static final String QUESTIONSEQUENCES = "mj.cchp.survey.QUESTIONSEQUENCES";
	public static final int QUESTIONTYPE_ID_CHECKBOX = 103;
	public static final int QUESTIONTYPE_ID_DESCRIPTIVE = 102;
	public static final int QUESTIONTYPE_ID_RADIO = 100;
	public static final int QUESTIONTYPE_ID_YESNO = 101;
	public static final String QUESTIONTYPE_LIST = "mj.cchp.survey.QUESTIONTYPE_LIST";
	public static final String RECEIPT_LIST = "mj.cchp.RECEIPT_LIST";
	public static final String RECEIPT_OBJECT = "mj.cchp.RECEIPT_OBJECT";
	public static final String RECEIPT_REOPENFLAG = "REOPEN";
	public static final String RECEIPT_VECTOR_KEY = "mj.cchp.RECEIPT_VECTOR_KEY";
	public static final String REGION_VECTOR = "mj.cchp.REGION_VECTOR";
	public static final String REGIONMAPPING = "mj.cchp.REGIONMAPPING";
	public static final int REGISTERED_CCHP_USER = 0;
	public static final String REPORT_MAP = "mj.cchp.REPORT_MAP";
	public static final String REPORT_VECTOR = "mj.cchp.REPORT_VECTOR";
	public static final String RESOLUTION_ID = "mj.cchp.RESOLUTION_ID";
	public static final String RESOLUTION_OBJECT = "mj.cchp.RESOLUTION_OBJECT";
	public static final String RESOLUTION_OBJECT_KEY = "mj.cchp.RESOLUTION_OBJECT_KEY";
	public static final String RESOLUTION_VECTOR_KEY = "mj.cchp.RESOLUTION_VECTOR_KEY";
	public static final String RESOLUTIONCLOSEFLAG = "CLOSED";
	public static final String RESOLVER_AREAMAPPING = "mj.cchp.RESOLVER_AREAMAPPING";
	public static final String RESOLVER_VECTOR_KEY = "mj.cchp.RESOLVER_VECTOR_KEY";
	public static final String RESOURCE_FEEDBACK_VECTOR = "mj.cchp.RESOURCE_FEEDBACK_VECTOR";
	public static final String RESOURCE_FEEDBACKCOUNT_VECTOR = "mj.cchp.RESOURCE_FEEDBACKCOUNT_VECTOR";
	public static final String RESOURCE_VECTOR = "mj.cchp.RESOURCE_VECTOR";
	public static final String RESPONSE_OBJECT_KEY = "mj.cchp.RESPONSE_OBJECT_KEY";
	public static final String RESPONSE_VECTOR_KEY = "mj.cchp.RESPONSE_VECTOR_KEY";
	public static final int ROLE_BUH = 103;
	public static final int ROLE_CRMTADMIN = 107;
	public static final int ROLE_CRMTFEEDBACKLOGGER = 108;
	public static final String ROLE_DESCRIPTION_APPROVER = "APPROVER";
	public static final String ROLE_DESCRIPTION_BUH = "BUH";
	/**
	 * Below entries are added for CRMT Login CCHP V 1.3 Date: 28-04-2009
	 * (Partha Pratim Saha) Start
	 */
	public static final String ROLE_DESCRIPTION_CRMTADMIN = "CRMT ADMIN";
	public static final String ROLE_DESCRIPTION_CRMTFEEDBACKLOGGER = "CRMT FEEDBACK LOGGER";
	// ********************* Prasenjit : End ************************//
	public static final String ROLE_DESCRIPTION_FEEDBACK_LOGGER = "FEEDBACK LOGGER";
	public static final String ROLE_DESCRIPTION_HEADAC = "HEAD ACCOUNT MANAGEMENT";
	public static final String ROLE_DESCRIPTION_HEADOP = "HEAD OPERATION";
	public static final String ROLE_DESCRIPTION_INTERNALFEEDBACKLOGGER = "INTERNAL FEEDBACK LOGGER";
	public static final String ROLE_DESCRIPTION_LOGGER = "LOGGER";
	public static final String ROLE_DESCRIPTION_RECEIVER = "RECEIVER";
	public static final String ROLE_DESCRIPTION_REPORTVIEW = "REPORT-VIEW";
	public static final String ROLE_DESCRIPTION_RESOLVER = "RESOLVER";
	public static final String ROLE_DESCRIPTION_SPOCINCIDENT = "SPOC-INCIDENT";
	public static final String ROLE_DESCRIPTION_SUPERVISOR = "SUPERVISOR";
	public static final int ROLE_HEADAC = 106;
	public static final int ROLE_HEADOP = 105;
	public static final int ROLE_ID_APPROVER = 115;
	public static final int ROLE_ID_INTERNAL_FEEDBACKLOGGER = 109;
	public static final int ROLE_ID_MISF = 112;
	public static final int ROLE_ID_REPORTVIEW = 114;
	public static final int ROLE_ID_SPOCINCIDENT = 113;
	public static final String ROLE_MISF_DESCRIPTION = "MISF";
	public static final int ROLE_RECEIVER = 100;
	public static final int ROLE_RESOLVER = 101;
	public static final int ROLE_SUPERVISOR = 110;
	public static final String ROLE_VECTOR = "mj.cchp.ROLE_VECTOR";
	public static final String ROLETYPE_DESCRIPTION_SPOC1 = "SPOC1";
	public static final String ROLETYPE_DESCRIPTION_SPOC2 = "SPOC2";
	public static final String ROLETYPE_DESCRIPTION_SPOC3 = "SPOC3";
	public static final int ROLETYPE_ID_SPOC1 = 100;
	public static final int ROLETYPE_ID_SPOC2 = 101;
	public static final int ROLETYPE_ID_SPOC3 = 102;
	public static final String ROLETYPE_VECTOR = "mj.cchp.ROLETYPE_VECTOR";
	public static final String SATISFACTIONLEVEL = "mj.cchp.SATISFACTIONLEVEL";
	public static final String SEARCH_TASKCATEGORY = "TASKCATEGORY";
	public static final String SEARCH_TASKGROUP = "TASKGROUP";
	public static final String SEARCH_TASKSUBGROUP = "TASKSUBGROUP";
	public static final String SEARCH_TASKTYPE = "TASKTYPE";
	public static final String SELECTED_CLIENT = "mj.cchp.SELECTED_CLIENT";
	public static final String SERVICE = "mj.cchp.SERVICE";
	public static final String SERVICE_CODE_ADMIN = "ADMIN";
	public static final String SERVICE_CODE_HR = "HR";
	public static final String SERVICE_DESCRIPTION_ADMIN = "ADMIN";
	public static final String SERVICE_DESCRIPTION_HR = "HR";
	public static final String SERVICE_DESCRIPTION_VALUEJUNCTION = "VALUEJUNCTION";
	public static final String SERVICE_ID = "mj.cchp.SERVICE_ID";
	public static final int SERVICE_ID_ADMIN = 112;
	public static final int SERVICE_ID_AUTO = 105;

	public static final int SERVICE_ID_AUTOB2C = 113;
	public static final int SERVICE_ID_BE = 117;
	public static final int SERVICE_ID_BHEL = 123;
	public static final int SERVICE_ID_CHANNEL_FINANCE = 103;
	public static final int SERVICE_ID_COAL_SALES = 100;
	public static final int SERVICE_ID_CRMT = 109;
	public static final int SERVICE_ID_EPS = 101;
	public static final int SERVICE_ID_EPS_NONSAIL = 107;
	public static final int SERVICE_ID_HR = 111;
	public static final int SERVICE_ID_IA = 300;
	public static final int SERVICE_ID_MJEDGE = 110;
	public static final int SERVICE_ID_MJUNCTION = 200;
	public static final int SERVICE_ID_OFB = 122;
	public static final int SERVICE_ID_RA = 104;
	public static final int SERVICE_ID_SL = 114;
	public static final int SERVICE_ID_STEEL_SALES = 102;
	public static final int SERVICE_ID_TECHNOLOGY = 106;
	public static final int SERVICE_ID_VALUEJUNCTION = 115;
	public static final String SERVICE_TIMING_LIST = "mj.cchp.SERVICE_TIMING_LIST";
	public static final String SERVICE_TYPE_EXTERNALCLIENT = "EXTERNAL";
	public static final String SERVICE_TYPE_INTERNALCLIENT = "INTERNAL";
	public static final String SERVICE_TYPE_OUTSIDERCLIENT = "OUTSIDER";
	public static final String SERVICE_VECTOR = "mj.cchp.SERVICE_VECTOR";
	public static final String SERVICEMAIL_ARRAY_VECTOR = "mj.cchp.SERVICEMAIL_ARRAY_VECTOR";
	public static final String SERVICEMAIL_OBJECT = "mj.cchp.SERVICEMAIL_OBJECT";
	public static final String SERVICEMAIL_SUCCESS = "mj.cchp.SERVICEMAIL_SUCCESS";
	public static final String SERVICEMAIL_VECTOR = "mj.cchp.SERVICEMAIL_VECTOR";
	public static final int SLA_BUSINESS_END_TIME = 17;
	public static final int SLA_BUSINESS_START_TIME = 9;
	public static final String SLA_OBJECT = "mj.cchp.SLA_OBJECT";
	public static final String SPOC_INCIDENT = "113";
	public static final int STARTING_YEAR_FOR_DATE_PARSE = 1900; // This value
	public static final String STATUS_CLOSED = "mj.cchp.STATUS_CLOSED";
	public static final String STATUS_CODE_ACTIVE = "A";
	public static final String STATUS_CODE_AWAITING_APPROVAL = "W";
	public static final String STATUS_CODE_FALSE = "false";
	public static final String STATUS_CODE_INACTIVE = "X";
	public static final String STATUS_CODE_NOT_APPLICABLE = "N / A";
	public static final String STATUS_CODE_OFF = "0";
	public static final String STATUS_CODE_ON = "1";
	// Rejected
	// Status
	public static final String STATUS_CODE_SUB_PROJECT = "S"; // For Sub Project
	public static final String STATUS_CODE_TRUE = "true";
	public static final int STEELSALES_BUH_ID = 128;
	public static final String SURVETTYPEFLAG_INTERNAL = "INTERNAL";
	public static final String SURVEY_CLOSEFLAG = "CLOSED";
	public static final String SURVEY_ID = "mj.cchp.survey.SURVEY_ID";
	public static final String SURVEY_LIST = "mj.cchp.survey.SURVEY_LIST";
	public static final String SURVEY_OPENFLAG = "OPEN";
	public static final String SURVEYTYPEFLAG_ETHICS_EXTERNAL = "ETHICS-EXTERNAL";
	public static final String SURVEYTYPEFLAG_ETHICS_INTERNAL = "ETHICS-INTERNAL";
	public static final String SURVEYTYPEFLAG_EXTERNAL = "EXTERNAL";
	public static final String SURVEYTYPEFLAG_TEST = "TEST";
	public static final String TASK_CATEGORY_ID = "mj.cchp.TASK_CATEGORY_ID";
	// End Mrinmoy
	// Start Mrinmoy
	public static final String TASK_CATEGORY_OBJ_VECTOR = "mj.cchp.TASK_CATEGORY_OBJ_VECTOR";
	/* Varun - End */
	// Start : Somnath
	public static final String TASK_GROUP_ATTRIBUTE_VECTOR = "mj.cchp.TASK_GROUP_ATTRIBUTE_VECTOR";
	public static final String TASK_GROUP_ID = "mj.cchp.TASK_GROUP_ID";
	/* Varun - Start */
	public static final String TASK_GROUP_VECTOR = "mj.cchp.TASK_GROUP_VECTOR";
	public static final String TASK_SIZE_UNIT = "UCP";
	public static final String TASK_STARTTIME = "mj.cchp.TASK_STARTTIME";
	public static final String TASK_SUB_GROUP_VECTOR = "mj.cchp.TASK_SUB_GROUP_VECTOR";
	public static final String TASK_TYPE_OBJ_VECTOR = "mj.cchp.TASK_TYPE_OBJ_VECTOR";
	public static final String TASK_VECTOR = "mj.cchp.TASK_VECTOR";
	public static final String TASKASSIGN_MYSELF = "ASSIGNED";
	public static final int TASKCATEGORY_ID_BUGFIX = 112;
	public static final int TASKCATEGORY_ID_DATAUPLOAD = 116;
	public static final int TASKCATEGORY_ID_DEVELOPMENT = 109;
	public static final int TASKCATEGORY_ID_MODIFICATION = 113;
	public static final int TASKCATEGORY_ID_SUPPORT = 114;
	public static final String TASKCATEGORY_VECTOR = "mj.cchp.TASKCATEGROY_VECTOR";
	public static final String TASKCOLSE = "CLOSED";
	public static final String TASKCOMPLETE_ALL = "ALL COMPLETE";
	public static final String TASKCOMPLETE_MYSELF = "COMPLETE";
	public static final String TASKGROUP_VECTOR = "mj.cchp.TASKGROUP_VECTOR";
	public static final String TASKOBJECT = "mj.cchp.TASKOBJECT";
	public static final String TASKOPEN_ALL = "OPEN";
	public static final String TASKOPEN_MYSELF = "OPEN";
	public static final String TASKRECEIPT_PRIMARY = "PRIMARY";
	public static final String TASKRECEIPT_SECONDARY = "SECONDARY";
	public static final String TASKREOPEN = "REOPEN";
	public static final String TASKSUBGROUP_AVGFLAG_NO = "N";
	public static final String TASKSUBGROUP_AVGFLAG_YES = "Y";
	public static final String TASKSUBGROUP_VECTOR = "mj.cchp.TASKSUBGROUP_VECTOR";
	public static final String TASKSUBGROUPSTATUS_SIMULTANEOUS = "SIMALTANEOUS";
	public static final String TASKSUBGROUPSTATUS_SYNCHRONOUS = "SEQUENTIAL";
	public static final String TASKTYPE_VECTOR = "mj.cchp.TASKTYPE_VECTOR";
	public static final String TASKUNASSIGNED = "UNASSIGNED";
	public static final int TECH_ISSUE_ESCALATION_ID = 104;
	public static final int TEMPLATE_ATTRIBUTE_CLIENT_AUTO = 110;
	public static final int TEMPLATE_ATTRIBUTE_CLIENT_COAL = 100;
	public static final int TEMPLATE_ATTRIBUTE_CLIENT_EPS = 102;
	public static final int TEMPLATE_ATTRIBUTE_CLIENT_STEEL_SALES = 104;
	public static final String TEMPLATE_ATTRIBUTE_OPTION_LIST = "mj.cchp.TEMPLATE_ATTRIBUTE_OPTION_LIST";
	public static final String TEMPLATE_ATTRIBUTE_VECTOR = "mj.cchp.TEMPLATE_ATTRIBUTE_VECTOR";
	public static final String TEMPLATE_ATTRIBUTE_VECTOR_KEY = "mj.cchp.TEMPLATE_ATTRIBUTE_VECTOR_KEY";
	// Entry for Timesheet
	public static final String TIMESHEET_ADDED_ENTRY = "DIRECT ENTRY";
	public static final String TIMESHEET_STATUS_NOTSUBMITTED = "NOT SUBMITTED";
	public static final String TIMESHEET_STATUS_READONLY_FALSE = "N";
	public static final String TIMESHEET_STATUS_READONLY_TRUE = "Y";
	public static final String TIMESHEET_TASK_REPLY = "TASK REPLY";
	public static final int TRANSACTIONAL_FEEDBACK_USER_REGISTERED_CCHP = 1;
	public static final String TRAVERSABLE_VECTOR_KEY = "mj.cchp.TRAVERSABLE_VECTOR_KEY";
	public static final String UNMAPPED_USER_VECTOR = "mj.cchp.UNMAPPED_USER_VECTOR";
	public static final int UNREGISTERED_CCHP_USER = -1;
	public static final String USEING_PROJECTID = "projectId";
	public static final String USEING_USERID = "userId";
	// End : somnath
	// start: vikas
	public static final String USER_ABSENT_VECTOR = "mj.cchp.USER_ABSENT_VECTOR";
	public static final String USER_CONTAINER_KEY = "USER_CONTAINER_KEY";
	public static final String USER_EMAIL = "mj.cchp.USER_EMAIL";
	public static final String USER_ID = "mj.cchp.USER_ID";

	public static final String USER_INTERNAL_OBJECT = "mj.cchp.USER_INTERNAL_OBJECT";
	public static final String USER_INTERNAL_VECTOR = "mj.cchp.USER_INTERNAL_VECTOR";
	public static final String USER_NAME_VECTOR = "mj.cchp.USER_NAME_VECTOR";
	public static final int USER_REGISTERED_CCHP = 0;

	public static final String USER_REGISTRATION_FROM_DIFFERENT_MODULE = "Different Module";
	public static final String USER_WORKING_DETAILS_VECTOR = "mj.cchp.USER_WORKING_DETAILS_VECTOR";
	public static final String USERID_KEY = "mj.cchp.USERID_KEY";
	public static final String USERINPUT_PROCCED = "PR";
	public static final String USERINPUT_RML = "RML";
	public static final String USERINPUT_UNDERSTAND = "UND";

	public static final String USERTYPE_VECTOR = "mj.cchp.USERTYPE_VECTOR";
	public static final String VCODE_VECTOR = "mj.cchp.VCODE_VECTOR";
	public static final String WORKFLOW_LIST = "mj.cchp.WORKFLOW_LIST";

	/**MD Escalation Start */
	public static final int SERVICE_ID_CC = 129;
	public static final int FEEDBACKTYPE_ID_MD = 141;
	public static final String MD_FEEDBACK_NEW_LIST = "mj.cchp.MD_FEEDBACK_NEW_LIST";
	public static final String MD_FEEDBACK_ASSIGNED_LIST = "mj.cchp.MD_FEEDBACK_ASSIGNED_LIST";
	public static final String MD_FEEDBACK_RESOLVED_LIST = "mj.cchp.MD_FEEDBACK_RESOLVED_LIST";
	public static final Object FEEDBACK_FLAG_REOPEN = "REOPEN";
	public static final String MD_FEEDBACK_REOPENED_LIST = "mj.cchp.MD_FEEDBACK_REOPENED_LIST";
	/**MD Escalation End */
	
	public static final String SERVICES = "mj.cchp.SERVICE_LIST";
	public static final String MASTER_AREA_LIST = "mj.cchp.MASTER_AREA_LIST";
	public static final String SUBAREA_LIST = "mj.cchp.SUBAREA_LIST";
	public static final String MAPPED_USER_LIST = "mj.cchp.MAPPED_USER_LIST";
	public static final String UNMAPPED_USER_LIST = "mj.cchp.UNMAPPED_USER_LIST";	

	public static final String NEW_FEEDBACKS = "mj.cchp.NEW_FEEDBACKS";
	public static final String ASSIGNED_FEEDBACKS = "mj.cchp.ASSIGNED_FEEDBACKS";
	public static final String INTERNAL_RESOLVED_FEEDBACKS = "mj.cchp.INTERNAL_RESOLVED_FEEDBACKS";
	public static final String EXTERNAL_RESOLVED_FEEDBACKS = "mj.cchp.EXTERNAL_RESOLVED_FEEDBACKS";
	public static final String OPEN_FEEDBACKS = "mj.cchp.OPEN_FEEDBACKS";

	public static final String H2H_NEW_FEEDBACKS = "mj.cchp.H2H_NEW_FEEDBACKS";
	public static final String H2H_ASSIGNED_FEEDBACKS = "mj.cchp.H2H_ASSIGNED_FEEDBACKS";
	public static final String ACTIVITI_PROCESS_ID = "heart2heart:5:582963";
	public static final String ITEM_TECH_FORMAT = "com.stock.ITEM_TECH_FORMAT";
	public static final String CROSSOVER_POSITIVE = "POSITIVE";
	public static final String CROSSOVER_NEGETIVE = "NEGETIVE";
	public static final String CROSSOVER_POSITION_ABOVE_ZERO = "ABOVE ZERO LINE";
	public static final String CROSSOVER_POSITION_BELOW_ZERO = "BELOW ZERO LINE";
	public static final int MODE_SWING_TRADING = 2;
	public static final int MODE_SWING_TRADING_INDEX = 1;
	public static final int GROUP_ALLOCATION_INDEX_NIFTY50 = 12;
	public static final int GROUP_ALLOCATION_INDEX_NIFTYNEXT50 = 13;
	public static final int GROUP_ALLOCATION_INDEX_NIFTYMIDCAP50 = 14;
	public static final int GROUP_ALLOCATION_INDEX_NIFTYOTHERS50 = 15;
	public static final String CURRENT_HOLDING_TEXT = "CURRENT HOLDING";
	public static final String POSITIONS_TEXT = "POSITIONS";
	public static final double INTRADAY_RISK = 3.33;



}
